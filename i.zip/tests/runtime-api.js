#!/usr/bin/env node
'use strict';
/**
 * Per-server runtime check (process vs Docker) against a running panel.
 * Requires the panel to see a Docker engine - in CI/sandboxes point it at the
 * test double:  PATH="$(node scripts/fake-docker.js --print-path):$PATH" node server.js
 *
 *   node tests/runtime-api.js --url http://localhost:8090 --user admin --pass secret
 *
 * The checks assert *facts*, never assumptions: the container name comes back
 * from the API and is looked up through the docker CLI the panel used.
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const H = require('./lib/harness');
const dockerSvc = require('../src/services/docker');
const cfg = require('../src/config');

const SERVERS_DIR = H.flag('servers-dir', process.env.SERVER_DATA_DIR || path.join(process.cwd(), 'servers'));
const REAL_INSTALL = !process.argv.includes('--no-install');

const dockerAvailable = () => {
  try { execFileSync('docker', ['info'], { stdio: 'ignore' }); return true; } catch (_) { return false; }
};

const inspect = (container, format) => {
  try { return execFileSync('docker', ['inspect', '-f', format, container], { encoding: 'utf8' }).trim(); } catch (_) { return null; }
};

/** Wait until the software is really on disk (jar) - returns { server, jar, size }. */
async function waitForJar(id, token, timeoutMs = 150000) {
  const deadline = Date.now() + timeoutMs;
  let server = null;
  let jarSeen = null;
  while (Date.now() < deadline) {
    const r = await H.api(`/api/servers/${id}`, { token });
    server = (r.json && r.json.server) || server;
    const jar = path.join(SERVERS_DIR, id, (server && server.jarFile) || 'server.jar');
    if (fs.existsSync(jar) && fs.statSync(jar).size > 1024) {
      jarSeen = { jar, size: fs.statSync(jar).size };
      // the jar lands a moment before the panel writes lastInstalledAt
      if (server && server.lastInstalledAt) return { server, ...jarSeen };
    }
    await H.sleep(2000);
  }
  return { server, jar: jarSeen ? jarSeen.jar : null, size: jarSeen ? jarSeen.size : 0 };
}

(async () => {
  const token = await H.login();
  H.begin('per-server runtime (process | docker)');

  // A panel may itself run in Docker while it controls the host daemon. Its
  // internal /app/servers path must then be translated to the configured host
  // source path—not handed verbatim to the host daemon.
  const savedBindRoot = process.env.DOCKER_BIND_ROOT;
  const panelServerPath = path.join(cfg.serverDataDir, 'srv_bind_contract');
  process.env.DOCKER_BIND_ROOT = '/var/lib/zenith-host/servers';
  const mappedBindPath = dockerSvc.bindSourcePath(panelServerPath);
  H.check('containerised-panel Docker bind path maps its managed /data source to the host root', mappedBindPath === '/var/lib/zenith-host/servers/srv_bind_contract', mappedBindPath);
  process.env.DOCKER_BIND_ROOT = 'relative-path-is-not-safe';
  let rejectedRelativeBindRoot = false;
  try { dockerSvc.bindSourcePath(panelServerPath); } catch (err) { rejectedRelativeBindRoot = /absolute host path/i.test(err.message); }
  H.check('containerised-panel Docker bind root rejects a relative host path', rejectedRelativeBindRoot);
  if (savedBindRoot === undefined) delete process.env.DOCKER_BIND_ROOT;
  else process.env.DOCKER_BIND_ROOT = savedBindRoot;

  if (!dockerAvailable()) {
    H.check('docker engine reachable for the test', false, 'start the panel with the fake-docker PATH, or install Docker');
    process.exit(H.finish() ? 1 : 0);
  }

  const created = [];
  const name = `Runtime Test ${Date.now().toString().slice(-5)}`;
  let srv = null;
  let restrictedUserId = null;

  try {
    // Server provisioning is intentionally an administrator-only operation.
    // Exercise the HTTP boundary with a real, temporary ordinary account so a
    // hidden button can never be mistaken for authorization.
    const restrictedName = `deny${Date.now().toString().slice(-10)}`;
    const createdUser = await H.api('/api/users', {
      token, method: 'POST',
      body: { username: restrictedName, password: 'OnlyAdminCreates123!', role: 'user' },
    });
    restrictedUserId = createdUser.json && createdUser.json.user && createdUser.json.user.id;
    H.check('administrator can create a temporary ordinary account for authorization coverage', createdUser.status === 201 && Boolean(restrictedUserId), createdUser.json && createdUser.json.error ? createdUser.json.error : `HTTP ${createdUser.status}`);
    if (restrictedUserId) {
      const restrictedLogin = await H.api('/api/auth/login', {
        method: 'POST', body: { username: restrictedName, password: 'OnlyAdminCreates123!' },
      });
      const restrictedToken = restrictedLogin.json && restrictedLogin.json.token;
      const forbiddenCreate = await H.api('/api/servers', {
        token: restrictedToken, method: 'POST',
        body: { name: 'Forbidden provisioning attempt', serverType: 'PAPER', version: '1.21.4', memory: 512, install: false },
      });
      H.check('ordinary users cannot create servers through the API', forbiddenCreate.status === 403 && /administrator privileges required/i.test((forbiddenCreate.json || {}).error || ''), (forbiddenCreate.json || {}).error || `HTTP ${forbiddenCreate.status}`);
    }

    const res = await H.api('/api/servers', {
      token, method: 'POST',
      body: { name, serverType: 'PAPER', version: '1.21.4', memory: 1024, backend: 'docker', dockerImage: 'eclipse-temurin:17-jre', eulaAccepted: true, install: false },
    });
    srv = res.json && res.json.server;
    H.check('created with an explicit docker runtime', res.status === 201 && Boolean(srv), `HTTP ${res.status}`);
    if (srv) created.push(srv.id);
    H.check('image stored on the server', Boolean(srv && srv.dockerImage === 'eclipse-temurin:17-jre'), srv ? srv.dockerImage : '');

    // The runtime needs a jar to launch. Either really install the software
    // (network) or drop the fixture jar the test double is happy with.
    let jar = path.join(SERVERS_DIR, srv.id, (srv.jarFile || 'server.jar'));
    if (REAL_INSTALL) {
      await H.api(`/api/servers/${srv.id}/reinstall`, { token, method: 'POST', body: {} });
      const done = await waitForJar(srv.id, token, 150000);
      const stamp = done.server && done.server.lastInstalledAt;
      H.check('software really installed (jar on disk, panel stamped it)',
        Boolean(done.size && stamp), done.size ? `${(done.size / 1048576).toFixed(1)} MB, installed ${stamp || 'unstamped'}` : 'no jar after 150s (offline?)');
      if (done.jar) jar = done.jar;
    }
    if (!fs.existsSync(jar)) {
      fs.mkdirSync(path.dirname(jar), { recursive: true });
      fs.writeFileSync(jar, 'fixture jar - the container engine here is the test double');
      H.check('jar fixture written for the container run', true, jar);
    }

    const start = await H.api(`/api/servers/${srv.id}/start`, { token, method: 'POST' });
    H.check('start accepted', start.status === 200, start.json && start.json.error ? start.json.error : `HTTP ${start.status}`);
    await H.sleep(3500);

    const detail = await H.api(`/api/servers/${srv.id}`, { token });
    const live = detail.json.live || {};
    H.check('it really runs in a container', Boolean(live.container), live.container || 'no container reported');
    H.check('the container is up in the docker engine', live.container ? inspect(live.container, '{{.State.Running}}') === 'true' : false, live.container || '');
    H.check('the container used the per-server image', live.container ? inspect(live.container, '{{.Config.Image}}') === 'eclipse-temurin:17-jre' : false,
      live.container ? String(inspect(live.container, '{{.Config.Image}}')) : '');
    H.check('container name follows the zenith-<serverId> contract', Boolean(live.container && live.container === `zenith-${srv.id}`), live.container || '');

    const switchWhileRunning = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'process' } });
    H.check('runtime switch refused while running', switchWhileRunning.status === 409, `HTTP ${switchWhileRunning.status}`);

    await H.api(`/api/servers/${srv.id}/stop`, { token, method: 'POST' });
    await H.sleep(2000);
    const toProcess = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'process' } });
    H.check('switch to the process runtime works when stopped', toProcess.status === 200, `HTTP ${toProcess.status}`);
    const toDocker = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'docker' } });
    H.check('switch back to docker works', toDocker.status === 200, `HTTP ${toDocker.status}`);
    const follow = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: '' } });
    H.check('"follow the node" resets the override', follow.status === 200 && follow.json.server && !follow.json.server.requestedBackend,
      follow.json && follow.json.server ? `backend=${follow.json.server.backend || '(node default)'}` : '');
    const badImage = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'docker', dockerImage: 'not a valid image!!' } });
    H.check('invalid image reference rejected', badImage.status === 400, `HTTP ${badImage.status}`);

    // Dedicated games use a separately-audited SteamCMD catalogue. The test
    // double exercises the actual Docker install/create/attach control path
    // without downloading a multi-gigabyte public game during CI.
    const gameCatalogue = await H.api('/api/system/games', { token });
    const gameNames = ((gameCatalogue.json || {}).games || []).map((game) => game.name);
    H.check('dedicated-game catalogue exposes every requested game template', gameCatalogue.status === 200 && ['Rust', 'ARK: Survival Evolved', 'Palworld', 'Valheim', 'Terraria', 'Counter-Strike 2', "Garry's Mod", 'Team Fortress 2', '7 Days to Die', 'Project Zomboid', 'DayZ', 'Unturned', 'V Rising', 'Conan Exiles', 'Satisfactory', 'Factorio', "Don't Starve Together", 'Space Engineers', 'Starbound', 'Squad'].every((name) => gameNames.includes(name)), `${gameNames.length} templates`);
    H.check('publisher Windows-only templates are explicit rather than fake Linux options', Boolean(((gameCatalogue.json || {}).games || []).find((game) => game.id === 'space-engineers' && game.availableOnLocalNode === false)));
    const gameCreate = await H.api('/api/servers', {
      token, method: 'POST',
      body: { workloadType: 'game', gameId: 'rust', name: `Rust Test ${Date.now().toString().slice(-5)}`, memory: 1024, diskLimit: 0, cpuLimit: 20, maxPlayers: 12, install: true },
    });
    const gameServer = gameCreate.json && gameCreate.json.server;
    H.check('admin can create an audited SteamCMD game server', gameCreate.status === 201 && gameServer && gameServer.workloadType === 'game' && gameServer.gameId === 'rust' && gameServer.gameAppId === 258550, gameCreate.json && gameCreate.json.error ? gameCreate.json.error : `HTTP ${gameCreate.status}`);
    if (gameServer) {
      created.push(gameServer.id);
      H.check('game secrets are never included in the server projection', gameServer.gameSecrets === undefined && gameServer.game && gameServer.game.name === 'Rust');
      await H.sleep(900);
      const gameStart = await H.api(`/api/servers/${gameServer.id}/start`, { token, method: 'POST' });
      H.check('installed game starts in its real Docker game container', gameStart.status === 200, gameStart.json && gameStart.json.error ? gameStart.json.error : `HTTP ${gameStart.status}`);
      await H.sleep(650);
      const gameDetail = await H.api(`/api/servers/${gameServer.id}`, { token });
      const gameLive = gameDetail.json && gameDetail.json.live;
      H.check('game runtime uses the SteamCMD image and reserves its port block', Boolean(gameLive && gameLive.container && inspect(gameLive.container, '{{.Config.Image}}') === 'cm2network/steamcmd:latest') && Array.isArray(gameDetail.json.server.portAllocations) && gameDetail.json.server.portAllocations.length === 2, gameLive && gameLive.container ? gameLive.container : 'not running');
      const mutateGamePort = await H.api(`/api/servers/${gameServer.id}`, { token, method: 'PATCH', body: { port: 28015 } });
      H.check('game port blocks cannot be partially reassigned', mutateGamePort.status === 400 && /allocated together/i.test((mutateGamePort.json || {}).error || ''), (mutateGamePort.json || {}).error || `HTTP ${mutateGamePort.status}`);
      const windowsGame = await H.api('/api/servers', { token, method: 'POST', body: { workloadType: 'game', gameId: 'space-engineers', name: 'Windows-only fixture', install: false } });
      H.check('Windows-only game profile refuses Linux Docker provisioning honestly', windowsGame.status === 409 && /Windows-only/i.test((windowsGame.json || {}).error || ''), (windowsGame.json || {}).error || `HTTP ${windowsGame.status}`);
      await H.api(`/api/servers/${gameServer.id}/stop`, { token, method: 'POST' });
    }

    // General container provisioning is intentionally separate from the JVM
    // path: it pulls a curated Linux image, starts a real container, then runs
    // SSHX inside that container and reports the real browser-session URL.
    const workload = await H.api('/api/servers', {
      token, method: 'POST',
      body: { workloadType: 'container', containerTemplate: 'ubuntu-22.04', name: `Shell Test ${Date.now().toString().slice(-5)}`, memory: 512, cpuLimit: 20, diskLimit: 0, install: false },
    });
    const container = workload.json && workload.json.server;
    H.check('created a curated Docker workload', workload.status === 201 && container && container.workloadType === 'container', workload.json && workload.json.error ? workload.json.error : `HTTP ${workload.status}`);
    if (container) {
      created.push(container.id);
      H.check('workload stores its fixed selected image', container.dockerImage === 'ubuntu:22.04' && container.containerTemplate === 'ubuntu-22.04', `${container.containerTemplate} / ${container.dockerImage}`);
      const started = await H.api(`/api/servers/${container.id}/start`, { token, method: 'POST' });
      H.check('general workload starts through Docker', started.status === 200, started.json && started.json.error ? started.json.error : `HTTP ${started.status}`);
      await H.sleep(900);
      const workDetail = await H.api(`/api/servers/${container.id}`, { token });
      const workLive = workDetail.json && workDetail.json.live;
      H.check('general workload has a real running container', Boolean(workLive && workLive.container && inspect(workLive.container, '{{.State.Running}}') === 'true'), workLive && workLive.container ? workLive.container : 'no running container');
      const bootstrapCommand = workLive && workLive.container ? inspect(workLive.container, '{{json .Config.Cmd}}') : '';
      H.check('container bootstrap installs and runs SSHX inside the selected image', /curl -sSf https:\/\/sshx\.io\/get \| sh/.test(bootstrapCommand) && /\(sshx;/.test(bootstrapCommand), bootstrapCommand || 'no container command');
      const sshx = (workDetail.json && ((workDetail.json.live || {}).sshx || (workDetail.json.server || {}).sshx)) || {};
      H.check('workload reports the SSHX link emitted by its container', sshx.status === 'ready' && /^https:\/\/sshx\.io\//.test(sshx.url || ''), sshx.url || sshx.error || `status=${sshx.status || 'missing'}`);

      // Two VPS workloads must receive separate hostnames, Docker bridge
      // networks, writable roots, /data mounts and cgroup limits. These are
      // inspected from Docker's actual configuration, never inferred from UI.
      const secondWorkload = await H.api('/api/servers', {
        token, method: 'POST',
        body: { workloadType: 'container', containerTemplate: 'debian-12', name: `Shell Peer ${Date.now().toString().slice(-5)}`, memory: 768, cpuLimit: 50, diskLimit: 0, install: false },
      });
      const second = secondWorkload.json && secondWorkload.json.server;
      H.check('created a second isolated Docker VPS workload', secondWorkload.status === 201 && second && second.workloadType === 'container', secondWorkload.json && secondWorkload.json.error ? secondWorkload.json.error : `HTTP ${secondWorkload.status}`);
      if (second) {
        created.push(second.id);
        const startSecond = await H.api(`/api/servers/${second.id}/start`, { token, method: 'POST' });
        H.check('second workload starts in Docker', startSecond.status === 200, startSecond.json && startSecond.json.error ? startSecond.json.error : `HTTP ${startSecond.status}`);
        await H.sleep(1600);
        const secondDetail = await H.api(`/api/servers/${second.id}`, { token });
        const secondLive = secondDetail.json && secondDetail.json.live;
        const firstInspect = workLive && workLive.container ? JSON.parse(inspect(workLive.container, '{{json .}}') || '{}') : {};
        const secondInspect = secondLive && secondLive.container ? JSON.parse(inspect(secondLive.container, '{{json .}}') || '{}') : {};
        const isolated = (doc, expectedMemory) => doc.Config && doc.HostConfig && doc.Config.Hostname
          && doc.HostConfig.PidMode === 'private' && doc.HostConfig.UTSMode === 'private' && doc.HostConfig.IpcMode === 'private'
          && doc.HostConfig.NetworkMode && doc.HostConfig.NetworkMode !== 'host'
          && doc.HostConfig.Privileged === false && Array.isArray(doc.HostConfig.SecurityOpt) && doc.HostConfig.SecurityOpt.includes('no-new-privileges:true')
          && doc.HostConfig.Memory === expectedMemory * 1024 * 1024
          && Array.isArray(doc.Mounts) && doc.Mounts.length === 1 && doc.Mounts[0].Destination === '/data' && doc.Mounts[0].RW === true;
        H.check('both VPS containers have private namespaces, cgroup memory limits, and only their own /data bind', isolated(firstInspect, 512) && isolated(secondInspect, 768), `${firstInspect.Config && firstInspect.Config.Hostname || '?'} / ${secondInspect.Config && secondInspect.Config.Hostname || '?'}`);
        H.check('two VPS containers do not share hostname, bridge network, or mounted workspace', Boolean(firstInspect.Config && secondInspect.Config)
          && firstInspect.Config.Hostname !== secondInspect.Config.Hostname
          && firstInspect.HostConfig.NetworkMode !== secondInspect.HostConfig.NetworkMode
          && firstInspect.Mounts[0].Source !== secondInspect.Mounts[0].Source,
        `${firstInspect.HostConfig && firstInspect.HostConfig.NetworkMode || '?'} / ${secondInspect.HostConfig && secondInspect.HostConfig.NetworkMode || '?'}`);
        const isolation = secondDetail.json && ((secondDetail.json.live || {}).isolation || (secondDetail.json.server || {}).containerIsolation) || {};
        H.check('VPS identity is read from its real container /etc/os-release and honestly marks the kernel shared', Boolean(isolation.identity && isolation.identity.os && isolation.identity.os.id && isolation.identity.hostname === second.containerHostname) && isolation.kernelShared === true, JSON.stringify(isolation.identity || isolation).slice(0, 180));
      }
      const terminal = await H.api(`/api/servers/${container.id}/terminal`, { token, method: 'POST', body: { command: 'pwd' } });
      H.check('retired embedded terminal refuses command execution', terminal.status === 410 && /replaced by the SSHX/i.test((terminal.json || {}).error || ''), terminal.json && terminal.json.error ? terminal.json.error : `HTTP ${terminal.status}`);
      const stopped = await H.api(`/api/servers/${container.id}/stop`, { token, method: 'POST' });
      await H.sleep(400);
      const stoppedDetail = await H.api(`/api/servers/${container.id}`, { token });
      const stoppedSshx = (stoppedDetail.json && ((stoppedDetail.json.live || {}).sshx || (stoppedDetail.json.server || {}).sshx)) || {};
      H.check('stopping a workload clears its SSHX capability link', stopped.status === 200 && stoppedSshx.status === 'offline' && !stoppedSshx.url, stoppedSshx.url || stoppedSshx.error || `status=${stoppedSshx.status || 'missing'}`);
      const mutateImage = await H.api(`/api/servers/${container.id}`, { token, method: 'PATCH', body: { dockerImage: 'debian:12' } });
      H.check('workload image cannot be changed post-create', mutateImage.status === 400, `HTTP ${mutateImage.status}`);
      const migrateWorkload = await H.api(`/api/servers/${container.id}/migrate`, { token, method: 'POST', body: { serverType: 'PAPER', version: '1.21.4' } });
      H.check('software switch refuses a Docker OS-image workload instead of pretending to install Minecraft', migrateWorkload.status === 400 && /do not have Minecraft software/i.test((migrateWorkload.json || {}).error || ''), (migrateWorkload.json || {}).error || `HTTP ${migrateWorkload.status}`);
    }
  } finally {
    for (const id of created) {
      try { await H.api(`/api/servers/${id}`, { token, method: 'DELETE' }); } catch (_) {}
    }
    if (restrictedUserId) {
      try { await H.api(`/api/users/${restrictedUserId}`, { token, method: 'DELETE' }); } catch (_) {}
    }
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
