#!/usr/bin/env node
'use strict';
/**
 * Per-server runtime check (process vs Docker) against a running panel.
 * Requires the panel to see a Docker engine - in CI/sandboxes point it at the
 * test double:  PATH="$(node scripts/fake-docker.js --print-path):$PATH" node server.js
 *
 *   node tests/runtime-api.js --url http://localhost:8090 --user admin --pass secret
 *
 * The checks assert *facts*, never assumptions: the container name comes back
 * from the API and is looked up through the docker CLI the panel used.
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const H = require('./lib/harness');

const SERVERS_DIR = H.flag('servers-dir', process.env.SERVER_DATA_DIR || path.join(process.cwd(), 'servers'));
const REAL_INSTALL = !process.argv.includes('--no-install');

const dockerAvailable = () => {
  try { execFileSync('docker', ['info'], { stdio: 'ignore' }); return true; } catch (_) { return false; }
};

const inspect = (container, format) => {
  try { return execFileSync('docker', ['inspect', '-f', format, container], { encoding: 'utf8' }).trim(); } catch (_) { return null; }
};

/** Wait until the software is really on disk (jar) - returns { server, jar, size }. */
async function waitForJar(id, token, timeoutMs = 150000) {
  const deadline = Date.now() + timeoutMs;
  let server = null;
  let jarSeen = null;
  while (Date.now() < deadline) {
    const r = await H.api(`/api/servers/${id}`, { token });
    server = (r.json && r.json.server) || server;
    const jar = path.join(SERVERS_DIR, id, (server && server.jarFile) || 'server.jar');
    if (fs.existsSync(jar) && fs.statSync(jar).size > 1024) {
      jarSeen = { jar, size: fs.statSync(jar).size };
      // the jar lands a moment before the panel writes lastInstalledAt
      if (server && server.lastInstalledAt) return { server, ...jarSeen };
    }
    await H.sleep(2000);
  }
  return { server, jar: jarSeen ? jarSeen.jar : null, size: jarSeen ? jarSeen.size : 0 };
}

(async () => {
  const token = await H.login();
  H.begin('per-server runtime (process | docker)');

  if (!dockerAvailable()) {
    H.check('docker engine reachable for the test', false, 'start the panel with the fake-docker PATH, or install Docker');
    process.exit(H.finish() ? 1 : 0);
  }

  const created = [];
  const name = `Runtime Test ${Date.now().toString().slice(-5)}`;
  let srv = null;

  try {
    const res = await H.api('/api/servers', {
      token, method: 'POST',
      body: { name, serverType: 'PAPER', version: '1.21.4', memory: 1024, backend: 'docker', dockerImage: 'eclipse-temurin:17-jre', eulaAccepted: true, install: false },
    });
    srv = res.json && res.json.server;
    H.check('created with an explicit docker runtime', res.status === 201 && Boolean(srv), `HTTP ${res.status}`);
    if (srv) created.push(srv.id);
    H.check('image stored on the server', Boolean(srv && srv.dockerImage === 'eclipse-temurin:17-jre'), srv ? srv.dockerImage : '');

    // The runtime needs a jar to launch. Either really install the software
    // (network) or drop the fixture jar the test double is happy with.
    let jar = path.join(SERVERS_DIR, srv.id, (srv.jarFile || 'server.jar'));
    if (REAL_INSTALL) {
      await H.api(`/api/servers/${srv.id}/reinstall`, { token, method: 'POST', body: {} });
      const done = await waitForJar(srv.id, token, 150000);
      const stamp = done.server && done.server.lastInstalledAt;
      H.check('software really installed (jar on disk, panel stamped it)',
        Boolean(done.size && stamp), done.size ? `${(done.size / 1048576).toFixed(1)} MB, installed ${stamp || 'unstamped'}` : 'no jar after 150s (offline?)');
      if (done.jar) jar = done.jar;
    }
    if (!fs.existsSync(jar)) {
      fs.mkdirSync(path.dirname(jar), { recursive: true });
      fs.writeFileSync(jar, 'fixture jar - the container engine here is the test double');
      H.check('jar fixture written for the container run', true, jar);
    }

    const start = await H.api(`/api/servers/${srv.id}/start`, { token, method: 'POST' });
    H.check('start accepted', start.status === 200, start.json && start.json.error ? start.json.error : `HTTP ${start.status}`);
    await H.sleep(3500);

    const detail = await H.api(`/api/servers/${srv.id}`, { token });
    const live = detail.json.live || {};
    H.check('it really runs in a container', Boolean(live.container), live.container || 'no container reported');
    H.check('the container is up in the docker engine', live.container ? inspect(live.container, '{{.State.Running}}') === 'true' : false, live.container || '');
    H.check('the container used the per-server image', live.container ? inspect(live.container, '{{.Config.Image}}') === 'eclipse-temurin:17-jre' : false,
      live.container ? String(inspect(live.container, '{{.Config.Image}}')) : '');
    H.check('container name follows the zenith-<serverId> contract', Boolean(live.container && live.container === `zenith-${srv.id}`), live.container || '');

    const switchWhileRunning = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'process' } });
    H.check('runtime switch refused while running', switchWhileRunning.status === 409, `HTTP ${switchWhileRunning.status}`);

    await H.api(`/api/servers/${srv.id}/stop`, { token, method: 'POST' });
    await H.sleep(2000);
    const toProcess = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'process' } });
    H.check('switch to the process runtime works when stopped', toProcess.status === 200, `HTTP ${toProcess.status}`);
    const toDocker = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'docker' } });
    H.check('switch back to docker works', toDocker.status === 200, `HTTP ${toDocker.status}`);
    const follow = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: '' } });
    H.check('"follow the node" resets the override', follow.status === 200 && follow.json.server && !follow.json.server.requestedBackend,
      follow.json && follow.json.server ? `backend=${follow.json.server.backend || '(node default)'}` : '');
    const badImage = await H.api(`/api/servers/${srv.id}`, { token, method: 'PATCH', body: { backend: 'docker', dockerImage: 'not a valid image!!' } });
    H.check('invalid image reference rejected', badImage.status === 400, `HTTP ${badImage.status}`);

    // General container provisioning is intentionally separate from the JVM
    // path: it pulls a curated Linux image, starts a real container, then runs
    // SSHX inside that container and reports the real browser-session URL.
    const workload = await H.api('/api/servers', {
      token, method: 'POST',
      body: { workloadType: 'container', containerTemplate: 'ubuntu-22.04', name: `Shell Test ${Date.now().toString().slice(-5)}`, memory: 512, cpuLimit: 20, diskLimit: 0, install: false },
    });
    const container = workload.json && workload.json.server;
    H.check('created a curated Docker workload', workload.status === 201 && container && container.workloadType === 'container', workload.json && workload.json.error ? workload.json.error : `HTTP ${workload.status}`);
    if (container) {
      created.push(container.id);
      H.check('workload stores its fixed selected image', container.dockerImage === 'ubuntu:22.04' && container.containerTemplate === 'ubuntu-22.04', `${container.containerTemplate} / ${container.dockerImage}`);
      const started = await H.api(`/api/servers/${container.id}/start`, { token, method: 'POST' });
      H.check('general workload starts through Docker', started.status === 200, started.json && started.json.error ? started.json.error : `HTTP ${started.status}`);
      await H.sleep(900);
      const workDetail = await H.api(`/api/servers/${container.id}`, { token });
      const workLive = workDetail.json && workDetail.json.live;
      H.check('general workload has a real running container', Boolean(workLive && workLive.container && inspect(workLive.container, '{{.State.Running}}') === 'true'), workLive && workLive.container ? workLive.container : 'no running container');
      const bootstrapCommand = workLive && workLive.container ? inspect(workLive.container, '{{json .Config.Cmd}}') : '';
      H.check('container bootstrap installs and runs SSHX inside the selected image', /curl -sSf https:\/\/sshx\.io\/get \| sh/.test(bootstrapCommand) && /\(sshx;/.test(bootstrapCommand), bootstrapCommand || 'no container command');
      const sshx = (workDetail.json && ((workDetail.json.live || {}).sshx || (workDetail.json.server || {}).sshx)) || {};
      H.check('workload reports the SSHX link emitted by its container', sshx.status === 'ready' && /^https:\/\/sshx\.io\//.test(sshx.url || ''), sshx.url || sshx.error || `status=${sshx.status || 'missing'}`);
      const terminal = await H.api(`/api/servers/${container.id}/terminal`, { token, method: 'POST', body: { command: 'pwd' } });
      H.check('retired embedded terminal refuses command execution', terminal.status === 410 && /replaced by the SSHX/i.test((terminal.json || {}).error || ''), terminal.json && terminal.json.error ? terminal.json.error : `HTTP ${terminal.status}`);
      const stopped = await H.api(`/api/servers/${container.id}/stop`, { token, method: 'POST' });
      await H.sleep(400);
      const stoppedDetail = await H.api(`/api/servers/${container.id}`, { token });
      const stoppedSshx = (stoppedDetail.json && ((stoppedDetail.json.live || {}).sshx || (stoppedDetail.json.server || {}).sshx)) || {};
      H.check('stopping a workload clears its SSHX capability link', stopped.status === 200 && stoppedSshx.status === 'offline' && !stoppedSshx.url, stoppedSshx.url || stoppedSshx.error || `status=${stoppedSshx.status || 'missing'}`);
      const mutateImage = await H.api(`/api/servers/${container.id}`, { token, method: 'PATCH', body: { dockerImage: 'debian:12' } });
      H.check('workload image cannot be changed post-create', mutateImage.status === 400, `HTTP ${mutateImage.status}`);
      const migrateWorkload = await H.api(`/api/servers/${container.id}/migrate`, { token, method: 'POST', body: { serverType: 'PAPER', version: '1.21.4' } });
      H.check('software switch refuses a Docker OS-image workload instead of pretending to install Minecraft', migrateWorkload.status === 400 && /do not have Minecraft software/i.test((migrateWorkload.json || {}).error || ''), (migrateWorkload.json || {}).error || `HTTP ${migrateWorkload.status}`);
    }
  } finally {
    for (const id of created) {
      try { await H.api(`/api/servers/${id}`, { token, method: 'DELETE' }); } catch (_) {}
    }
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
