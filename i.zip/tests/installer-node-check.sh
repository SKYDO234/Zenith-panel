#!/usr/bin/env bash
# Installer node-provisioning check.
#
# Sources install.sh (it only executes its main flow when run, never when sourced)
# with ACTION=noop, then calls the real functions.
# and then calls the REAL provisioning functions against a RUNNING panel:
# registration, credential handling, the health check and idempotency.
#
#   bash tests/installer-node-check.sh [panel-port]
#
# A green run means the code install.sh ships really works - the checks never
# curl by hand, they call the installer's own functions.
set -u

PORT="${1:-8090}"
PANEL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export ZENITH_LOG="${ZENITH_LOG:-${TMPDIR:-/tmp}/zenith-installer-check.log}"
: >"$ZENITH_LOG"

fails=0
ok()  { printf '  ok   %s\n' "$*"; }
bad() { printf ' FAIL  %s\n' "$*"; fails=$((fails + 1)); }

# The installer parses $@ at source time - keep it empty. Pass the temporary
# panel port through its documented environment setting before sourcing: the
# installer's own PORT default is intentionally 8080 for real installations.
set --
ACTION=noop
export ZENITH_PORT="$PORT"
# shellcheck disable=SC1090,SC1091
. "$PANEL_DIR/install.sh" >/dev/null   # defines functions only, runs nothing

# Codespaces is a first-class installer target: the default port is declared
# for the Ports UI and install.sh must form its real forwarded URL without
# guessing a container/public IP.
if node -e 'const x=require(process.argv[1]); const docker=(x.features||{})["ghcr.io/devcontainers/features/docker-in-docker:2"]; if (!x.privileged || !docker || !x.forwardPorts.includes(8080) || x.portsAttributes["8080"].label !== "Zenith Panel") process.exit(1)' "$PANEL_DIR/.devcontainer/devcontainer.json" >/dev/null 2>&1; then
  ok "Codespaces devcontainer pre-forwards the panel and provisions Docker-in-Docker"
else
  bad "Codespaces devcontainer Docker/port configuration is missing or invalid"
fi
CODESPACES=true CODESPACE_NAME=zenith-test GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN=app.github.dev
export CODESPACES CODESPACE_NAME GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN
cs_url="$(codespaces_panel_url)"
[ "$cs_url" = "https://zenith-test-${PORT}.app.github.dev" ] && ok "installer forms the Codespaces Open-in-Browser URL" || bad "unexpected Codespaces URL: ${cs_url:-<empty>}"
unset CODESPACES CODESPACE_NAME GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN

# values the functions expect from the main flow
NODE_MODE=local
NODE_AGENT_PORT=8443
ALLOC_START=25565
ALLOC_END=25665
SFTP_PORT=2022
NODE_BACKEND=process

secret="$(sed -n 's/^OWNER_SECRET=//p' "$PANEL_DIR/.env")"
# the main flow gets this from ensure_owner_secret(); provide it here so the
# sourced functions can authenticate exactly like they do during a real run.
export OWNER_SECRET="$secret"
count_nodes() {
  curl -s "http://127.0.0.1:${PORT}/api/nodes" -H "x-owner-secret: ${secret}" \
    | tr ',' '\n' | grep -c '"id":"node_\|"id":"local"' || true
}

echo "== installer node provisioning against the panel on :${PORT} =="
n0="$(count_nodes)"
out="$(provision_local_node 2>&1)"; rc=$?
printf '%s\n' "$out" | sed 's/^/     | /'
[ "$rc" -eq 0 ] && ok "provision_local_node exited 0" || bad "provision_local_node exited ${rc}"
case "$out" in
  *"registered with fresh credentials"*) ok "a credential was minted or reused" ;;
  *"existing credentials kept"*)        ok "credentials reused (idempotent re-run)" ;;
esac
# provision_local_node sets NODE_ID inside its own call; in a subshell that
# assignment is lost, so read the id back from the panel (the source of truth).
if [ -z "${NODE_ID:-}" ]; then
  NODE_ID="$(curl -s "http://127.0.0.1:${PORT}/api/nodes" -H "x-owner-secret: ${secret}" | python3 -c '
import json, sys
try:
    payload = json.load(sys.stdin)
except Exception:
    raise SystemExit
nodes = payload.get("nodes", payload) if isinstance(payload, dict) else payload
for node in nodes or []:
    if node.get("id"):
        print(node["id"]); break
' 2>/dev/null)"
fi
[ -n "${NODE_ID:-}" ] && ok "node id read back from the panel: ${NODE_ID}" || bad "no node id available"
export NODE_ID
n1="$(count_nodes)"
[ "$n1" -le $((n0 + 1)) ] && ok "no duplicate node records (${n0} -> ${n1})" || bad "node duplicated (${n0} -> ${n1})"

echo "== health check =="
hout="$(verify_node_health 2>&1)"; hrc=$?
printf '%s\n' "$hout" | sed 's/^/     | /'
[ "$hrc" -eq 0 ] && ok "verify_node_health exited 0" || bad "verify_node_health exited ${hrc}"
case "$hout" in *online*) ok "node marked online only after the checks passed" ;; *) bad "no online verdict printed" ;; esac

echo "== idempotency: two more runs =="
for i in 2 3; do
  out="$(provision_local_node 2>&1)"; rc=$?
  n2="$(count_nodes)"
  [ "$rc" -eq 0 ] && [ "$n2" -le "$n1" ] \
    && ok "run ${i}: exit 0, still ${n2} node record(s)" \
    || bad "run ${i}: exit ${rc}, ${n2} node record(s)"
done

echo "== honest failure reporting =="
node_id="${NODE_ID:-local}"
curl -s -X PATCH "http://127.0.0.1:${PORT}/api/nodes/${node_id}" -H "x-owner-secret: ${secret}" \
  -H 'content-type: application/json' -d '{"backend":"docker"}' >/dev/null 2>&1 || true
curl -s -X POST "http://127.0.0.1:${PORT}/api/nodes/${node_id}/health-check" -H "x-owner-secret: ${secret}" \
  -H 'content-type: application/json' -d '{}' >"$ZENITH_LOG.health" 2>/dev/null || true
python3 - "$ZENITH_LOG.health" <<'PY'
import json, sys
try:
    payload = json.load(open(sys.argv[1]))
except Exception:
    print('  ok   the health check returned a non-JSON body (the error is surfaced, not hidden)')
    raise SystemExit(0)
checks = payload.get('checks') or []
failed = [c for c in checks if c.get('ok') is False]
status = payload.get('status') or (payload.get('node') or {}).get('status')
print(f"  ok   health payload parsed: status={status}, {len(checks)} check(s), {len(failed)} failing")
for c in failed:
    print(f"       - {c.get('name')}: {(c.get('detail') or '')[:90]}")
if failed and status == 'online':
    print(' FAIL  the node is online although checks failed (fake health)')
    raise SystemExit(1)
if not failed:
    print('  ok   the runtime genuinely works here, so no failure was expected either')
PY

# put the node back on the runtime the installer used
curl -s -X PATCH "http://127.0.0.1:${PORT}/api/nodes/${node_id}" -H "x-owner-secret: ${secret}" \
  -H 'content-type: application/json' -d '{"backend":"process"}' >/dev/null 2>&1 || true

echo
if [ "$fails" -eq 0 ]; then echo "installer node checks passed"; else echo "${fails} check(s) FAILED"; fi
exit "$fails"
