#!/usr/bin/env bash
# Full verification run for Zenith Panel.
#
#   bash tests/run.sh                 # fresh temp panel on :8090 + fake docker, all suites
#   PORT=8123 bash tests/run.sh       # pick another port
#   KEEP=1 bash tests/run.sh          # leave the panel running afterwards
#   SKIP_INSTALL=1 bash tests/run.sh  # do not touch node_modules
#
# It never touches your real panel: everything runs in a throwaway directory
# with the fake-docker test double on PATH.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PORT="${PORT:-8090}"
SFTP_PORT="${SFTP_PORT:-2023}"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/zenith-tests-XXXXXX")"
LOG="$TMP/panel.log"
USER_ACC="${ZENITH_USER:-admin@gmail.com}"
PASS_ACC="${ZENITH_PASS:-admin123}"
fails=0
declare -a RESULTS=()

say()  { printf '\n\033[1m%s\033[0m\n' "$*"; }
pass() { printf '  \033[32mok\033[0m   %s\n' "$*"; RESULTS+=("pass  $*"); }
fail() { printf '  \033[31mFAIL\033[0m %s\n' "$*"; fails=$((fails + 1)); RESULTS+=("FAIL  $*"); }

cleanup() {
  if [ -n "${PANEL_PID:-}" ] && [ "${KEEP:-0}" != "1" ]; then
    kill "$PANEL_PID" 2>/dev/null || true
    wait "$PANEL_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

# ------------------------------------------------------------------ deps ----
if [ "${SKIP_INSTALL:-0}" != "1" ]; then
  say "dependencies"
  if [ ! -d node_modules ] || [ ! -e node_modules/express ]; then
    npm install --no-audit --no-fund >"$TMP/npm.log" 2>&1 && pass "npm install (panel dependencies)" || fail "npm install - see $TMP/npm.log"
  else
    pass "panel dependencies already installed"
  fi
  if ! node -e "require.resolve('jsdom')" >/dev/null 2>&1; then
    npm install --no-save --no-audit --no-fund jsdom >"$TMP/npm-jsdom.log" 2>&1 \
      && pass "jsdom installed (page checks)" || fail "jsdom install failed - see $TMP/npm-jsdom.log"
  else
    pass "jsdom already available"
  fi
fi

if [ "$fails" -gt 0 ]; then
  say "aborting: dependencies are missing"
  exit 1
fi

# ------------------------------------------------- pane: fake docker + dirs ----
say "test environment"
export PATH="$(node scripts/fake-docker.js --print-path):$PATH"
if command -v docker >/dev/null 2>&1; then pass "docker CLI on PATH: $(command -v docker)"; else fail "no docker CLI on PATH"; fi
rm -rf "$(node scripts/fake-docker.js --print-path | sed 's#/bin$##')/state/containers" 2>/dev/null || true
mkdir -p "$TMP/data" "$TMP/servers" "$TMP/backups"
pass "throwaway data dir: $TMP"

# ------------------------------------------------------------ start panel ----
say "starting the panel on :$PORT"
PORT="$PORT" DATA_DIR="$TMP/data" SERVER_DATA_DIR="$TMP/servers" BACKUP_DIR="$TMP/backups" \
  SFTP_PORT="$SFTP_PORT" node server.js >"$LOG" 2>&1 &
PANEL_PID=$!

ready="no"
for _ in $(seq 1 40); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/version" >/dev/null 2>&1; then ready="yes"; break; fi
  sleep 0.5
done
if [ "$ready" = "yes" ]; then pass "panel answers on /api/version"; else fail "panel did not start - log:"; tail -20 "$LOG" | sed 's/^/      /'; exit 1; fi

# ------------------------------------------------------------ owner account ----
DATA_DIR="$TMP/data" node scripts/createuser.js --user "$USER_ACC" --pass "$PASS_ACC" --role owner --email "$USER_ACC" >/dev/null 2>&1 \
  && pass "owner account created ($USER_ACC)" || fail "could not create the owner account"

# ------------------------------------------------------------- smoke + UI ----
run_suite() { # run_suite <name> <command...>
  local name="$1"; shift
  say "$name"
  if "$@" >"$TMP/out.txt" 2>&1; then
    tail -3 "$TMP/out.txt" | sed 's/^/  /'
    pass "$name"
  else
    sed 's/^/  /' "$TMP/out.txt" | tail -30
    fail "$name"
  fi
}

# ------------------------------------------------------- server fixture ----
say "server fixture (a real PAPER server the page checks can render)"
TOKEN="$(curl -fsS -X POST "http://127.0.0.1:${PORT}/api/auth/login" -H 'content-type: application/json' \
      -d "{\"username\":\"${USER_ACC}\",\"password\":\"${PASS_ACC}\"}" | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')"
if [ -n "$TOKEN" ]; then
  FIXTURE_ID="$(curl -fsS -X POST "http://127.0.0.1:${PORT}/api/servers" -H "authorization: Bearer $TOKEN" \
    -H 'content-type: application/json' \
    -d '{"name":"Test Bed","serverType":"PAPER","version":"1.21.4","memory":1024,"eulaAccepted":true}' \
    | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')"
  if [ -n "$FIXTURE_ID" ]; then pass "created PAPER fixture (${FIXTURE_ID})"; else fail "could not create the server fixture"; fi
else
  fail "could not log in to create the server fixture"
fi

# the install pipeline (real download) - skipped instead of failed when offline
say "software install pipeline (real Paper download)"
if [ -n "${FIXTURE_ID:-}" ]; then
  curl -fsS -X POST "http://127.0.0.1:${PORT}/api/servers/${FIXTURE_ID}/reinstall" -H "authorization: Bearer $TOKEN" \
    -H 'content-type: application/json' -d '{}' >/dev/null 2>&1 || true
  JAR=""
  for _ in $(seq 1 40); do
    JAR="$(find "$TMP/servers/${FIXTURE_ID}" -maxdepth 1 -name '*.jar' -size +1M 2>/dev/null | head -1)"
    [ -n "$JAR" ] && break
    sleep 3
  done
  if [ -n "$JAR" ]; then
    pass "Paper jar downloaded ($(du -h "$JAR" | cut -f1) at $(basename "$JAR"))"
  else
    RESULTS+=("skip  software install (upstream unreachable?)")
    printf '  \033[33mskip\033[0m software install - no jar after 120s (offline?)\n'
  fi
else
  RESULTS+=("skip  software install (no fixture)")
fi

run_suite "API smoke test (scripts/smoke.js)" \
  node scripts/smoke.js --url "http://127.0.0.1:${PORT}" --user "$USER_ACC" --pass "$PASS_ACC"
run_suite "headless UI test (scripts/uitest.js)" \
  node scripts/uitest.js --url "http://127.0.0.1:${PORT}" --user "$USER_ACC" --pass "$PASS_ACC"
run_suite "page checks: every panel page (tests/pages-panel.js)" \
  node tests/pages-panel.js --url "http://127.0.0.1:${PORT}" --user "$USER_ACC" --pass "$PASS_ACC"
run_suite "page checks: servers + console theme (tests/pages-theme.js)" \
  node tests/pages-theme.js --url "http://127.0.0.1:${PORT}" --user "$USER_ACC" --pass "$PASS_ACC"
run_suite "page checks: mods/plugins + components (tests/pages-mods-components.js)" \
  node tests/pages-mods-components.js --url "http://127.0.0.1:${PORT}" --user "$USER_ACC" --pass "$PASS_ACC"

run_suite "transfer size / caching (tests/compression.js)" \
  node tests/compression.js --url "http://127.0.0.1:${PORT}"

run_suite "release footprint under budget (tests/size-check.js)" \
  node tests/size-check.js

run_suite "per-server runtime, process | docker (tests/runtime-api.js)" \
  node tests/runtime-api.js --url "http://127.0.0.1:${PORT}" --user "$USER_ACC" --pass "$PASS_ACC" --servers-dir "$TMP/servers"

# ------------------------------------------------- installer node functions ----
say "installer node provisioning (tests/installer-node-check.sh)"
if bash tests/installer-node-check.sh "$PORT" >"$TMP/installer.txt" 2>&1; then
  grep -E '^  (ok|FAIL)' "$TMP/installer.txt" | sed 's/^/  /' | head -20
  pass "installer node check"
else
  sed 's/^/  /' "$TMP/installer.txt" | tail -30
  fail "installer node check"
fi

# ------------------------------------------------------------------ summary ----
say "summary"
for line in "${RESULTS[@]}"; do printf '  %s\n' "$line"; done
echo
if [ "$fails" -eq 0 ]; then
  printf '\033[32mevery suite passed\033[0m  (panel log: %s)\n' "$LOG"
else
  printf '\033[31m%s suite(s) failed\033[0m  (panel log: %s)\n' "$fails" "$LOG"
fi
[ "${KEEP:-0}" = "1" ] && echo "panel left running on :$PORT (pid $PANEL_PID) - kill $PANEL_PID when done"
exit "$fails"
