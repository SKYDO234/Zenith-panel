# Tests

Everything in this folder runs against a **real panel process** (a throwaway one,
started by `run.sh`), never against mocks of the panel's own API. The only test
double is `scripts/fake-docker.js`, and it only replaces the Docker CLI, not the
panel.

```bash
bash tests/run.sh                 # everything: deps, fake docker, panel, all suites
PORT=8123 bash tests/run.sh       # another port
KEEP=1 bash tests/run.sh          # leave the test panel running afterwards
SKIP_INSTALL=1 bash tests/run.sh  # do not touch node_modules
```

`run.sh` prints a per-suite summary and exits non-zero if anything failed. It
cleans up its temp directory and the panel process unless `KEEP=1`.

## What runs

| Suite | File | What it proves |
| --- | --- | --- |
| API smoke | `../scripts/smoke.js` | ~60 checks over the whole public API, the websocket console handshake, auth, nodes, auto-register idempotency and every static asset |
| Headless UI | `../scripts/uitest.js` | every page **and every server/admin tab** renders in jsdom, real buttons clicked, zero JS errors |
| Panel pages | `pages-panel.js` | each page renders, plus per-page contracts (nodes runtime badges, account photo/password/tour, all admin tabs, login page leaks no credentials) |
| Servers + console theme | `pages-theme.js` | the reworked screens: two-tier responsive server drawer, 4-button power hero, terminal CLI, four real-time stat cards, 3 charts, banner cards, view switcher, inset tiles |
| Mods / plugins + components | `pages-mods-components.js` | the Plugins/Mods split (tab visibility, id scoping, type-scoped API) and every shared component from `public/js/components.js` |
| Transfer size | `compression.js` | every text asset is really brotli/gzip encoded over the wire, cache headers, 304 revalidation and Range pass-through |
| Release footprint | `size-check.js` | shipped tree + archive under 25 MB, no runtime folder or JRE inside the project |
| Per-server runtime | `runtime-api.js` | a server really runs **inside a container** (asserted through the docker CLI), the runtime switch is refused while running, invalid images are rejected |
| Installer node | `installer-node-check.sh` | the real `install.sh` functions: registration, credential handling, health check gating, 3× idempotency, honest failure output |

Each suite can be run on its own against any panel:

```bash
node tests/pages-theme.js --url http://localhost:8080 --user admin@gmail.com --pass yourpass
bash tests/installer-node-check.sh 8080          # panel port
node tests/runtime-api.js --url … --servers-dir /path/to/servers
```

`npm run verify` is `bash tests/run.sh`; individual suites have aliases
(`npm run verify:api`, `verify:ui`, `verify:pages`, `verify:theme`,
`verify:mods`, `verify:runtime`, `verify:installer`).

## Requirements

* **jsdom** - a dev dependency (`npm install`). The panel itself never needs it:
  `install.sh` installs with `--omit=dev`.
* **A Docker CLI on `PATH`.** On a machine without Docker, `run.sh` puts the test
  double in front: `PATH="$(node scripts/fake-docker.js --print-path):$PATH"`.
  The runtime check then verifies real container semantics (create/start/inspect
  with the per-server image, published ports, bind mount) without a daemon.
* **Network** for the "software install pipeline" step (real Paper download,
  ~50 MB). Without it that step is reported as *skipped*, not failed.

## Notes for future work

* `tests/lib/harness.js` is the shared jsdom harness: `H.render(page, {script, token, serverId})`
  loads `app.js` + `components.js` + the page script and returns `{ window, document, errors, text }`.
  Use it instead of writing another bespoke renderer.
* Timings: a full `bash tests/run.sh` takes ~2.5 minutes on a 2-core box
  (most of it the real jar download and the ~50 s UI suite).
* The page suites need at least one server; `run.sh` creates a PAPER fixture
  first and asserts the download really produced a jar.
