#!/usr/bin/env node
'use strict';
/**
 * Page check: the shared components (public/js/components.js) and the
 * Plugins/Mods manager on the server page.
 *
 *   node tests/pages-mods-components.js --url http://localhost:8090 --user admin --pass secret
 */
const H = require('./lib/harness');

(async () => {
  const token = await H.login();
  const list = await H.servers(token);
  const paper = list.find((s) => /PAPER|SPIGOT|PURPUR|FOLIA/i.test(s.serverType)) || list[0];
  const modded = list.find((s) => /FABRIC|QUILT|FORGE|NEOFORGE/i.test(s.serverType));
  if (!paper) { console.error('this check needs at least one server - create one first'); process.exit(2); }

  H.begin('mods / plugins tabs + shared components');

  /* ---------------------- plugin software: Plugins tab ---------------------- */
  {
    const { window, document, errors } = await H.render('server.html', { script: 'server.js', token, serverId: paper.id, wait: 6500 });
    const tabs = [...document.querySelectorAll('#serverTabs button')].map((b) => b.dataset.tab);
    const isModded = /FABRIC|QUILT|FORGE|NEOFORGE/i.test(paper.serverType);
    H.check('plugins tab shown for plugin software', isModded ? !tabs.includes('plugins') : tabs.includes('plugins'), tabs.join(','));
    H.check('mods tab follows the loader', isModded ? tabs.includes('mods') : !tabs.includes('mods'), tabs.join(','));

    const key = isModded ? 'mods' : 'plugins';
    const suffix = isModded ? 'mod' : 'plugin';
    const btn = document.querySelector(`#serverTabs button[data-tab="${key}"]`);
    if (btn) {
      btn.click();
      await H.sleep(2600);
      H.check(`${key} manager renders its own element ids`, Boolean(document.getElementById(`installedList-${suffix}`)));
      H.check(`${key} manager has the search + build-picker wiring`, Boolean(document.getElementById(`modSearch-${suffix}`) && document.getElementById(`modSearchBtn-${suffix}`)));
      H.check(`${key} manager shows the Installed / Browse tabs`, document.querySelectorAll('[data-ptab]').length === 2);
      H.check(`no duplicate ids across ${key} manager instances`, document.querySelectorAll(`[id="installedList-${suffix}"]`).length === 1);
    } else {
      H.check(`${key} tab exists`, false);
    }
    H.check('no JS errors on the server page', errors.length === 0, errors.slice(0, 2).join(' | '));
    void window;
  }

  /* ------------------- modded software, if one exists ---------------------- */
  if (modded) {
    const { document, errors } = await H.render('server.html', { script: 'server.js', token, serverId: modded.id, wait: 6500 });
    const tabs = [...document.querySelectorAll('#serverTabs button')].map((b) => b.dataset.tab);
    H.check(`modded server (${modded.serverType}): mods tab present`, tabs.includes('mods'), tabs.join(','));
    H.check(`modded server (${modded.serverType}): plugins tab hidden`, !tabs.includes('plugins'));
    H.check('modded server: no JS errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  }

  /* ----------------------------- components -------------------------------- */
  {
    const { window, document, errors } = await H.render('dashboard.html', { script: 'dashboard.js', token, wait: 2500 });
    H.check('search + notification hosts are in the topbar', Boolean(document.getElementById('gsBtn') && document.getElementById('notifBtn')));
    H.check('notification badge element exists', Boolean(document.getElementById('notifBadge')));
    H.check('the topbar hosts are not duplicated', document.querySelectorAll('#gsBtn').length === 1 && document.querySelectorAll('#notifBtn').length === 1);

    const gs = document.getElementById('gsBtn');
    if (gs) {
      gs.click();
      await H.sleep(600);
      const input = document.getElementById('gsInput');
      H.check('global search modal opens', Boolean(input));
      if (input) {
        input.value = 'servers';
        input.dispatchEvent(new window.Event('input'));
        await H.sleep(300);
        H.check('global search returns hits', document.querySelectorAll('#gsResults .gs-item').length >= 1);
        const closer = document.querySelector('.overlay.open [data-close]');
        if (closer) closer.click();
        await H.sleep(200);
      }
    }

    window.Tutorial.start(0);
    await H.sleep(300);
    H.check('tutorial overlay renders a step', Boolean(document.querySelector('#tourBox .tour-card')));
    window.Tutorial.stop();
    H.check('components are exported for the pages', Boolean(window.Cropper && window.ModrinthVersionModal && window.searchableDropdown && window.versionGroups && window.Loading));
    H.check('versionGroups splits stable / snapshots', (() => {
      const groups = window.versionGroups(['1.21.4', '1.21.5-pre2'], '1.21.4');
      return groups.length === 2 && groups[0].items[0].hint === 'current';
    })());
    H.check('no JS errors while using the components', errors.length === 0, errors.slice(0, 2).join(' | '));
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
