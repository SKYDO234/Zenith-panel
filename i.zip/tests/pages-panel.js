#!/usr/bin/env node
'use strict';
/**
 * Page check: every panel page renders against a live API without JS errors,
 * plus the per-page contracts that matter (nodes page runtime badges, account
 * page avatar controls, admin tabs, api keys page, register page).
 *
 *   node tests/pages-panel.js --url http://localhost:8090 --user admin --pass secret
 */
const fs = require('fs');
const path = require('path');
const H = require('./lib/harness');

const PAGES = [
  { page: 'dashboard.html', script: 'dashboard.js', want: /Your servers|Your server list|private server fleet/i },
  { page: 'analytics.html', script: 'analytics.js', want: /CPU average|charts/i },
  { page: 'servers.html', script: 'servers.js', want: /server/i },
  { page: 'nodes.html', script: 'nodes.js', want: /node/i },
  { page: 'allocations.html', script: 'allocations.js', want: /Ports tracked|port/i },
  { page: 'account.html', script: 'account.js', want: /API keys/i },
  { page: 'apikeys.html', script: 'apikeys.js', want: /API key|Your keys/i },
  { page: 'admin.html', script: 'admin.js', want: /Panel users|Panel settings/i },
];

(async () => {
  const token = await H.login();
  H.begin('every panel page renders');

  const sharedCss = fs.readFileSync(path.join(__dirname, '..', 'public', 'css', 'app.css'), 'utf8');
  H.check('shared UI stylesheet explicitly keeps text horizontal', /writing-mode:\s*horizontal-tb\s*!important/.test(sharedCss) && /text-orientation:\s*mixed\s*!important/.test(sharedCss));
  H.check('label/value metadata is laid out as rows, never one shrinking flex line', /\.kv\s*\{\s*display:\s*grid/.test(sharedCss) && /@container\s+panel-main/.test(sharedCss));
  H.check('global background uses a real fixed layer rather than a fragile body pseudo-element', /#panel-global-backdrop\s*\{[^}]*position:\s*fixed[\s\S]*?z-index:\s*0/.test(sharedCss));
  H.check('background-aware pages use translucent, readable glass surfaces', /html\[data-panel-background=\"true\"\]\s+\.card/.test(sharedCss) && /backdrop-filter:\s*blur/.test(sharedCss));

  const publicPanel = await H.api('/api/auth/panel');
  H.check('public auth metadata exposes provider availability without secrets', publicPanel.status === 200
    && publicPanel.json && publicPanel.json.authProviders && publicPanel.json.authProviders.google.enabled === false
    && publicPanel.json.authProviders.discord.enabled === false
    && !Object.prototype.hasOwnProperty.call(publicPanel.json, 'discordOAuthClientSecret'));
  const unconfiguredGoogle = await H.api('/api/auth/firebase/google', { method: 'POST', body: { idToken: 'not-a-token' } });
  H.check('unconfigured Firebase login returns an honest setup error', unconfiguredGoogle.status === 503 && /not configured/i.test((unconfiguredGoogle.json || {}).error || ''), (unconfiguredGoogle.json || {}).error || `HTTP ${unconfiguredGoogle.status}`);
  const invalidOAuthExchange = await H.api('/api/auth/oauth/complete', { method: 'POST', body: { code: 'expired-test-code' } });
  H.check('Discord browser exchanges are one-time and reject unknown codes', invalidOAuthExchange.status === 400, `HTTP ${invalidOAuthExchange.status}`);
  const privateSettings = await H.api('/api/settings', { token });
  H.check('settings API reports only whether a Discord OAuth secret exists', privateSettings.status === 200
    && privateSettings.json && privateSettings.json.settings && privateSettings.json.settings.discordOAuthClientSecret === undefined
    && privateSettings.json.settings.discordOAuthClientSecretSet === false);

  // Provider switches are configuration, not cosmetic: incomplete credentials
  // must be rejected, and a complete saved configuration must become publicly
  // available without exposing the Discord secret.
  const incompleteGoogle = await H.api('/api/settings', { method: 'PATCH', token, body: { firebaseGoogleEnabled: true } });
  H.check('provider enablement explains missing Firebase credentials', incompleteGoogle.status === 400
    && /Firebase Web API key.*auth domain.*project ID.*app ID/i.test((incompleteGoogle.json || {}).error || ''), (incompleteGoogle.json || {}).error || `HTTP ${incompleteGoogle.status}`);
  const configuredProviders = await H.api('/api/settings', {
    method: 'PATCH', token,
    body: {
      panelUrl: 'https://panel.example.test', oauthAllowRegistration: true,
      firebaseGoogleEnabled: true, firebaseApiKey: 'AIza-provider-regression-key', firebaseAuthDomain: 'panel.example.test', firebaseProjectId: 'panel-provider-test', firebaseAppId: '1:123456:web:provider-test',
      discordOAuthEnabled: true, discordOAuthClientId: '123456789012345678', discordOAuthClientSecret: 'provider-regression-secret',
    },
  });
  const enabledProviders = await H.api('/api/auth/panel');
  H.check('complete Google and Discord settings persist and publish provider availability', configuredProviders.status === 200
    && enabledProviders.status === 200 && enabledProviders.json.authProviders.google.enabled === true && enabledProviders.json.authProviders.discord.enabled === true
    && !Object.prototype.hasOwnProperty.call(enabledProviders.json, 'discordOAuthClientSecret'));
  const configuredSettings = await H.api('/api/settings', { token });
  H.check('saved public panel URL is normalised and Discord secret remains redacted', configuredSettings.status === 200
    && configuredSettings.json.panelUrl === 'https://panel.example.test' && configuredSettings.json.settings.discordOAuthClientSecret === undefined
    && configuredSettings.json.settings.discordOAuthClientSecretSet === true);
  await H.api('/api/settings', { method: 'PATCH', token, body: {
    panelUrl: '', oauthAllowRegistration: false, firebaseGoogleEnabled: false, firebaseApiKey: '', firebaseAuthDomain: '', firebaseProjectId: '', firebaseAppId: '',
    discordOAuthEnabled: false, discordOAuthClientId: '', discordOAuthClientSecret: '',
  } });

  for (const spec of PAGES) {
    const { errors, text, document } = await H.render(spec.page, { script: spec.script, token, wait: 2600 });
    H.check(`${spec.page}: renders`, spec.want.test(text()), text().slice(0, 80));
    H.check(`${spec.page}: no JS errors`, errors.length === 0, errors.slice(0, 2).join(' | '));
    H.check(`${spec.page}: mounts the shared global background layer`, Boolean(document.getElementById('panel-global-backdrop')));
    if (spec.page === 'dashboard.html' && typeof document.defaultView.applyAppearance === 'function') {
      document.defaultView.applyAppearance({ panelBackground: 'data:image/png;base64,AA==', panelBackgroundOpacity: 57 });
      const backdrop = document.getElementById('panel-global-backdrop');
      H.check('appearance: a selected background is visible above document paint and below the app',
        document.documentElement.dataset.panelBackground === 'true' && Boolean(backdrop && !backdrop.hidden && backdrop.style.backgroundImage.includes('data:image/png;base64,AA==')));
      document.defaultView.applyAppearance({ panelBackground: '', panelBackgroundOpacity: 100 });
    }
    if (spec.page === 'nodes.html') {
      H.check('nodes page: runtime per node is explicit', /containers|processes/i.test(text()));
      H.check('nodes page: health check control for admins', Boolean(document.querySelector('[data-health-node]')) || /Health check/i.test(text()));
    }
    if (spec.page === 'apikeys.html') {
      const newKey = document.getElementById('newKey');
      H.check('API keys page: Create key control is live', Boolean(newKey));
      if (newKey) {
        const name = `page-test-${Date.now()}`;
        newKey.click();
        await H.sleep(40);
        const nameField = document.getElementById('keyName');
        const create = document.getElementById('doKey');
        if (nameField) nameField.value = name;
        if (create) create.click();
        await H.sleep(220);
        const reveal = document.querySelector('.overlay .code');
        const raw = reveal && reveal.textContent.trim();
        H.check('API keys page: creates and reveals a key exactly once', Boolean(raw && /^zen_/.test(raw)), raw ? raw.slice(0, 12) : 'no key revealed');
        const closeReveal = document.querySelector('.overlay .close');
        if (closeReveal) closeReveal.click();
        await H.sleep(170);
        const revoke = document.querySelector('#keysContent [data-revoke]');
        if (revoke) revoke.click();
        await H.sleep(40);
        const confirm = document.querySelector('.overlay [data-ok]');
        if (confirm) confirm.click();
        await H.sleep(220);
        H.check('API keys page: revokes the newly created key', /revoked/i.test(document.getElementById('keysContent').textContent));
      }
    }
    if (spec.page === 'account.html') {
      H.check('account page: profile photo controls', Boolean(document.getElementById('uploadAvatar')));
      H.check('account page: password change form', Boolean(document.getElementById('changePassword')));
      H.check('account page: tutorial replay button', Boolean(document.getElementById('replayTutorial')) || /Tutorial/i.test(text()));
    }
    if (spec.page === 'admin.html') {
      for (const tab of ['users', 'servers', 'settings', 'integrations', 'allocations', 'java', 'activity']) {
        const btn = document.querySelector(`[data-atab="${tab}"]`);
        if (!btn) { H.check(`admin: tab ${tab} exists`, false); continue; }
        btn.click();
        await H.sleep(tab === 'integrations' ? 2000 : 1300);
        H.check(`admin: tab ${tab} renders`, document.body.textContent.replace(/\s+/g, ' ').length > 200);
        if (tab === 'settings') {
          const opacity = document.getElementById('setBackgroundOpacity');
          H.check('admin: panel-wide background upload control renders', Boolean(document.getElementById('choosePanelBackground')) && Boolean(document.getElementById('resetPanelBackground')));
          H.check('admin: background opacity control is bounded 0–100', Boolean(opacity && opacity.min === '0' && opacity.max === '100'));
          H.check('admin: identity provider settings expose Firebase, Discord, and OAuth signup policy', Boolean(document.getElementById('setFirebaseGoogle') && document.getElementById('setFirebaseApiKey') && document.getElementById('setDiscordOAuth') && document.getElementById('setDiscordOAuthClientSecret') && document.getElementById('setOAuthRegistration')));
          H.check('admin: identity switches are clickable labels with an explicit save action and public URL field', Boolean(document.getElementById('setFirebaseGoogle')?.closest('label.switch') && document.getElementById('setDiscordOAuth')?.closest('label.switch') && document.getElementById('saveIdentityProviders') && document.getElementById('setPanelUrl')));
          H.check('admin: Discord OAuth secret is an obscured entry field', document.getElementById('setDiscordOAuthClientSecret')?.type === 'password');
        }
      }
    }
  }

  /* register page: public, explains the closed-door policy */
  {
    const { errors, text, document } = await H.render('register.html', { script: 'register.js', token: '', wait: 1500 });
    H.check('register.html: shows the closed form or the notice', /Registration is closed|Create account/i.test(text()));
    H.check('register.html: no JS errors', errors.length === 0, errors.slice(0, 2).join(' | '));
    H.check('register.html: mounts the shared global background layer', Boolean(document && document.getElementById('panel-global-backdrop')));
  }

  /* the login page must never print the default credentials */
  {
    const { document } = await H.render('index.html', { script: 'login.js', token: '', wait: 1500 });
    const html = document.documentElement.outerHTML;
    H.check('login page: usable without credentials in the markup',
      !/admin123/.test(html) && !/admin@gmail\.com/.test(html));
    H.check('login page: mounts the shared global background layer', Boolean(document.getElementById('panel-global-backdrop')));
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
