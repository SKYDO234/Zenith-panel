#!/usr/bin/env node
'use strict';
/**
 * Page check: every panel page renders against a live API without JS errors,
 * plus the per-page contracts that matter (nodes page runtime badges, account
 * page avatar controls, admin tabs, api keys page, register page).
 *
 *   node tests/pages-panel.js --url http://localhost:8090 --user admin --pass secret
 */
const H = require('./lib/harness');

const PAGES = [
  { page: 'dashboard.html', script: 'dashboard.js', want: /Host resources|live output/i },
  { page: 'analytics.html', script: 'analytics.js', want: /CPU average|charts/i },
  { page: 'servers.html', script: 'servers.js', want: /server/i },
  { page: 'nodes.html', script: 'nodes.js', want: /node/i },
  { page: 'allocations.html', script: 'allocations.js', want: /Ports tracked|port/i },
  { page: 'account.html', script: 'account.js', want: /API keys/i },
  { page: 'apikeys.html', script: 'apikeys.js', want: /API key|Your keys/i },
  { page: 'admin.html', script: 'admin.js', want: /Panel users|Panel settings/i },
];

(async () => {
  const token = await H.login();
  H.begin('every panel page renders');

  for (const spec of PAGES) {
    const { errors, text, document } = await H.render(spec.page, { script: spec.script, token, wait: 2600 });
    H.check(`${spec.page}: renders`, spec.want.test(text()), text().slice(0, 80));
    H.check(`${spec.page}: no JS errors`, errors.length === 0, errors.slice(0, 2).join(' | '));
    if (spec.page === 'nodes.html') {
      H.check('nodes page: runtime per node is explicit', /containers|processes/i.test(text()));
      H.check('nodes page: health check control for admins', Boolean(document.querySelector('[data-health-node]')) || /Health check/i.test(text()));
    }
    if (spec.page === 'account.html') {
      H.check('account page: profile photo controls', Boolean(document.getElementById('uploadAvatar')));
      H.check('account page: password change form', Boolean(document.getElementById('changePassword')));
      H.check('account page: tutorial replay button', Boolean(document.getElementById('replayTutorial')) || /Tutorial/i.test(text()));
    }
    if (spec.page === 'admin.html') {
      for (const tab of ['users', 'servers', 'settings', 'integrations', 'allocations', 'java', 'activity']) {
        const btn = document.querySelector(`[data-atab="${tab}"]`);
        if (!btn) { H.check(`admin: tab ${tab} exists`, false); continue; }
        btn.click();
        await H.sleep(tab === 'integrations' ? 2000 : 1300);
        H.check(`admin: tab ${tab} renders`, document.body.textContent.replace(/\s+/g, ' ').length > 200);
      }
    }
  }

  /* register page: public, explains the closed-door policy */
  {
    const { errors, text } = await H.render('register.html', { script: 'register.js', token: '', wait: 1500 });
    H.check('register.html: shows the closed form or the notice', /Registration is closed|Create account/i.test(text()));
    H.check('register.html: no JS errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  }

  /* the login page must never print the default credentials */
  {
    const { document } = await H.render('index.html', { script: 'login.js', token: '', wait: 1500 });
    const html = document.documentElement.outerHTML;
    H.check('login page: usable without credentials in the markup',
      !/admin123/.test(html) && !/admin@gmail\.com/.test(html));
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
