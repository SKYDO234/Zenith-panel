#!/usr/bin/env node
'use strict';
/**
 * Transfer-size checks against a running panel (tests/run.sh runs this).
 *
 *   node tests/compression.js --url http://127.0.0.1:8090
 *
 * Asserts what src/middleware/compress.js promises:
 *   - text assets come back brotli-encoded when the client accepts br, gzip if not
 *   - the encoded body really is smaller than the file on disk (the 64 KB chunk
 *     bug that once shipped /js/server.js uncompressed would fail here)
 *   - API responses are never cached, assets are cacheable but revalidated
 *   - small files, 304s and Range/206s are passed through untouched
 */
const { flag, BASE } = (() => {
  const args = process.argv.slice(2);
  const get = (name, fallback) => {
    const i = args.indexOf(`--${name}`);
    if (i !== -1 && args[i + 1]) return args[i + 1];
    const eq = args.find((a) => a.startsWith(`--${name}=`));
    return eq ? eq.split('=').slice(1).join('=') : fallback;
  };
  return { flag: get, BASE: get('url', process.env.ZENITH_URL || 'http://localhost:8080').replace(/\/$/, '') };
})();

const fs = require('fs');
const path = require('path');
const http = require('http');
const { URL } = require('url');

const PUB = path.join(__dirname, '..', 'public');
let failed = 0;
let passed = 0;
const check = (label, ok, extra = '') => {
  if (ok) { passed += 1; console.log(`  ok   ${label}${extra ? `  (${extra})` : ''}`); } else { failed += 1; console.log(` FAIL  ${label}${extra ? `  (${extra})` : ''}`); }
};
const kb = (bytes) => `${(bytes / 1024).toFixed(1)} KB`;
const pct = (a, b) => `${Math.round((1 - a / b) * 100)}%`;

// Raw http client on purpose: Node's fetch (undici) transparently decompresses
// gzip/br and strips Content-Encoding, which would make every compression
// assertion below meaningless. We need the bytes that actually cross the wire.
function get(pathname, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${BASE}${pathname}`);
    const req = http.request({
      hostname: url.hostname, port: url.port, path: url.pathname + url.search,
      method: 'GET', headers: { 'accept-encoding': 'identity', ...headers },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({
        status: res.statusCode,
        headers: {
          get: (name) => {
            const value = res.headers[String(name).toLowerCase()];
            return Array.isArray(value) ? value.join(', ') : (value === undefined ? null : value);
          },
        },
        body: Buffer.concat(chunks),
      }));
    });
    req.on('error', reject);
    req.end();
  });
}

const ASSETS = ['/css/app.css', '/js/app.js', '/js/components.js', '/js/server.js', '/js/servers.js', '/js/nodes.js'];

(async () => {
  console.log('\ntransfer size / caching (tests/compression.js)');

  // --- brotli on every text asset, and actually smaller than the file on disk
  let plainTotal = 0;
  let brTotal = 0;
  for (const asset of ASSETS) {
    const file = path.join(PUB, asset.replace(/^\//, ''));
    if (!fs.existsSync(file)) { check(`${asset} exists on disk`, false); continue; }
    const disk = fs.statSync(file).size;

    const plain = await get(asset, { 'accept-encoding': 'identity' });
    const br = await get(asset, { 'accept-encoding': 'br' });
    const gzip = await get(asset, { 'accept-encoding': 'gzip' });

    plainTotal += plain.body.length;
    brTotal += br.body.length;

    check(`${asset} 200 in every encoding`,
      plain.status === 200 && br.status === 200 && gzip.status === 200,
      `${plain.status}/${br.status}/${gzip.status}`);
    check(`${asset} brotli`,
      br.headers.get('content-encoding') === 'br' && br.body.length < disk,
      `${kb(disk)} -> ${kb(br.body.length)} (${pct(br.body.length, disk)})`);
    check(`${asset} gzip fallback`,
      gzip.headers.get('content-encoding') === 'gzip' && gzip.body.length < disk,
      `${kb(gzip.body.length)}`);
    check(`${asset} identity is untouched`,
      !plain.headers.get('content-encoding') && plain.body.length === disk,
      `${kb(plain.body.length)}`);
    check(`${asset} Vary: Accept-Encoding`, /accept-encoding/i.test(br.headers.get('vary') || ''),
      br.headers.get('vary') || 'missing');
    check(`${asset} cacheable but revalidated`,
      /public/.test(br.headers.get('cache-control') || '') && /max-age=3600/.test(br.headers.get('cache-control') || ''),
      br.headers.get('cache-control'));
  }
  check('total first-load saving > 60 %', brTotal < plainTotal * 0.4,
    `${kb(plainTotal)} -> ${kb(brTotal)} (${pct(brTotal, plainTotal)})`);

  // --- the whole-file case that used to break at 64 KB (express.static chunks)
  const big = await get('/js/server.js', { 'accept-encoding': 'br' });
  check('/js/server.js (multi-chunk file) is fully encoded',
    big.headers.get('content-encoding') === 'br' && big.body.length > 0 && big.body.length < fs.statSync(path.join(PUB, 'js/server.js')).size * 0.6,
    `${kb(big.body.length)}`);

  // --- small text stays uncompressed
  const html = await get('/dashboard.html', { 'accept-encoding': 'br' });
  check('dashboard.html (981 B, under the 1 KB threshold) not encoded',
    html.status === 200 && !html.headers.get('content-encoding'),
    html.headers.get('content-encoding') || 'identity');

  // --- API responses are never cached
  const api = await get('/api/version', { 'accept-encoding': 'br' });
  check('/api/version answers', api.status === 200);
  check('/api/version is no-store', api.headers.get('cache-control') === 'no-store',
    api.headers.get('cache-control'));

  // --- conditional requests still work
  const etag = html.headers.get('etag');
  if (etag) {
    const revalidated = await get('/dashboard.html', { 'if-none-match': etag });
    check('If-None-Match gives 304', revalidated.status === 304, `${revalidated.status}`);
    check('304 carries no body and is not encoded',
      revalidated.body.length === 0 && !revalidated.headers.get('content-encoding'));
  } else {
    check('dashboard.html has an ETag', false);
  }

  // --- range requests are passed through
  const ranged = await get('/js/server.js', { range: 'bytes=0-1023', 'accept-encoding': 'br' });
  check('Range request gives 206 with exactly 1024 bytes',
    ranged.status === 206 && ranged.body.length === 1024,
    `${ranged.status} / ${ranged.body.length} B`);
  check('206 is never re-encoded', !ranged.headers.get('content-encoding'));

  console.log(failed ? `\n${failed} check(s) FAILED, ${passed} passed` : `\n${passed} checks passed - transfer size / caching`);
  process.exit(failed ? 1 : 0);
})().catch((err) => { console.error('compression suite failed:', err.message); process.exit(1); });
