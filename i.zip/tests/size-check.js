#!/usr/bin/env node
'use strict';
/**
 * Footprint guard: keeps the panel small.
 *
 *   node tests/size-check.js            # human report + pass/fail against 25 MB
 *   node tests/size-check.js --budget 10
 *
 * "The panel" is the code that ships (see scripts/package.js). Runtime folders -
 * node_modules, data/, servers/, backups/, logs/, dist/ - and the design
 * references in uploads/ are measured separately: they are either regenerable or
 * belong to you, and a single managed JRE (50-160 MB) must never count against
 * the panel size, which is why JAVA_DIR points outside the project folder.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const argv = process.argv.slice(2);
const budgetArg = argv.indexOf('--budget') !== -1 ? Number(argv[argv.indexOf('--budget') + 1]) : 25;
const BUDGET = (Number.isFinite(budgetArg) ? budgetArg : 25) * 1024 * 1024;

const SHIPPED = ['server.js', 'install.sh', 'uninstall.sh', 'package.json', 'package-lock.json',
  'README.md', 'FILES.md', 'LICENSE', '.env.example', '.gitignore', 'Dockerfile',
  'docker-compose.yml', 'ecosystem.config.cjs', 'src', 'public', 'scripts', 'docs', 'tests', 'preview'];
const RUNTIME = ['node_modules', 'data', 'servers', 'backups', 'logs', 'dist', 'uploads'];

const human = (bytes) => (bytes < 1024 ? `${bytes} B`
  : bytes < 1048576 ? `${(bytes / 1024).toFixed(1)} KB`
    : `${(bytes / 1048576).toFixed(2)} MB`);

function sizeOf(target) {
  let st;
  try { st = fs.statSync(target); } catch { return 0; }
  if (st.isFile()) return st.size;
  let total = 0;
  for (const entry of fs.readdirSync(target, { withFileTypes: true })) total += sizeOf(path.join(target, entry.name));
  return total;
}

function countFiles(target) {
  let st;
  try { st = fs.statSync(target); } catch { return 0; }
  if (st.isFile()) return 1;
  let total = 0;
  for (const entry of fs.readdirSync(target, { withFileTypes: true })) total += countFiles(path.join(target, entry.name));
  return total;
}

let fails = 0;
const check = (label, ok, detail = '') => {
  console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${label}${detail ? `  (${detail})` : ''}`);
  if (!ok) fails += 1;
};

console.log(`\npanel footprint (budget ${human(BUDGET)})\n`);

const shipped = SHIPPED.map((entry) => ({ entry, bytes: sizeOf(path.join(ROOT, entry)), files: countFiles(path.join(ROOT, entry)) }));
shipped.sort((a, b) => b.bytes - a.bytes);
const shippedBytes = shipped.reduce((a, s) => a + s.bytes, 0);
const shippedFiles = shipped.reduce((a, s) => a + s.files, 0);

console.log('  shipped tree, biggest first:');
for (const item of shipped) {
  if (!item.bytes) continue;
  console.log(`    ${item.entry.padEnd(22)} ${human(item.bytes).padStart(9)}  ${String(item.files).padStart(4)} file(s)`);
}
console.log(`    ${'TOTAL'.padEnd(22)} ${human(shippedBytes).padStart(9)}  ${String(shippedFiles).padStart(4)} file(s)\n`);

check('shipped tree is under the budget', shippedBytes <= BUDGET, `${human(shippedBytes)} of ${human(BUDGET)}`);

// the runtime folders must not hide inside the shipped ones
const leaks = RUNTIME.filter((entry) => SHIPPED.some((s) => s === entry));
check('no runtime folder is part of the shipped tree', leaks.length === 0, leaks.join(', '));

// data/java must never grow to JRE size inside the project
const javaDir = path.join(ROOT, 'data', 'java');
const javaBytes = sizeOf(javaDir);
check('data/java holds no downloaded runtime', javaBytes < 5 * 1024 * 1024, human(javaBytes));

// the archive, if one was built
const distDir = path.join(ROOT, 'dist');
let archiveBytes = 0;
let archiveName = '';
if (fs.existsSync(distDir)) {
  for (const file of fs.readdirSync(distDir)) {
    const bytes = fs.statSync(path.join(distDir, file)).size;
    if (bytes > archiveBytes) { archiveBytes = bytes; archiveName = file; }
  }
}
if (archiveBytes) {
  check(`release archive ${archiveName} is under the budget`, archiveBytes <= BUDGET, human(archiveBytes));
} else {
  console.log('  --   no dist/ archive yet (node scripts/package.js builds one)');
}

// the runtime folders, for context only
console.log('\n  runtime folders (not the panel, safe to delete / regenerate):');
for (const entry of RUNTIME) {
  const bytes = sizeOf(path.join(ROOT, entry));
  if (!bytes) continue;
  const note = { 'node_modules': 'npm install', data: 'your accounts, servers and runtimes',
    servers: 'your Minecraft servers', backups: 'your backup archives', logs: 'panel logs',
    dist: 'release archives', uploads: 'your design references' }[entry] || '';
  console.log(`    ${entry.padEnd(22)} ${human(bytes).padStart(9)}   ${note}`);
}

console.log(fails ? `\n${fails} footprint check(s) FAILED\n` : '\nfootprint OK\n');
process.exit(fails ? 1 : 0);
