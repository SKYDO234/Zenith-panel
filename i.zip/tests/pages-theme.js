#!/usr/bin/env node
'use strict';
/**
 * Page check: the reworked server page (two-tier navigation, power banner,
 * live console, real-time stat cards, three charts) and the reworked servers
 * list (banner cards, view switcher, inset tiles).
 *
 *   node tests/pages-theme.js --url http://localhost:8090 --user admin --pass secret
 */
const H = require('./lib/harness');

(async () => {
  const token = await H.login();
  const list = await H.servers(token);
  const server = list[0];
  if (!server) { console.error('this check needs at least one server - create one first'); process.exit(2); }

  H.begin('server page + servers list (theme)');

  /* ---------------------------- server page ------------------------------- */
  {
    const { window, document, errors, text } = await H.render('server.html', { script: 'server.js', token, serverId: server.id, wait: 7000 });
    const txt = (id) => { const el = document.getElementById(id); return el ? el.textContent.trim() : '(missing)'; };

    H.check('shell carries the two-tier server layout class', document.querySelector('.shell') && document.querySelector('.shell').className.includes('server-layout'));
    H.check('server-specific options live in a secondary drawer', Boolean(document.querySelector('.server-sidebar #serverTabs.server-tabs')));
    H.check('server drawer groups options into labelled sections', document.querySelectorAll('.server-sidebar .server-nav-section').length >= 4, `${document.querySelectorAll('.server-sidebar .server-nav-section').length} sections`);
    H.check('server drawer has 10+ reachable tabs', document.querySelectorAll('#serverTabs button[data-tab]').length >= 10, `${document.querySelectorAll('#serverTabs button[data-tab]').length} tabs`);
    H.check('page header shows a server overview banner', Boolean(document.querySelector('.server-hero h1') && document.querySelector('#liveStatus')));
    H.check('power banner has start / restart / stop / kill', document.querySelectorAll('.server-hero [data-power]').length === 4, `${document.querySelectorAll('.server-hero [data-power]').length} buttons`);
    H.check('console terminal has a named header and CLI input', Boolean(document.querySelector('.console-terminal-head') && document.querySelector('#terminalBody') && document.querySelector('#cmdInput')));
    H.check('four real-time resource cards render', document.querySelectorAll('.server-stat-grid .console-stat').length === 4, `${document.querySelectorAll('.server-stat-grid .console-stat').length} cards`);
    H.check('stat tiles filled', ['statAddress', 'statUptime', 'statCpu', 'statMemory', 'statDisk'].every((id) => txt(id) && txt(id) !== '(missing)'),
      `${txt('statAddress')} · ${txt('statCpu')} · ${txt('statMemory')}`);
    H.check('network in/out tiles + scope note', Boolean(document.getElementById('statNetIn') && document.getElementById('statNetOut')), `${txt('statNetIn')} / ${txt('statNetOut')}`);
    H.check('three chart cards', document.querySelectorAll('#chartCpu svg, #chartMem svg, #chartNet svg').length === 3,
      `${document.querySelectorAll('#chartCpu svg').length + document.querySelectorAll('#chartMem svg').length + document.querySelectorAll('#chartNet svg').length} svg`);
    H.check('live snapshot came from the API', /running|offline|starting|stopped/i.test(text()));
    H.check('no JS errors on the server page', errors.length === 0, errors.slice(0, 2).join(' | '));

    // settings tab keeps the runtime card reachable
    const sBtn = document.querySelector('#serverTabs button[data-tab="settings"]');
    if (sBtn) {
      sBtn.click();
      await H.sleep(1800);
      H.check('settings exposes the container runtime card', Boolean(document.getElementById('sBackend') && document.getElementById('sImage') && document.getElementById('saveRuntime')));
    }
    void window;
  }

  /* ---------------------------- servers list ------------------------------ */
  {
    const { window, document, errors, text } = await H.render('servers.html', { script: 'servers.js', token, wait: 3500 });
    const grid = document.getElementById('serverGrid');
    H.check('server grid rendered', Boolean(grid));
    H.check('grid uses the card view class', Boolean(grid && /cards-\d/.test(grid.className)), grid ? grid.className : '');
    H.check('a card exists per server', document.querySelectorAll('.srv-card').length === list.length, `${document.querySelectorAll('.srv-card').length} cards / ${list.length} servers`);
    H.check('cards have banner art', document.querySelectorAll('.srv-card .srv-banner').length >= 1);
    H.check('cards have a status pill', document.querySelectorAll('.srv-card .srv-pill').length >= 1);
    H.check('cards have the inset tile grid', document.querySelectorAll('.srv-card .srv-tiles').length >= 1);
    H.check('tiles cover node / address / cpu / memory / storage / players',
      ['Node', 'Address', 'CPU', 'Memory', 'Storage', 'Players'].every((k) => text().includes(k)));
    H.check('footer note on each card', document.querySelectorAll('.srv-card .srv-foot').length >= 1);
    const toggle = document.getElementById('viewToggle');
    H.check('view switcher present', Boolean(toggle && toggle.querySelectorAll('button').length >= 3));
    if (toggle) {
      const third = toggle.querySelectorAll('button')[2];
      third.click();
      await H.sleep(300);
      H.check('view switcher switches the grid class', /cards-3/.test(grid.className), grid.className);
      toggle.querySelectorAll('button')[1].click();
      await H.sleep(200);
      H.check('view switcher back to two columns', /cards-2/.test(grid.className), grid.className);
    }
    H.check('players tile value is numeric, never " / limit"', !/^\s*\/\s*\d/.test(text()), '');
    H.check('no JS errors on the servers list', errors.length === 0, errors.slice(0, 2).join(' | '));
    void window;
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
