#!/usr/bin/env node
'use strict';
/**
 * Page check: the reworked server page (dedicated server navigation, power banner,
 * live console, real-time stat cards, three charts) and the reworked servers
 * list (banner cards, view switcher, inset tiles).
 *
 *   node tests/pages-theme.js --url http://localhost:8090 --user admin --pass secret
 */
const H = require('./lib/harness');

(async () => {
  const token = await H.login();
  const list = await H.servers(token);
  const server = list[0];
  if (!server) { console.error('this check needs at least one server - create one first'); process.exit(2); }

  H.begin('server page + servers list (theme)');

  /* ---------------------------- server page ------------------------------- */
  {
    const { window, document, errors, text } = await H.render('server.html', { script: 'server.js', token, serverId: server.id, wait: 7000 });
    const txt = (id) => { const el = document.getElementById(id); return el ? el.textContent.trim() : '(missing)'; };

    H.check('shell carries the dedicated server layout class', document.querySelector('.shell') && document.querySelector('.shell').className.includes('server-layout'));
    H.check('server-specific options live in the only console sidebar', Boolean(document.querySelector('.server-sidebar #serverTabs.server-tabs')) && !document.querySelector('.shell > .sidebar'));
    H.check('console view has no hamburger or global topbar', !document.getElementById('menuBtn') && !document.querySelector('.shell > .main > .topbar'));
    H.check('server drawer groups options into labelled sections', document.querySelectorAll('.server-sidebar .server-nav-section').length >= 4, `${document.querySelectorAll('.server-sidebar .server-nav-section').length} sections`);
    H.check('server drawer has 10+ reachable tabs', document.querySelectorAll('#serverTabs button[data-tab]').length >= 10, `${document.querySelectorAll('#serverTabs button[data-tab]').length} tabs`);
    H.check('page header shows a server overview banner', Boolean(document.querySelector('.server-hero h1') && document.querySelector('#liveStatus')));
    H.check('power banner has start / restart / stop / kill', document.querySelectorAll('.server-hero [data-power]').length === 4, `${document.querySelectorAll('.server-hero [data-power]').length} buttons`);
    H.check('console terminal has a named header and CLI input', Boolean(document.querySelector('.console-terminal-head') && document.querySelector('#terminalBody') && document.querySelector('#cmdInput')));
    H.check('four real-time resource cards render', document.querySelectorAll('.server-stat-grid .console-stat').length === 4, `${document.querySelectorAll('.server-stat-grid .console-stat').length} cards`);
    H.check('stat tiles filled', ['statAddress', 'statUptime', 'statCpu', 'statMemory', 'statDisk'].every((id) => txt(id) && txt(id) !== '(missing)'),
      `${txt('statAddress')} · ${txt('statCpu')} · ${txt('statMemory')}`);
    H.check('network in/out tiles + scope note', Boolean(document.getElementById('statNetIn') && document.getElementById('statNetOut')), `${txt('statNetIn')} / ${txt('statNetOut')}`);
    H.check('three chart cards', document.querySelectorAll('#chartCpu svg, #chartMem svg, #chartNet svg').length === 3,
      `${document.querySelectorAll('#chartCpu svg').length + document.querySelectorAll('#chartMem svg').length + document.querySelectorAll('#chartNet svg').length} svg`);
    H.check('live snapshot came from the API', /running|offline|starting|stopped/i.test(text()));
    H.check('no JS errors on the server page', errors.length === 0, errors.slice(0, 2).join(' | '));

    // settings tab keeps the runtime card reachable
    const sBtn = document.querySelector('#serverTabs button[data-tab="settings"]');
    if (sBtn) {
      sBtn.click();
      await H.sleep(1800);
      H.check('settings exposes the container runtime card', Boolean(document.getElementById('sBackend') && document.getElementById('sImage') && document.getElementById('saveRuntime')));
      H.check('admin settings can manage IP, disk and CPU limits', Boolean(document.getElementById('sIp') && document.getElementById('sDiskLimit') && document.getElementById('sCpuLimit')));
    }
    void window;
  }

  /* ---------------------- general Docker workload page --------------------- */
  {
    let workload = null;
    try {
      const created = await H.api('/api/servers', { token, method: 'POST', body: { workloadType: 'container', containerTemplate: 'debian-12', name: `Container UI ${Date.now().toString().slice(-5)}`, memory: 512, install: false } });
      workload = created.json && created.json.server;
      H.check('API accepts the curated Debian container template', created.status === 201 && workload && workload.workloadType === 'container', created.json && created.json.error ? created.json.error : `HTTP ${created.status}`);
      if (workload) {
        const { document, errors } = await H.render('server.html', { script: 'server.js', token, serverId: workload.id, wait: 1800 });
        const containerTabs = [...document.querySelectorAll('#serverTabs button[data-tab]')].map((button) => button.dataset.tab);
        H.check('container page has only its reduced six-tab menu', ['console', 'terminal', 'files', 'network', 'settings', 'backups'].every((key) => containerTabs.includes(key)) && containerTabs.length === 6, containerTabs.join(','));
        H.check('container page omits Minecraft-only tabs', !['players', 'properties', 'worlds', 'sftp', 'plugins', 'mods', 'schedules', 'people'].some((key) => containerTabs.includes(key)), containerTabs.join(','));
        H.check('container console uses the full JTG-style stats, log and runtime-detail structure', document.querySelectorAll('#tab-console .server-stat-grid .console-stat').length === 4 && Boolean(document.querySelector('#tab-console .console-grid .console-aside')) && Boolean(document.getElementById('openContainerTerminal')));
        const containerFiles = await H.api(`/api/servers/${workload.id}/files`, { token });
        H.check('container workspace has no seeded Minecraft plugins or mods folders', !((containerFiles.json || {}).entries || []).some((entry) => entry.name === 'plugins' || entry.name === 'mods'), ((containerFiles.json || {}).entries || []).map((entry) => entry.name).join(','));
        document.querySelector('#serverTabs button[data-tab="terminal"]')?.click();
        await H.sleep(250);
        H.check('container terminal provides a real-command input, not the Minecraft console input', Boolean(document.getElementById('containerCommand')) && !document.getElementById('cmdInput'));
        H.check('container server page has no JS errors', errors.length === 0, errors.slice(0, 2).join(' | '));
      }
    } finally {
      if (workload) await H.api(`/api/servers/${workload.id}`, { token, method: 'DELETE' }).catch(() => {});
    }
  }

  /* ---------------------------- servers list ------------------------------ */
  {
    const { window, document, errors, text } = await H.render('servers.html', { script: 'servers.js', token, wait: 3500 });
    const grid = document.getElementById('serverGrid');
    H.check('server grid rendered', Boolean(grid));
    H.check('grid uses the card view class', Boolean(grid && /cards-\d/.test(grid.className)), grid ? grid.className : '');
    H.check('a card exists per server', document.querySelectorAll('.srv-card').length === list.length, `${document.querySelectorAll('.srv-card').length} cards / ${list.length} servers`);
    H.check('cards have banner art', document.querySelectorAll('.srv-card .srv-banner').length >= 1);
    H.check('cards have a status pill', document.querySelectorAll('.srv-card .srv-pill').length >= 1);
    H.check('cards have the inset tile grid', document.querySelectorAll('.srv-card .srv-tiles').length >= 1);
    H.check('tiles cover node / address / cpu / memory / storage / players',
      ['Node', 'Address', 'CPU', 'Memory', 'Storage', 'Players'].every((k) => text().includes(k)));
    H.check('footer note on each card', document.querySelectorAll('.srv-card .srv-foot').length >= 1);
    const toggle = document.getElementById('viewToggle');
    H.check('view switcher present', Boolean(toggle && toggle.querySelectorAll('button').length >= 3));
    if (toggle) {
      const third = toggle.querySelectorAll('button')[2];
      third.click();
      await H.sleep(300);
      H.check('view switcher switches the grid class', /cards-3/.test(grid.className), grid.className);
      toggle.querySelectorAll('button')[1].click();
      await H.sleep(200);
      H.check('view switcher back to two columns', /cards-2/.test(grid.className), grid.className);
    }
    H.check('players tile value is numeric, never " / limit"', !/^\s*\/\s*\d/.test(text()), '');

    // Regression coverage for the creation flow: rendering the Version step
    // before its async request completes prevents a double click from jumping
    // straight to Review and hides neither the picker nor errors/retry UI.
    const create = document.getElementById('createBtn');
    if (create) {
      create.click();
      await H.sleep(250);
      H.check('admin create starts with a Minecraft-or-Docker workload choice', Boolean(document.querySelector('[data-workload="minecraft"]') && document.querySelector('[data-workload="container"]')));
      document.querySelector('[data-workload="minecraft"]')?.click();
      await H.sleep(250);
      const wizard = document.getElementById('createWizard');
      H.check('Minecraft wizard opens with Details, Version and Review', Boolean(wizard && /Step 1 of 3/.test(wizard.textContent)));
      const name = document.querySelector('#wizBody [name="name"]');
      const description = document.querySelector('#wizBody [name="description"]');
      const eula = document.querySelector('#wizBody [name="eula"]');
      H.check('wizard collects description and hard resource limits', Boolean(description && document.querySelector('[name="diskLimit"]') && document.querySelector('[name="cpuLimit"]')));
      if (name && eula) { name.value = 'Wizard regression'; if (description) description.value = 'Test server'; eula.checked = true; }
      document.getElementById('wizNext')?.click();
      await H.sleep(1500);
      H.check('wizard Continue opens Version directly, never skips to Review', /Step 2 of 3/.test(document.getElementById('wizCounter')?.textContent || ''));
      H.check('wizard always renders the version selection area', Boolean(document.getElementById('versionList')));

      // The same guarded entry point exposes the container-specific three-stage
      // wizard, not Minecraft fields masquerading as a shell workload.
      document.querySelector('[data-close]')?.click();
      await H.sleep(100);
      create.click(); await H.sleep(120);
      document.querySelector('[data-workload="container"]')?.click();
      await H.sleep(180);
      const containerWizard = document.getElementById('containerWizard');
      H.check('Docker wizard opens with Details, Image and Review', Boolean(containerWizard && /Step 1 of 3/.test(containerWizard.textContent)));
      H.check('Docker details collect owner and real resource limits', Boolean(document.querySelector('#containerBody [name="ownerId"]') && document.querySelector('#containerBody [name="memory"]') && document.querySelector('#containerBody [name="diskLimit"]') && document.querySelector('#containerBody [name="cpuLimit"]')));
      const containerName = document.querySelector('#containerBody [name="name"]');
      if (containerName) containerName.value = 'Container regression';
      document.getElementById('containerNext')?.click(); await H.sleep(100);
      H.check('Docker Continue opens Image directly', /Step 2 of 3/.test(document.getElementById('containerCounter')?.textContent || '') && document.querySelectorAll('[data-template]').length === 6);
      document.querySelector('[data-template="ubuntu-22.04"]')?.click();
      H.check('supported Ubuntu, Debian, Python and Node images are offered', ['ubuntu-22.04', 'ubuntu-20.04', 'debian-11', 'debian-12', 'python-3.12', 'node-20'].every((id) => document.querySelector(`[data-template="${id}"]`)));
    }
    H.check('no JS errors on the servers list', errors.length === 0, errors.slice(0, 2).join(' | '));
    void window;
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
