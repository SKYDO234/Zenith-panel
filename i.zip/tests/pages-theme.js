#!/usr/bin/env node
'use strict';
/**
 * Page check: the reworked server page (dedicated server navigation, power banner,
 * live console, real-time stat cards, three charts) and the reworked servers
 * list (banner cards, view switcher, inset tiles).
 *
 *   node tests/pages-theme.js --url http://localhost:8090 --user admin --pass secret
 */
const H = require('./lib/harness');

(async () => {
  const token = await H.login();
  const list = await H.servers(token);
  const server = list[0];
  if (!server) { console.error('this check needs at least one server - create one first'); process.exit(2); }

  H.begin('server page + servers list (theme)');

  /* ---------------------------- server page ------------------------------- */
  {
    const { window, document, errors, text } = await H.render('server.html', { script: 'server.js', token, serverId: server.id, wait: 7000 });
    const txt = (id) => { const el = document.getElementById(id); return el ? el.textContent.trim() : '(missing)'; };

    H.check('shell carries the dedicated server layout class', document.querySelector('.shell') && document.querySelector('.shell').className.includes('server-layout'));
    H.check('server-specific options live in the only console sidebar', Boolean(document.querySelector('.server-sidebar #serverTabs.server-tabs')) && !document.querySelector('.shell > .sidebar'));
    H.check('console view has no hamburger or global topbar', !document.getElementById('menuBtn') && !document.querySelector('.shell > .main > .topbar'));
    H.check('server drawer groups options into labelled sections', document.querySelectorAll('.server-sidebar .server-nav-section').length >= 4, `${document.querySelectorAll('.server-sidebar .server-nav-section').length} sections`);
    H.check('server drawer has 10+ reachable tabs', document.querySelectorAll('#serverTabs button[data-tab]').length >= 10, `${document.querySelectorAll('#serverTabs button[data-tab]').length} tabs`);
    H.check('page header shows a server overview banner', Boolean(document.querySelector('.server-hero h1') && document.querySelector('#liveStatus')));
    H.check('power banner has start / restart / stop / kill', document.querySelectorAll('.server-hero [data-power]').length === 4, `${document.querySelectorAll('.server-hero [data-power]').length} buttons`);
    H.check('console terminal has a named header and CLI input', Boolean(document.querySelector('.console-terminal-head') && document.querySelector('#terminalBody') && document.querySelector('#cmdInput')));
    H.check('Minecraft console follows the complete seven-card JTG metric rail', Boolean(document.querySelector('.jtg-console-grid .jtg-log-console')) && document.querySelectorAll('.jtg-stat-rail .jtg-stat-card').length === 7, `${document.querySelectorAll('.jtg-stat-rail .jtg-stat-card').length} cards`);
    H.check('JTG metric rail has real address, uptime, CPU, memory and disk values', ['jtgAddress', 'jtgUptime', 'jtgCpu', 'jtgMemory', 'jtgDisk'].every((id) => txt(id) && txt(id) !== '(missing)'),
      `${txt('jtgAddress')} · ${txt('jtgCpu')} · ${txt('jtgMemory')}`);
    H.check('JTG metric rail has inbound/outbound network cards', Boolean(document.getElementById('jtgNetIn') && document.getElementById('jtgNetOut')), `${txt('jtgNetIn')} / ${txt('jtgNetOut')}`);
    H.check('three chart cards', document.querySelectorAll('#chartCpu svg, #chartMem svg, #chartNet svg').length === 3,
      `${document.querySelectorAll('#chartCpu svg').length + document.querySelectorAll('#chartMem svg').length + document.querySelectorAll('#chartNet svg').length} svg`);
    H.check('live snapshot came from the API', /running|offline|starting|stopped/i.test(text()));
    H.check('no JS errors on the server page', errors.length === 0, errors.slice(0, 2).join(' | '));

    // Network metadata must stay in label/value rows rather than shrinking all
    // dt/dd pairs into a single character-wide flex line on a narrow screen.
    const nBtn = document.querySelector('#serverTabs button[data-tab="network"]');
    if (nBtn) {
      nBtn.click();
      await H.sleep(1800);
      const playitKv = document.querySelector('#playitCard .kv');
      H.check('Playit metadata uses five readable label/value definition rows', Boolean(playitKv) && playitKv.querySelectorAll('dt').length === 5 && playitKv.querySelectorAll('dd').length === 5, playitKv ? `${playitKv.querySelectorAll('dt').length} pairs` : 'missing');
    }

    // settings tab keeps the runtime card reachable
    const sBtn = document.querySelector('#serverTabs button[data-tab="settings"]');
    if (sBtn) {
      sBtn.click();
      await H.sleep(1800);
      H.check('settings exposes the container runtime card', Boolean(document.getElementById('sBackend') && document.getElementById('sImage') && document.getElementById('saveRuntime')));
      H.check('admin settings can manage IP, disk and CPU limits', Boolean(document.getElementById('sIp') && document.getElementById('sDiskLimit') && document.getElementById('sCpuLimit')));
      const switcher = document.getElementById('changeVersion');
      H.check('settings offers the one-click software and version switcher', Boolean(switcher) && /one-click software switch/i.test(switcher.textContent));
      if (switcher) {
        switcher.click();
        await H.sleep(1800);
        const typePicker = document.getElementById('migType');
        H.check('software switcher loads a real software picker and excludes fake custom downloads', Boolean(typePicker && document.getElementById('migVersion') && document.getElementById('migSearch')) && ![...typePicker.options].some((option) => option.value === 'CUSTOM'), typePicker ? `${typePicker.options.length} real distributions` : 'missing');
      }
      document.querySelector('.overlay.open [data-close]')?.click();
    }
    void window;
  }

  /* ---------------------- general Docker workload page --------------------- */
  {
    let workload = null;
    try {
      const created = await H.api('/api/servers', { token, method: 'POST', body: { workloadType: 'container', containerTemplate: 'debian-12', name: `Container UI ${Date.now().toString().slice(-5)}`, memory: 512, install: false } });
      workload = created.json && created.json.server;
      H.check('API accepts the curated Debian container template', created.status === 201 && workload && workload.workloadType === 'container', created.json && created.json.error ? created.json.error : `HTTP ${created.status}`);
      if (workload) {
        const { document, errors } = await H.render('server.html', { script: 'server.js', token, serverId: workload.id, wait: 1800 });
        const containerTabs = [...document.querySelectorAll('#serverTabs button[data-tab]')].map((button) => button.dataset.tab);
        H.check('container page has only its reduced five-tab menu', ['console', 'files', 'network', 'settings', 'backups'].every((key) => containerTabs.includes(key)) && containerTabs.length === 5 && !containerTabs.includes('terminal'), containerTabs.join(','));
        H.check('container page omits Minecraft-only tabs', !['players', 'properties', 'worlds', 'sftp', 'plugins', 'mods', 'schedules', 'people'].some((key) => containerTabs.includes(key)), containerTabs.join(','));
        H.check('container console uses the complete JTG structure: dominant log, seven metric cards, history charts and SSHX', Boolean(document.querySelector('#tab-console .jtg-console-grid .jtg-log-console')) && document.querySelectorAll('#tab-console .jtg-stat-rail .jtg-stat-card').length === 7 && ['chartCpu', 'chartMem', 'chartNet'].every((id) => Boolean(document.getElementById(id))) && Boolean(document.getElementById('openSshxSession')) && Boolean(document.querySelector('[data-sshx-slot]')));
        const containerFiles = await H.api(`/api/servers/${workload.id}/files`, { token });
        H.check('container workspace has no seeded Minecraft plugins or mods folders', !((containerFiles.json || {}).entries || []).some((entry) => entry.name === 'plugins' || entry.name === 'mods'), ((containerFiles.json || {}).entries || []).map((entry) => entry.name).join(','));
        H.check('container page has no embedded command terminal', !document.getElementById('containerCommand') && !document.getElementById('tab-terminal'));
        H.check('container server page has no JS errors', errors.length === 0, errors.slice(0, 2).join(' | '));
      }
    } finally {
      if (workload) await H.api(`/api/servers/${workload.id}`, { token, method: 'DELETE' }).catch(() => {});
    }
  }

  /* ---------------------------- servers list ------------------------------ */
  {
    const { window, document, errors, text } = await H.render('servers.html', { script: 'servers.js', token, wait: 3500 });
    const grid = document.getElementById('serverGrid');
    H.check('server grid rendered', Boolean(grid));
    H.check('grid uses the card view class', Boolean(grid && /cards-\d/.test(grid.className)), grid ? grid.className : '');
    H.check('a card exists per server', document.querySelectorAll('.srv-card').length === list.length, `${document.querySelectorAll('.srv-card').length} cards / ${list.length} servers`);
    H.check('cards have banner art', document.querySelectorAll('.srv-card .srv-banner').length >= 1);
    H.check('cards have a status pill', document.querySelectorAll('.srv-card .srv-pill').length >= 1);
    H.check('cards have the inset tile grid', document.querySelectorAll('.srv-card .srv-tiles').length >= 1);
    H.check('tiles cover node / address / cpu / memory / storage / players',
      ['Node', 'Address', 'CPU', 'Memory', 'Storage', 'Players'].every((k) => text().includes(k)));
    H.check('footer note on each card', document.querySelectorAll('.srv-card .srv-foot').length >= 1);
    const toggle = document.getElementById('viewToggle');
    H.check('view switcher present', Boolean(toggle && toggle.querySelectorAll('button').length >= 3));
    if (toggle) {
      const third = toggle.querySelectorAll('button')[2];
      third.click();
      await H.sleep(300);
      H.check('view switcher switches the grid class', /cards-3/.test(grid.className), grid.className);
      toggle.querySelectorAll('button')[1].click();
      await H.sleep(200);
      H.check('view switcher back to two columns', /cards-2/.test(grid.className), grid.className);
    }
    H.check('players tile value is numeric, never " / limit"', !/^\s*\/\s*\d/.test(text()), '');

    // Regression coverage for the creation flow: rendering the Version step
    // before its async request completes prevents a double click from jumping
    // straight to Review and hides neither the picker nor errors/retry UI.
    const create = document.getElementById('createBtn');
    if (create) {
      create.click();
      await H.sleep(250);
      H.check('admin create offers Minecraft, dedicated-game, and Docker workload choices', Boolean(document.querySelector('[data-workload="minecraft"]') && document.querySelector('[data-workload="game"]') && document.querySelector('[data-workload="container"]')));
      document.querySelector('[data-workload="minecraft"]')?.click();
      await H.sleep(250);
      const wizard = document.getElementById('createWizard');
      H.check('Minecraft wizard opens with Details, Version and Review', Boolean(wizard && /Step 1 of 3/.test(wizard.textContent)));
      const name = document.querySelector('#wizBody [name="name"]');
      const description = document.querySelector('#wizBody [name="description"]');
      const eula = document.querySelector('#wizBody [name="eula"]');
      H.check('wizard collects description and hard resource limits', Boolean(description && document.querySelector('[name="diskLimit"]') && document.querySelector('[name="cpuLimit"]')));
      if (name && eula) { name.value = 'Wizard regression'; if (description) description.value = 'Test server'; eula.checked = true; }
      document.getElementById('wizNext')?.click();
      await H.sleep(1500);
      H.check('wizard Continue opens Version directly, never skips to Review', /Step 2 of 3/.test(document.getElementById('wizCounter')?.textContent || ''));
      H.check('wizard always renders the version selection area', Boolean(document.getElementById('versionList')));

      // The same guarded entry point exposes the container-specific three-stage
      // wizard, not Minecraft fields masquerading as a shell workload.
      document.querySelector('[data-close]')?.click();
      await H.sleep(100);
      create.click(); await H.sleep(120);
      document.querySelector('[data-workload="container"]')?.click();
      await H.sleep(180);
      const containerWizard = document.getElementById('containerWizard');
      H.check('Docker wizard opens with Details, Image and Review', Boolean(containerWizard && /Step 1 of 3/.test(containerWizard.textContent)));
      H.check('Docker details collect owner and real resource limits', Boolean(document.querySelector('#containerBody [name="ownerId"]') && document.querySelector('#containerBody [name="memory"]') && document.querySelector('#containerBody [name="diskLimit"]') && document.querySelector('#containerBody [name="cpuLimit"]')));
      const containerName = document.querySelector('#containerBody [name="name"]');
      if (containerName) containerName.value = 'Container regression';
      document.getElementById('containerNext')?.click(); await H.sleep(100);
      H.check('Docker Continue opens Image directly', /Step 2 of 3/.test(document.getElementById('containerCounter')?.textContent || '') && document.querySelectorAll('[data-template]').length === 6);
      document.querySelector('[data-template="ubuntu-22.04"]')?.click();
      H.check('supported Ubuntu, Debian, Python and Node images are offered', ['ubuntu-22.04', 'ubuntu-20.04', 'debian-11', 'debian-12', 'python-3.12', 'node-20'].every((id) => document.querySelector(`[data-template="${id}"]`)));

      document.querySelector('[data-close]')?.click();
      await H.sleep(100);
      create.click(); await H.sleep(120);
      document.querySelector('[data-workload="game"]')?.click();
      await H.sleep(350);
      const gameWizard = document.getElementById('gameWizard');
      H.check('dedicated-game wizard opens with Details, Game and Review', Boolean(gameWizard && /Step 1 of 3/.test(gameWizard.textContent)));
      H.check('game wizard collects owner, limits, player slots, and safe port allocation', Boolean(document.querySelector('#gameBody [name="ownerId"]') && document.querySelector('#gameBody [name="maxPlayers"]') && document.querySelector('#gameBody [name="port"]')));
      const gameName = document.querySelector('#gameBody [name="name"]');
      if (gameName) gameName.value = 'Game wizard regression';
      document.getElementById('gameNext')?.click(); await H.sleep(100);
      H.check('game Continue opens audited SteamCMD template selection directly', /Step 2 of 3/.test(document.getElementById('gameCounter')?.textContent || '') && document.querySelectorAll('[data-game]').length >= 20);
      H.check('game picker visibly blocks Windows-only templates instead of making fake Linux options', Boolean(document.querySelector('[data-game="space-engineers"][disabled]')));
    }
    H.check('no JS errors on the servers list', errors.length === 0, errors.slice(0, 2).join(' | '));
    void window;
  }

  process.exit(H.finish() ? 1 : 0);
})().catch((err) => { console.error('HARNESS ERROR', err); process.exit(2); });
