/* Dashboard: live console + players + host resources, with quick power actions. */
(async function () {
  try { await bootstrap({ active: 'dashboard.html' }); } catch (_) { return; }

  const root = document.getElementById('dashContent');
  let servers = [];
  let host = null;
  let history = { series: [], summary: {} };
  let activity = [];
  let currentId = localStorage.getItem('zenith_last_server') || null;
  let socket = null;
  let consoleView = null;
  let actions = [];

  const isAdmin = ['admin', 'owner'].includes(store.user?.role);

  /* ------------------------------- rendering ------------------------------- */
  function shell() {
    root.innerHTML = `
      <div class="grid cols-4" id="statCards"></div>
      <div class="dash-split">
        <div class="stack" id="dashLeft"></div>
        <div class="stack" id="dashRight"></div>
      </div>`;
  }

  function renderStats() {
    const el = document.getElementById('statCards');
    if (!el) return;
    const s = history.series || [];
    const running = servers.filter((x) => ['running', 'starting'].includes(x.status)).length;
    const players = servers.reduce((n, x) => n + (x.players || 0), 0);
    const maxPlayers = servers.reduce((n, x) => n + (x.maxPlayers || 0), 0);
    const sparkCpu = s.length > 1 ? Chart.spark(s, { key: 'cpu', color: 'var(--green)', width: 130, height: 34, max: 100 }) : '';
    const sparkMem = s.length > 1 ? Chart.spark(s, { key: 'memory', color: 'var(--violet)', width: 130, height: 34, max: 100 }) : '';
    el.innerHTML = `
      <div class="card">
        <div class="row between"><span class="label tiny dim">Servers</span>${ICONS.servers}</div>
        <div class="stat-row mt"><b>${running}</b><span class="dim">online / ${servers.length} total</span></div>
        <div class="tiny dim mt">${servers.filter((x) => x.status === 'offline').length} offline${servers.some((x) => x.status === 'crashed') ? ` · ${servers.filter((x) => x.status === 'crashed').length} crashed` : ''}</div>
      </div>
      <div class="card">
        <div class="row between"><span class="label tiny dim">Players online</span>${ICONS.users2}</div>
        <div class="stat-row mt"><b>${players}</b><span class="dim">of ${maxPlayers || 0} slots</span></div>
        <div class="tiny dim mt">peak in the last hour: ${history.summary?.playersPeak ?? 0}</div>
      </div>
      <div class="card">
        <div class="row between"><span class="label tiny dim">Host CPU</span>${ICONS.chip}</div>
        <div class="stat-row mt"><b>${(host?.cpu ?? 0).toFixed(1)}%</b><span class="dim">${host?.cores || '?'} cores</span></div>
        <div style="margin-top:6px">${sparkCpu}</div>
      </div>
      <div class="card">
        <div class="row between"><span class="label tiny dim">Host memory</span>${ICONS.memory}</div>
        <div class="stat-row mt"><b>${(host?.memory?.percent ?? 0).toFixed(0)}%</b><span class="dim">${fmt.bytes(host?.memory?.used || 0)} / ${fmt.bytes(host?.memory?.total || 0)}</span></div>
        <div style="margin-top:6px">${sparkMem}</div>
      </div>`;
  }

  function serverOptions() {
    return servers.map((s) => `<option value="${s.id}" ${s.id === currentId ? 'selected' : ''}>${esc(s.name)} · ${s.status}${s.players ? ` · ${s.players}p` : ''}</option>`).join('');
  }

  function renderConsole() {
    const el = document.getElementById('dashLeft');
    if (!el) return;
    const server = servers.find((s) => s.id === currentId) || servers[0];
    if (!server) {
      el.innerHTML = `<div class="card">${UI.empty('No servers yet', 'Create your first Minecraft server to see its console here.')}
        <div class="mt"><a class="btn primary" href="servers.html#create">${ICONS.plus} Create a server</a></div></div>`;
      return;
    }
    currentId = server.id;
    el.innerHTML = `
      <div class="card">
        <div class="row between wrap" style="gap:10px">
          <div class="row" style="gap:10px">
            <div class="server-icon" style="width:38px;height:38px;flex:0 0 38px;font-size:13px">${esc(server.serverType.slice(0, 2))}</div>
            <div>
              <div class="row" style="gap:8px"><b>${esc(server.name)}</b><span id="dashStatus">${statusBadge(server.status)}</span></div>
              <div class="tiny dim mono">${esc(server.serverType)} ${esc(server.version || '')} · ${esc(server.nodeName || 'local')} · ${esc(server.ip)}:${server.port}</div>
            </div>
          </div>
          <div class="row wrap" style="gap:7px">
            ${servers.length > 1 ? `<select id="dashServerPick" style="max-width:210px">${serverOptions()}</select>` : ''}
            <span id="dashPower">${powerButtons(server)}</span>
            <a class="btn sm" href="server.html?id=${server.id}">${ICONS.terminal} Full view</a>
          </div>
        </div>
        <div class="terminal mt">
          <div class="terminal-head">
            <div class="lights"><i></i><i></i><i></i></div>
            <span class="tiny dim mono">${esc(server.name.toLowerCase().replace(/\s+/g, '-'))} - live output</span>
            <div class="grow"></div>
            <span class="badge tiny" id="dashSocketMode">connecting</span>
            <button class="btn ghost sm" id="dashJump">Jump to end</button>
          </div>
          <div class="terminal-body" id="dashTerminal">${UI.spinner()} <span class="dim">connecting to the console stream…</span></div>
          <div class="console-input">
            <input type="text" id="dashCmd" placeholder="Type a command and press Enter (say hello, list, op Notch…)" autocomplete="off">
            <button class="btn primary" id="dashCmdSend">Send</button>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="row between"><h3 style="margin:0">Your servers</h3>
          <div class="row" style="gap:7px"><a class="btn sm" href="analytics.html">${ICONS.analytics} Analytics</a><a class="btn sm" href="servers.html">All servers</a></div>
        </div>
        <div class="grid cols-3 mt" id="serverCards"></div>
      </div>`;

    const pick = document.getElementById('dashServerPick');
    if (pick) pick.onchange = () => selectServer(pick.value);
    wirePower(el, server);
    document.getElementById('dashJump').onclick = () => { const t = document.getElementById('dashTerminal'); t.scrollTop = t.scrollHeight; };
    const input = document.getElementById('dashCmd');
    const send = () => {
      const command = input.value.trim();
      if (!command) return;
      if (socket) socket.command(command);
      input.value = '';
    };
    document.getElementById('dashCmdSend').onclick = send;
    input.onkeydown = (e) => { if (e.key === 'Enter') send(); };
    mountTerminal(server.id);
    renderServerCards();
  }

  function powerButtons(server) {
    if (['installing', 'starting', 'stopping'].includes(server.status)) {
      return `<button class="btn sm" disabled>${UI.spinner(13)} working…</button>`;
    }
    if (server.status === 'running') {
      return `<button class="btn sm" data-dpower="restart">${ICONS.restart} Restart</button>
              <button class="btn sm red" data-dpower="stop">${ICONS.stop} Stop</button>`;
    }
    return `<button class="btn sm primary" data-dpower="start">${ICONS.play} Start</button>`;
  }

  function wirePower(scope, server) {
    scope.querySelectorAll('[data-dpower]').forEach((b) => {
      b.onclick = async () => {
        b.disabled = true;
        try { await API.post(`/servers/${server.id}/${b.dataset.dpower}`); UI.toast(`${server.name}: ${b.dataset.dpower} sent`, 'success'); setTimeout(refresh, 1200); }
        catch (err) { UI.toast(err.message, 'error'); b.disabled = false; }
      };
    });
  }

  function renderServerCards() {
    const el = document.getElementById('serverCards');
    if (!el) return;
    if (!servers.length) { el.innerHTML = UI.empty('Nothing here yet'); return; }
    el.innerHTML = servers.map((s) => `
      <div class="card inset" data-sid="${s.id}">
        <div class="row between"><b class="truncate">${esc(s.name)}</b>${statusBadge(s.status)}</div>
        <div class="tiny dim mono mt">${esc(s.serverType)} ${esc(s.version || '')} · :${s.port}${s.nodeId !== 'local' ? ` · ${esc(s.nodeName)}` : ''}</div>
        <div class="row between mt" style="gap:8px">
          <span class="tiny dim">${s.players || 0}/${s.maxPlayers || 0} players · ${fmt.bytes((s.memory || 0) * 1024 * 1024)}<span class="tiny dim"> limit</span></span>
          <div class="row" style="gap:6px">
            <a class="btn sm icon" href="server.html?id=${s.id}" title="Open console">${ICONS.terminal}</a>
            <a class="btn sm icon" href="server.html?id=${s.id}#players" title="Players">${ICONS.users2}</a>
          </div>
        </div>
        <div class="row mt" style="gap:6px">
          <span class="grow"></span>
          ${s.status === 'running'
            ? `<button class="btn sm icon ghost" data-spower="restart" data-sid="${s.id}" title="Restart">${ICONS.restart}</button>
               <button class="btn sm icon ghost" data-spower="stop" data-sid="${s.id}" title="Stop">${ICONS.stop}</button>`
            : `<button class="btn sm icon ghost" data-spower="start" data-sid="${s.id}" title="Start">${ICONS.play}</button>`}
        </div>
      </div>`).join('');
    el.querySelectorAll('[data-spower]').forEach((b) => {
      b.onclick = async () => {
        b.disabled = true;
        try { await API.post(`/servers/${b.dataset.sid}/${b.dataset.spower}`); setTimeout(refresh, 1200); }
        catch (err) { UI.toast(err.message, 'error'); b.disabled = false; }
      };
    });
  }

  function renderSide() {
    const el = document.getElementById('dashRight');
    if (!el) return;
    const server = servers.find((s) => s.id === currentId) || servers[0];
    const memPct = host?.memory?.percent || 0;
    const cpuPct = host?.cpu || 0;
    const diskPct = host?.disk ? Math.round(((host.disk.total - host.disk.free) / host.disk.total) * 100) : 0;
    const statusItems = ['running', 'starting', 'installing', 'offline', 'crashed'].map((st, i) => ({
      label: st, value: servers.filter((s) => s.status === st).length,
      color: ['var(--green)', 'var(--yellow)', 'var(--blue)', 'var(--fg-faint)', 'var(--red)'][i],
    }));
    el.innerHTML = `
      <div class="card">
        <div class="row between">
          <h3 style="margin:0">Players${server ? ` · ${esc(server.name)}` : ''}</h3>
          <div class="row" style="gap:6px">
            <span class="badge tiny mono" id="dashPlayerCount">0 / ${server?.maxPlayers || 20}</span>
            ${server ? `<button class="btn sm icon ghost" id="dashAddPlayer" title="Act on a player by name">${ICONS.plus}</button>` : ''}
          </div>
        </div>
        <div class="mt" id="dashPlayers">${UI.skeleton(3)}</div>
      </div>
      <div class="card">
        <h3>Host resources</h3>
        <div class="mt stack">
          <div><div class="row between tiny dim"><span>CPU</span><span class="mono">${cpuPct.toFixed(1)}%</span></div><div class="bar blue mt"><i style="width:${Math.min(100, cpuPct)}%"></i></div></div>
          <div><div class="row between tiny dim"><span>Memory</span><span class="mono">${fmt.bytes(host?.memory?.used || 0)} / ${fmt.bytes(host?.memory?.total || 0)}</span></div><div class="bar ${memPct > 85 ? 'red' : 'green'} mt"><i style="width:${Math.min(100, memPct)}%"></i></div></div>
          <div><div class="row between tiny dim"><span>Disk</span><span class="mono">${fmt.bytes(host?.disk?.free || 0)} free</span></div><div class="bar ${diskPct > 85 ? 'red' : 'yellow'} mt"><i style="width:${Math.min(100, diskPct)}%"></i></div></div>
          <div><div class="row between tiny dim"><span>Load average</span><span class="mono">${(host?.load?.['1m'] ?? 0).toFixed(2)}</span></div></div>
        </div>
        <div class="divider"></div>
        <div class="row" style="gap:14px;align-items:center">
          ${Chart.donut(statusItems, { size: 118, thickness: 13, center: String(servers.length), sub: 'servers' })}
          ${Chart.legend(statusItems.filter((i) => i.value))}
        </div>
      </div>
      <div class="card">
        <div class="row between"><h3 style="margin:0">Recent activity</h3><a class="tiny dim" href="analytics.html">see all</a></div>
        <div class="mt" id="dashActivity">${UI.skeleton(4)}</div>
      </div>`;
    const add = document.getElementById('dashAddPlayer');
    if (add && server) add.onclick = () => Players.openActions(server.id, '', actions);
    renderPlayers(server);
    renderActivity();
  }

  function renderPlayers(server) {
    const el = document.getElementById('dashPlayers');
    if (!el) return;
    if (!server) { el.innerHTML = UI.empty('No server selected'); return; }
    const count = document.getElementById('dashPlayerCount');
    if (count) count.textContent = `${server.players || 0} / ${server.maxPlayers || 20}`;
    Players.mount(el, {
      serverId: server.id,
      players: server.playerList || [],
      max: server.maxPlayers || 20,
      status: server.status,
      actions,
      emptyText: 'Nobody is online right now',
    });
  }

  function renderActivity() {
    const el = document.getElementById('dashActivity');
    if (!el) return;
    if (!activity.length) { el.innerHTML = `<div class="tiny dim">No activity recorded yet.</div>`; return; }
    el.innerHTML = activity.slice(0, 7).map((a) => `
      <div class="row" style="gap:9px;padding:6px 0;border-bottom:1px solid var(--line-subtle)">
        <span class="tiny dim mono" style="flex:0 0 auto">${new Date(a.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        <div class="grow" style="min-width:0">
          <div class="truncate" style="font-size:13px">${esc(a.detail || a.action)}</div>
          <div class="tiny dim">${esc(a.actor || 'system')} · ${esc(a.action)}${a.serverName ? ` · ${esc(a.serverName)}` : ''}</div>
        </div>
      </div>`).join('');
  }

  /* ------------------------------- console ------------------------------- */
  function mountTerminal(serverId) {
    const body = document.getElementById('dashTerminal');
    if (!body) return;
    body.textContent = '';
    consoleView = new ConsoleView(body);
    if (socket) socket.close();
    socket = new ConsoleSocket(serverId, {
      onState(mode) {
        const badge = document.getElementById('dashSocketMode');
        if (badge) badge.textContent = mode === 'open' ? 'live' : mode;
      },
      onEvent(msg) {
        if (msg.type === 'log' && msg.data) consoleView.append(msg.data);
        if (msg.type === 'history' && Array.isArray(msg.data)) msg.data.forEach((l) => consoleView.append(typeof l === 'string' ? l : l.line));
        if (msg.type === 'players') updatePlayers(msg.data);
        if (msg.type === 'status' && msg.data) {
          const server = servers.find((s) => s.id === serverId);
          if (server) server.status = msg.data.status;
          const badge = document.getElementById('dashStatus');
          if (badge) badge.innerHTML = statusBadge(msg.data.status);
          const power = document.getElementById('dashPower');
          if (power && server) power.innerHTML = powerButtons(server);
          if (server) wirePower(document.getElementById('dashLeft'), server);
        }
        if (msg.installProgress) {
          const p = msg.installProgress;
          if (p && p.percent < 100) consoleView.append(`[panel] ${p.note || p.step || 'installing'}: ${p.percent}%`);
        }
      },
    });
  }

  function updatePlayers(list) {
    const server = servers.find((s) => s.id === currentId);
    if (!server) return;
    server.playerList = list || [];
    server.players = (list || []).length;
    renderPlayers(server);
    renderStats();
  }

  function selectServer(id) {
    currentId = id;
    localStorage.setItem('zenith_last_server', id);
    renderConsole();
    renderSide();
    loadPlayers();
  }

  /* --------------------------------- data --------------------------------- */
  async function loadPlayers() {
    const server = servers.find((s) => s.id === currentId) || servers[0];
    if (!server) return;
    try {
      const data = await API.get(`/servers/${server.id}/players`);
      if (!actions.length) actions = data.actions || [];
      server.playerList = data.players || [];
      server.players = (server.playerList || []).length;
      server.maxPlayers = data.max || server.maxPlayers;
      renderPlayers(server);
      renderStats();
    } catch (_) { /* server may be gone */ }
  }

  async function refresh() {
    try {
      const [stats, list, hist, act] = await Promise.all([
        API.get('/system/stats'),
        API.get('/servers'),
        API.get('/system/history?minutes=60&points=60').catch(() => ({ series: [], summary: {} })),
        API.get('/system/activity?limit=12').catch(() => ({ activity: [] })),
      ]);
      host = stats.host;
      servers = list.servers || [];
      history = hist;
      activity = act.activity || act.entries || [];
      if (!servers.some((s) => s.id === currentId)) currentId = servers[0] ? servers[0].id : null;
      renderStats();
      renderConsole();
      renderSide();
      await loadPlayers();
      Layout.setServerCount(servers.length);
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  }

  Layout.title('Dashboard', 'Live view of your fleet');
  Layout.actions(`<button class="btn sm" id="dashRefresh">${ICONS.refresh} Refresh</button>
                  <a class="btn sm" href="servers.html#create">${ICONS.plus} New server</a>`);
  shell();
  document.getElementById('dashRefresh').onclick = () => refresh();
  await refresh();
  setInterval(() => {
    API.get('/system/stats').then((s) => { host = s.host; renderStats(); renderSide(); }).catch(() => {});
    API.get('/servers').then((l) => {
      const byId = new Map(servers.map((s) => [s.id, s]));
      servers = (l.servers || []).map((s) => ({ ...s, playerList: byId.get(s.id)?.playerList || [] }));
      renderStats(); renderServerCards();
    }).catch(() => {});
  }, 15000);
  void isAdmin;
})();
