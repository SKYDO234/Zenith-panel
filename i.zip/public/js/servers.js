/* Servers list + create-server wizard */
(async function () {
  const grid = document.getElementById('serverGrid');
  const searchInput = document.getElementById('searchInput');
  const statusFilter = document.getElementById('statusFilter');
  const sortSelect = document.getElementById('sortSelect');
  let catalogue = null;
  let versionCache = {};

  try { await bootstrap({ active: 'servers.html' }); } catch (_) { return; }

  Layout.title('Servers', 'all instances you can access');
  Layout.actions(`<button class="btn sm primary" id="createBtn">${ICONS.plus} Create server</button>`);
  document.getElementById('createBtn').onclick = openCreate;
  document.getElementById('refreshBtn').onclick = () => load();

  /* layout switch: 1 / 2 / 3 columns, remembered per browser */
  const viewToggle = document.getElementById('viewToggle');
  function setView(n) {
    grid.classList.remove('cards-1', 'cards-2', 'cards-3');
    grid.classList.add(`cards-${n}`);
    viewToggle.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.view === String(n)));
    try { localStorage.setItem('zenith.serverView', String(n)); } catch (_) {}
  }
  viewToggle.querySelectorAll('button').forEach((b) => b.onclick = () => setView(Number(b.dataset.view)));
  try { setView(Number(localStorage.getItem('zenith.serverView')) || 2); } catch (_) { setView(2); }

  async function load() {
    const params = new URLSearchParams();
    if (searchInput.value) params.set('search', searchInput.value);
    if (statusFilter.value) params.set('status', statusFilter.value);
    if (sortSelect.value) params.set('sort', sortSelect.value);
    params.set('withUsage', 'disk');
    try {
      const data = await API.get(`/servers?${params}`);
      Layout.setServerCount(data.total);
      render(data);
    } catch (err) {
      grid.innerHTML = `<div class="banner-note red">${ICONS.warn}<div>${esc(err.message)}</div></div>`;
    }
  }

  /* Deterministic "mini world" banner: pure inline SVG (works offline and in
     sandboxed previews). Colours come from the server type, shape from its id. */
  const TYPE_COLORS = {
    PAPER: ['#7ec8a0', '#5aa9ff', '#f0c674', '#32607a'],
    VANILLA: ['#8fd694', '#6fc3e0', '#e8e2c0', '#3c6b53'],
    PURPUR: ['#c39bf5', '#7f6ad8', '#f3bde4', '#3b2f63'],
    FABRIC: ['#f0d9a8', '#9ad3c6', '#ffb27a', '#4a5b6e'],
    QUILT: ['#c9a8f0', '#f5c9e0', '#8fd694', '#3f3a63'],
    FORGE: ['#d8b48a', '#8a6a4a', '#c9d8e0', '#3a3226'],
    NEOFORGE: ['#f0a868', '#e07850', '#ffd9a8', '#4a3a30'],
    SPIGOT: ['#f0c674', '#d8a04a', '#8fd694', '#3f3a2a'],
    BUNGEECORD: ['#c9b6f0', '#8fa8e0', '#f0d9a8', '#33355c'],
    VELOCITY: ['#8fd6f0', '#5aa9ff', '#c9f0e0', '#28455c'],
  };
  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < String(str).length; i++) { h ^= String(str).charCodeAt(i); h = Math.imul(h, 16777619); }
    return Math.abs(h);
  }
  function bannerArt(s) {
    const seed = hash(s.id + s.name);
    const [a, b, c, sky] = TYPE_COLORS[s.serverType] || ['#8fb8f0', '#7f8ce0', '#f0d9a8', '#2b3550'];
    const rnd = (n) => ((seed >> (n * 3)) % 1000) / 1000;
    const W = 400; const H = 132;
    const clouds = [0, 1].map((i) => {
      const cx = 40 + rnd(i) * (W - 120); const cy = 18 + rnd(i + 4) * 44; const w = 46 + rnd(i + 7) * 62;
      return `<g opacity="${0.24 + rnd(i + 2) * 0.22}"><rect x="${cx.toFixed(0)}" y="${cy.toFixed(0)}" width="${w.toFixed(0)}" height="9" rx="2" fill="#ffffff"/><rect x="${(cx + 12).toFixed(0)}" y="${(cy - 8).toFixed(0)}" width="${(w * 0.5).toFixed(0)}" height="9" rx="2" fill="#ffffff"/></g>`;
    }).join('');
    const hills = [0, 1, 2].map((i) => {
      const y = 78 + i * 17 + rnd(i + 1) * 8;
      return `<polygon points="0,${H} ${W * 0.18},${(y - 22).toFixed(0)} ${W * 0.42},${H} ${W},${H} ${W},${H}" fill="${i === 0 ? a : i === 1 ? b : c}" opacity="${0.42 - i * 0.08}"/>`;
    }).join('');
    const blocks = Array.from({ length: 7 }, (_, i) => {
      const bx = 22 + i * 51 + Math.round(rnd(i + 3) * 14); const by = 96 + Math.round(rnd(i + 5) * 22);
      return `<rect x="${bx}" y="${by}" width="17" height="17" rx="3" fill="${i % 2 ? b : a}" opacity="0.5"/>`;
    }).join('');
    return `<svg class="art" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="sky-${esc(s.id)}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${sky}" stop-opacity="0.92"/><stop offset="100%" stop-color="#05060c" stop-opacity="0.95"/>
        </linearGradient>
      </defs>
      <rect width="${W}" height="${H}" fill="url(#sky-${esc(s.id)})"/>
      <g opacity="0.5">${Array.from({ length: 12 }, (_, i) => `<rect x="0" y="${i * 11}" width="${W}" height="1" fill="#ffffff" opacity="0.03"/>`).join('')}</g>
      ${clouds}${hills}${blocks}
    </svg>`;
  }

  const STATUS_LABEL = { running: 'Running', starting: 'Starting', installing: 'Installing', stopping: 'Stopping', offline: 'Offline', crashed: 'Crashed', suspended: 'Suspended' };

  function tile(label, value, { icon = '', cls = '' } = {}) {
    return `<div class="srv-tile ${cls}"><div class="k">${icon}${esc(label)}</div><div class="v" title="${esc(String(value))}">${esc(String(value))}</div></div>`;
  }

  function card(s) {
    const stats = s.stats || {};
    const cpu = Number(stats.cpu || 0);
    const memPretty = stats.memoryPretty || (stats.memoryBytes ? fmt.bytes(stats.memoryBytes) : '0 B');
    const diskPretty = s.disk && s.disk.bytes ? s.disk.pretty : 'not measured';
    const diskLimitMb = s.diskLimit ? s.diskLimit : null;
    const diskWarn = diskLimitMb && s.disk && s.disk.bytes > diskLimitMb * 1048576 * 0.9;
    const host = location.hostname || 'this host';
    const addr = `${s.playit && s.playit.publicAddress ? s.playit.publicAddress : `${host}:${s.port}`}`;
    return `<div class="card srv-card server-card" data-id="${s.id}">
      <div class="srv-banner">
        ${bannerArt(s)}
        <span class="srv-type"><i class="dot" style="background:${(TYPE_COLORS[s.serverType] || ['#8fb8f0'])[0]}"></i>${esc(s.serverType)} ${esc(s.version || '')}</span>
        <span class="srv-pill ${esc(s.status)}"><i></i>${esc(STATUS_LABEL[s.status] || s.status)}</span>
        <div class="banner-title">
          <b><a href="server.html?id=${s.id}">${esc(s.name)}</a></b>
          <span>${esc(s.nodeName || 'Local Node')} · ${s.players || 0}/${s.maxPlayers || 20} online${s.backend ? ` · ${esc(s.backend)}` : ''}</span>
        </div>
      </div>
      <div class="srv-body">
        <div class="srv-tiles">
          ${tile('Node', s.nodeName || 'Local Node', { icon: ICONS.node })}
          ${tile('Address', addr, { icon: ICONS.globe })}
          ${tile('CPU usage', `${cpu.toFixed(1)}%`, { icon: ICONS.analytics, cls: cpu > 80 ? 'warn' : 'blue' })}
          ${tile('Memory', memPretty, { icon: ICONS.chip })}
          ${tile('Storage', diskPretty, { icon: ICONS.folder, cls: diskWarn ? 'warn' : '' })}
          ${tile('Players', `${s.players || 0} / ${s.maxPlayers || 20}`, { icon: ICONS.users2 })}
        </div>
        <div class="srv-foot">
          ${s.perms.console ? (s.status === 'running'
            ? `<button class="btn sm" data-power="restart" data-id="${s.id}" title="Restart">${ICONS.restart}</button>
               <button class="btn sm red" data-power="stop" data-id="${s.id}" title="Stop">${ICONS.stop}</button>`
            : `<button class="btn sm green" data-power="start" data-id="${s.id}" title="Start" ${s.status === 'installing' ? 'disabled' : ''}>${ICONS.play}</button>`) : ''}
          <span class="tiny dim" style="margin-left:2px">${s.uptime ? `up ${fmt.duration(s.uptime)}` : (s.status === 'offline' ? 'stopped' : esc(s.status))}</span>
          <div class="grow"></div>
          ${s.packages ? `<span class="chip">${s.packages} add-on${s.packages === 1 ? '' : 's'}</span>` : ''}
          <a class="btn sm" href="server.html?id=${s.id}">${ICONS.terminal} Console</a>
        </div>
      </div>
    </div>`;
  }

  function render(data) {
    const fleet = document.getElementById('fleetLine');
    if (fleet) {
      const mem = data.servers.reduce((n, s) => n + Number((s.stats && s.stats.memoryBytes) || 0), 0);
      fleet.textContent = data.servers.length
        ? `${data.servers.length} server(s) · ${data.running} running · ${fmt.bytes(mem)} in use right now`
        : '';
    }
    if (!data.servers.length) {
      grid.innerHTML = `<div style="grid-column:1/-1">${UI.empty('No servers found', 'Create a server to get started - it installs the jar for you.')}</div>`;
      return;
    }
    grid.innerHTML = data.servers.map(card).join('');
  }

  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-power]');
    if (!btn) return;
    btn.disabled = true;
    try {
      await API.post(`/servers/${btn.dataset.id}/${btn.dataset.power}`);
      UI.toast(`${btn.dataset.power} requested`, 'success');
      setTimeout(load, 1500);
    } catch (err) { UI.toast(err.message, 'error'); btn.disabled = false; }
  });

  let debounce;
  [searchInput, statusFilter, sortSelect].forEach((el) => el.addEventListener('input', () => {
    clearTimeout(debounce); debounce = setTimeout(load, 250);
  }));

  /* ------------------------------ create wizard ------------------------------ */
  async function openCreate() {
    catalogue = catalogue || await API.get('/system/catalogue');
    const state = {
      step: 1,
      name: '',
      serverType: 'PAPER',
      version: '',
      versions: [],
      memory: catalogue.defaultMemory || 2048,
      port: '',
      subdomain: '',
      maxPlayers: 20,
      eulaAccepted: true,
      autoStart: false,
      install: true,
      nodeId: 'local',
      backend: '', // '' = follow the node's own runtime
    };

    let nodes = [{ id: 'local', name: 'Local node', local: true, status: 'online' }];
    try {
      const res = await API.get('/nodes');
      nodes = res.nodes || nodes;
      // only nodes the panel can actually reach are selectable
      state.nodeId = (nodes.find((n) => n.id === 'local') || nodes[0]).id;
    } catch (_) { /* admin-only view; everyone can still use the local node */ }

    const m = UI.modal({
      title: 'Create a Minecraft server',
      wide: true,
      body: `
        <div class="steps" id="wizSteps"><div class="s active"></div><div class="s"></div><div class="s"></div></div>
        <div id="wizBody"></div>`,
      footer: `<button class="btn" data-close>Cancel</button>
               <button class="btn" id="wizPrev" style="display:none">Back</button>
               <button class="btn primary" id="wizNext">Continue</button>`,
      onMount(root, { close }) {
        root.querySelector('#wizPrev').onclick = () => { state.step = Math.max(1, state.step - 1); paint(); };
        root.querySelector('#wizNext').onclick = async () => {
          if (state.step < 3) {
            if (state.step === 1 && !readStep1()) return;
            state.step += 1;
            if (state.step === 2) await loadVersions();
            paint();
          } else {
            submit(close);
          }
        };
        paint();
        void close;

        function readStep1() {
          const body = root.querySelector('#wizBody');
          state.name = body.querySelector('[name=name]').value.trim();
          state.memory = parseInt(body.querySelector('[name=memory]').value, 10) || 2048;
          state.port = body.querySelector('[name=port]').value.trim();
          const subEl = body.querySelector('[name=subdomain]');
          if (subEl) state.subdomain = subEl.value.trim();
          state.maxPlayers = parseInt(body.querySelector('[name=maxPlayers]').value, 10) || 20;
          state.eulaAccepted = body.querySelector('[name=eula]').checked;
          state.autoStart = body.querySelector('[name=autoStart]').checked;
          const nodeEl = body.querySelector('[name=nodeId]');
          if (nodeEl) state.nodeId = nodeEl.value;
          const backendEl = body.querySelector('[name=backend]');
          if (backendEl) state.backend = backendEl.value;
          if (!state.name) { UI.toast('Give your server a name', 'error'); return false; }
          return true;
        }

        async function loadVersions() {
          if (versionCache[state.serverType]) { state.versions = versionCache[state.serverType]; return; }
          const body = root.querySelector('#wizBody');
          if (body) body.querySelector('#versionList').innerHTML = `<div class="tiny dim">Loading versions from the ${esc(state.serverType)} API...</div>`;
          try {
            const data = await API.get(`/system/versions/${state.serverType}`);
            state.versions = data.versions || [];
            versionCache[state.serverType] = state.versions;
            state.version = data.latest || (state.versions[0] && state.versions[0].id) || '';
          } catch (err) {
            state.versions = [];
            state.version = 'latest';
            UI.toast(`Could not load versions (${err.message}) - you can still install later`, 'warn');
          }
        }

        function paint() {
          const steps = root.querySelectorAll('#wizSteps .s');
          steps.forEach((s, i) => { s.className = `s ${i + 1 < state.step ? 'done' : i + 1 === state.step ? 'active' : ''}`; });
          root.querySelector('#wizPrev').style.display = state.step > 1 ? '' : 'none';
          root.querySelector('#wizNext').textContent = state.step === 3 ? 'Create & install' : 'Continue';
          const body = root.querySelector('#wizBody');

          if (state.step === 1) {
            body.innerHTML = `
              <div class="col" style="gap:14px">
                <label class="field">Server name
                  <input name="name" placeholder="Survival SMP" value="${esc(state.name)}" maxlength="60">
                </label>
                <div class="field-row">
                  <label class="field">Memory (MB)
                    <input type="number" name="memory" value="${state.memory}" min="256" step="256">
                    <span class="hint">Heap size for the JVM (-Xmx). 2 GB is fine for 10-20 players.</span>
                  </label>
                  <label class="field">Port <span class="dim tiny">(blank = auto)</span>
                    <input type="number" name="port" value="${state.port}" placeholder="25565" min="1024" max="65535">
                  </label>
                  <label class="field">Max players
                    <input type="number" name="maxPlayers" value="${state.maxPlayers}" min="1" max="1000">
                  </label>
                </div>
                <label class="field">Subdomain <span class="dim tiny">(optional)</span>
                  <input name="subdomain" value="${esc(state.subdomain)}" placeholder="survival" maxlength="40">
                  <span class="hint">Creates a hostname like <span class="mono">survival.your-domain.com</span> once an admin configures the base domain.</span>
                </label>
                ${nodes.length > 1 ? `
                <label class="field">Node
                  <select name="nodeId">
                    ${nodes.map((n) => `<option value="${esc(n.id)}" ${n.id === state.nodeId ? 'selected' : ''}>${esc(n.name)} · ${esc(n.status || 'unknown')}${n.local ? ' (this host)' : ` · ${esc(n.fqdn || '')}`}</option>`).join('')}
                  </select>
                  <span class="hint">Remote nodes need Java + a reachable agent port; the panel installs the jar there for you.</span>
                </label>` : ''}
                <label class="field">Runtime
                  <select name="backend">
                    <option value="" ${state.backend ? '' : 'selected'}>Follow the node (<span id="nodeRuntime">${esc((nodes.find((n) => n.id === state.nodeId) || {}).backend || 'process')}</span>)</option>
                    <option value="docker" ${state.backend === 'docker' ? 'selected' : ''}>Docker container - isolated, memory and CPU limited</option>
                    <option value="process" ${state.backend === 'process' ? 'selected' : ''}>Java process on the node host</option>
                  </select>
                  <span class="hint">Docker is validated against the node when the server is created: if the daemon cannot be reached, creation fails with the engine's own error instead of pretending a container will run.</span>
                </label>
                <label class="checkbox"><input type="checkbox" name="eula" ${state.eulaAccepted ? 'checked' : ''}>
                  <span>I accept the <b>Minecraft EULA</b> (<a href="https://aka.ms/MinecraftEULA" target="_blank" style="text-decoration:underline">minecraft.net/eula</a>) - required before the server can start</span></label>
                <label class="checkbox"><input type="checkbox" name="autoStart" ${state.autoStart ? 'checked' : ''}>
                  <span>Start this server automatically when the panel boots</span></label>
              </div>`;
          }

          if (state.step === 2) {
            body.innerHTML = `
              <div class="col" style="gap:14px">
                <div>
                  <div class="label tiny dim" style="margin-bottom:8px">Server software</div>
                  <div class="pick-grid">
                    ${catalogue.types.map((t) => `
                      <div class="pick ${t.id === state.serverType ? 'active' : ''}" data-type="${t.id}">
                        <b>${t.name}</b><span>${t.description}</span>
                        <div class="chips" style="margin-top:7px">
                          ${t.plugins ? '<span class="chip">plugins</span>' : ''}${t.mods ? '<span class="chip">mods</span>' : ''}${t.kind === 'proxy' ? '<span class="chip">proxy</span>' : ''}
                        </div>
                      </div>`).join('')}
                  </div>
                </div>
                <div>
                  <div class="row between" style="margin-bottom:8px">
                    <div class="label tiny dim">Version</div>
                    <input type="search" id="versionSearch" placeholder="filter versions..." style="max-width:200px" value="">
                  </div>
                  <div id="versionList" style="max-height:230px;overflow-y:auto;display:flex;flex-wrap:wrap;gap:7px">
                    ${state.versions.length ? state.versions.map((v) => `<div class="pick ${v.id === state.version ? 'active' : ''}" data-version="${esc(v.id)}" style="padding:7px 11px"><b style="font-family:var(--mono);font-size:12.5px">${esc(v.id)}</b></div>`).join('') : `<div class="tiny dim">Loading versions...</div>`}
                  </div>
                </div>
              </div>`;
            body.querySelectorAll('[data-type]').forEach((el) => el.onclick = async () => {
              state.serverType = el.dataset.type;
              await loadVersions();
              paint();
            });
            body.querySelectorAll('[data-version]').forEach((el) => el.onclick = () => {
              state.version = el.dataset.version;
              body.querySelectorAll('[data-version]').forEach((x) => x.classList.remove('active'));
              el.classList.add('active');
            });
            const vs = body.querySelector('#versionSearch');
            if (vs) vs.oninput = () => {
              const q = vs.value.toLowerCase();
              body.querySelectorAll('[data-version]').forEach((el) => {
                el.style.display = el.dataset.version.toLowerCase().includes(q) ? '' : 'none';
              });
            };
          }

          if (state.step === 3) {
            body.innerHTML = `
              <div class="col" style="gap:12px">
                <div class="banner-note green">${ICONS.check}<div><b>Ready to create</b><div class="tiny">${esc(state.name)} · ${esc(state.serverType)} ${esc(state.version || 'latest')} · ${state.memory} MB RAM</div></div></div>
                <dl class="kv">
                  <dt>Type</dt><dd>${esc(state.serverType)} ${esc(state.version || '')}</dd>
                  <dt>Memory</dt><dd>${state.memory} MB</dd>
                  <dt>Node</dt><dd>${esc((nodes.find((n) => n.id === state.nodeId) || { name: 'Local node' }).name)}</dd>
                  <dt>Port</dt><dd>${state.port || 'auto-allocated from the node range'}</dd>
                  <dt>Subdomain</dt><dd>${state.subdomain ? esc(state.subdomain) : '<span class="dim">none</span>'}</dd>
                  <dt>Max players</dt><dd>${state.maxPlayers}</dd>
                  <dt>Runtime</dt><dd>${state.backend === 'docker' ? 'Docker container' : state.backend === 'process' ? 'Java process' : `node default (${esc((nodes.find((n) => n.id === state.nodeId) || {}).backend || 'process')})`}</dd>
                  <dt>Auto start</dt><dd>${state.autoStart ? 'yes' : 'no'}</dd>
                </dl>
                <label class="checkbox"><input type="checkbox" name="install" ${state.install ? 'checked' : ''}>
                  <span>Download and install the server jar now (recommended - progress shows in the console)</span></label>
                <div class="tiny dim">Java is installed automatically: ${state.serverType === 'PAPER' || state.serverType === 'VANILLA' ? 'the panel fetches a matching Temurin JRE if the host has none.' : 'the loader installer runs in the background.'}</div>
                ${state.nodeId !== 'local' ? `<div class="banner-note"><div><b>Remote node selected</b><div class="tiny">The jar is downloaded, Java provisioned and the process started on <b>${esc((nodes.find((n) => n.id === state.nodeId) || {}).name || 'that node')}</b>. Console, power, stats and backups are proxied through the agent; the file manager and Modrinth installs operate on the panel host's copy.</div></div></div>` : ''}
              </div>`;
            const cb = body.querySelector('[name=install]');
            if (cb) cb.onchange = () => { state.install = cb.checked; };
          }

          const nodeSelect = body.querySelector('[name=nodeId]');
          if (nodeSelect) nodeSelect.onchange = () => {
            state.nodeId = nodeSelect.value;
            const label = body.querySelector('#nodeRuntime');
            if (label) label.textContent = (nodes.find((n) => n.id === state.nodeId) || {}).backend || 'process';
          };
        }

        async function submit(close) {
          const btn = root.querySelector('#wizNext');
          btn.disabled = true;
          btn.innerHTML = `${UI.spinner(14)} Creating...`;
          try {
            const installEl = root.querySelector('#wizBody [name=install]');
            if (installEl) state.install = installEl.checked;
            const res = await API.post('/servers', {
              name: state.name,
              serverType: state.serverType,
              version: state.version || 'latest',
              memory: state.memory,
              port: state.port || undefined,
              maxPlayers: state.maxPlayers,
              eulaAccepted: state.eulaAccepted,
              autoStart: state.autoStart,
              install: state.install,
              nodeId: state.nodeId,
              backend: state.backend || undefined,
              subdomain: state.subdomain || undefined,
            });
            UI.toast(`Server "${res.server.name}" created`, 'success');
            if (res.subdomainError) UI.toast(`Subdomain not created: ${res.subdomainError}`, 'warn');
            close();
            location.href = `server.html?id=${res.server.id}`;
          } catch (err) {
            UI.toast(err.message, 'error');
            btn.disabled = false;
            btn.textContent = 'Create & install';
          }
        }
      },
    });
    void m;
  }

  await load();
  if (new URLSearchParams(location.search).get('create') === '1' || location.hash === '#create') {
    history.replaceState(null, '', location.pathname);
    openCreate();
  }
})();
