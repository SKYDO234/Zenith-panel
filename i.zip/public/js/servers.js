/* Servers list + create-server wizard */
(async function () {
  const grid = document.getElementById('serverGrid');
  const searchInput = document.getElementById('searchInput');
  const statusFilter = document.getElementById('statusFilter');
  const sortSelect = document.getElementById('sortSelect');
  let catalogue = null;
  let versionCache = {};

  try { await bootstrap({ active: 'servers.html' }); } catch (_) { return; }

  const canCreate = () => ['admin', 'owner'].includes(store.user?.role);
  Layout.title('Servers', 'all instances you can access');
  Layout.actions(canCreate() ? `<button class="btn sm primary" id="createBtn">${ICONS.plus} Create server</button>` : '');
  document.getElementById('createBtn')?.addEventListener('click', openCreate);
  document.getElementById('refreshBtn').onclick = () => load();

  /* layout switch: 1 / 2 / 3 columns, remembered per browser */
  const viewToggle = document.getElementById('viewToggle');
  function setView(n) {
    grid.classList.remove('cards-1', 'cards-2', 'cards-3');
    grid.classList.add(`cards-${n}`);
    viewToggle.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.view === String(n)));
    try { localStorage.setItem('zenith.serverView', String(n)); } catch (_) {}
  }
  viewToggle.querySelectorAll('button').forEach((b) => b.onclick = () => setView(Number(b.dataset.view)));
  try { setView(Number(localStorage.getItem('zenith.serverView')) || 2); } catch (_) { setView(2); }

  async function load() {
    const params = new URLSearchParams();
    if (searchInput.value) params.set('search', searchInput.value);
    if (statusFilter.value) params.set('status', statusFilter.value);
    if (sortSelect.value) params.set('sort', sortSelect.value);
    params.set('withUsage', 'disk');
    try {
      const data = await API.get(`/servers?${params}`);
      Layout.setServerCount(data.total);
      render(data);
    } catch (err) {
      grid.innerHTML = `<div class="banner-note red">${ICONS.warn}<div>${esc(err.message)}</div></div>`;
    }
  }

  /* Deterministic "mini world" banner: pure inline SVG (works offline and in
     sandboxed previews). Colours come from the server type, shape from its id. */
  const TYPE_COLORS = {
    PAPER: ['#7ec8a0', '#5aa9ff', '#f0c674', '#32607a'],
    VANILLA: ['#8fd694', '#6fc3e0', '#e8e2c0', '#3c6b53'],
    PURPUR: ['#c39bf5', '#7f6ad8', '#f3bde4', '#3b2f63'],
    FABRIC: ['#f0d9a8', '#9ad3c6', '#ffb27a', '#4a5b6e'],
    QUILT: ['#c9a8f0', '#f5c9e0', '#8fd694', '#3f3a63'],
    FORGE: ['#d8b48a', '#8a6a4a', '#c9d8e0', '#3a3226'],
    NEOFORGE: ['#f0a868', '#e07850', '#ffd9a8', '#4a3a30'],
    SPIGOT: ['#f0c674', '#d8a04a', '#8fd694', '#3f3a2a'],
    BUNGEECORD: ['#c9b6f0', '#8fa8e0', '#f0d9a8', '#33355c'],
    VELOCITY: ['#8fd6f0', '#5aa9ff', '#c9f0e0', '#28455c'],
  };
  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < String(str).length; i++) { h ^= String(str).charCodeAt(i); h = Math.imul(h, 16777619); }
    return Math.abs(h);
  }
  function bannerArt(s) {
    const seed = hash(s.id + s.name);
    const [a, b, c, sky] = TYPE_COLORS[s.serverType] || ['#8fb8f0', '#7f8ce0', '#f0d9a8', '#2b3550'];
    const rnd = (n) => ((seed >> (n * 3)) % 1000) / 1000;
    const W = 400; const H = 132;
    const clouds = [0, 1].map((i) => {
      const cx = 40 + rnd(i) * (W - 120); const cy = 18 + rnd(i + 4) * 44; const w = 46 + rnd(i + 7) * 62;
      return `<g opacity="${0.24 + rnd(i + 2) * 0.22}"><rect x="${cx.toFixed(0)}" y="${cy.toFixed(0)}" width="${w.toFixed(0)}" height="9" rx="2" fill="#ffffff"/><rect x="${(cx + 12).toFixed(0)}" y="${(cy - 8).toFixed(0)}" width="${(w * 0.5).toFixed(0)}" height="9" rx="2" fill="#ffffff"/></g>`;
    }).join('');
    const hills = [0, 1, 2].map((i) => {
      const y = 78 + i * 17 + rnd(i + 1) * 8;
      return `<polygon points="0,${H} ${W * 0.18},${(y - 22).toFixed(0)} ${W * 0.42},${H} ${W},${H} ${W},${H}" fill="${i === 0 ? a : i === 1 ? b : c}" opacity="${0.42 - i * 0.08}"/>`;
    }).join('');
    const blocks = Array.from({ length: 7 }, (_, i) => {
      const bx = 22 + i * 51 + Math.round(rnd(i + 3) * 14); const by = 96 + Math.round(rnd(i + 5) * 22);
      return `<rect x="${bx}" y="${by}" width="17" height="17" rx="3" fill="${i % 2 ? b : a}" opacity="0.5"/>`;
    }).join('');
    return `<svg class="art" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="sky-${esc(s.id)}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${sky}" stop-opacity="0.92"/><stop offset="100%" stop-color="#05060c" stop-opacity="0.95"/>
        </linearGradient>
      </defs>
      <rect width="${W}" height="${H}" fill="url(#sky-${esc(s.id)})"/>
      <g opacity="0.5">${Array.from({ length: 12 }, (_, i) => `<rect x="0" y="${i * 11}" width="${W}" height="1" fill="#ffffff" opacity="0.03"/>`).join('')}</g>
      ${clouds}${hills}${blocks}
    </svg>`;
  }

  const STATUS_LABEL = { running: 'Running', starting: 'Starting', installing: 'Installing', stopping: 'Stopping', offline: 'Offline', crashed: 'Crashed', suspended: 'Suspended' };

  function tile(label, value, { icon = '', cls = '' } = {}) {
    return `<div class="srv-tile ${cls}"><div class="k">${icon}${esc(label)}</div><div class="v" title="${esc(String(value))}">${esc(String(value))}</div></div>`;
  }

  function card(s) {
    const stats = s.stats || {};
    const cpu = Number(stats.cpu || 0);
    const memPretty = stats.memoryPretty || (stats.memoryBytes ? fmt.bytes(stats.memoryBytes) : '0 B');
    const diskPretty = s.disk && s.disk.bytes ? s.disk.pretty : 'not measured';
    const diskLimitMb = s.diskLimit ? s.diskLimit : null;
    const diskWarn = diskLimitMb && s.disk && s.disk.bytes > diskLimitMb * 1048576 * 0.9;
    const host = location.hostname || 'this host';
    const addr = `${s.playit && s.playit.publicAddress ? s.playit.publicAddress : `${host}:${s.port}`}`;
    return `<div class="card srv-card server-card" data-id="${s.id}">
      <div class="srv-banner">
        ${bannerArt(s)}
        <span class="srv-type"><i class="dot" style="background:${(TYPE_COLORS[s.serverType] || ['#8fb8f0'])[0]}"></i>${esc(s.serverType)} ${esc(s.version || '')}</span>
        <span class="srv-pill ${esc(s.status)}"><i></i>${esc(STATUS_LABEL[s.status] || s.status)}</span>
        <div class="banner-title">
          <b><a href="server.html?id=${s.id}">${esc(s.name)}</a></b>
          <span>${esc(s.nodeName || 'Local Node')} · ${s.players || 0}/${s.maxPlayers || 20} online${s.backend ? ` · ${esc(s.backend)}` : ''}</span>
        </div>
      </div>
      <div class="srv-body">
        <div class="srv-tiles">
          ${tile('Node', s.nodeName || 'Local Node', { icon: ICONS.node })}
          ${tile('Address', addr, { icon: ICONS.globe })}
          ${tile('CPU usage', `${cpu.toFixed(1)}%`, { icon: ICONS.analytics, cls: cpu > 80 ? 'warn' : 'blue' })}
          ${tile('Memory', memPretty, { icon: ICONS.chip })}
          ${tile('Storage', diskPretty, { icon: ICONS.folder, cls: diskWarn ? 'warn' : '' })}
          ${tile('Players', `${s.players || 0} / ${s.maxPlayers || 20}`, { icon: ICONS.users2 })}
        </div>
        <div class="srv-foot">
          ${s.perms.console ? (s.status === 'running'
            ? `<button class="btn sm" data-power="restart" data-id="${s.id}" title="Restart">${ICONS.restart}</button>
               <button class="btn sm red" data-power="stop" data-id="${s.id}" title="Stop">${ICONS.stop}</button>`
            : `<button class="btn sm green" data-power="start" data-id="${s.id}" title="Start" ${s.status === 'installing' ? 'disabled' : ''}>${ICONS.play}</button>`) : ''}
          <span class="tiny dim" style="margin-left:2px">${s.uptime ? `up ${fmt.duration(s.uptime)}` : (s.status === 'offline' ? 'stopped' : esc(s.status))}</span>
          <div class="grow"></div>
          ${s.packages ? `<span class="chip">${s.packages} add-on${s.packages === 1 ? '' : 's'}</span>` : ''}
          <a class="btn sm" href="server.html?id=${s.id}">${ICONS.terminal} Console</a>
        </div>
      </div>
    </div>`;
  }

  function render(data) {
    const fleet = document.getElementById('fleetLine');
    if (fleet) {
      const mem = data.servers.reduce((n, s) => n + Number((s.stats && s.stats.memoryBytes) || 0), 0);
      fleet.textContent = data.servers.length
        ? `${data.servers.length} server(s) · ${data.running} running · ${fmt.bytes(mem)} in use right now`
        : '';
    }
    if (!data.servers.length) {
      const message = canCreate()
        ? 'Create a server to get started - it installs the jar for you.'
        : 'Ask an administrator to create a server and assign you access.';
      grid.innerHTML = `<div style="grid-column:1/-1">${UI.empty('No servers found', message)}</div>`;
      return;
    }
    grid.innerHTML = data.servers.map(card).join('');
  }

  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-power]');
    if (!btn) return;
    btn.disabled = true;
    try {
      await API.post(`/servers/${btn.dataset.id}/${btn.dataset.power}`);
      UI.toast(`${btn.dataset.power} requested`, 'success');
      setTimeout(load, 1500);
    } catch (err) { UI.toast(err.message, 'error'); btn.disabled = false; }
  });

  let debounce;
  [searchInput, statusFilter, sortSelect].forEach((el) => el.addEventListener('input', () => {
    clearTimeout(debounce); debounce = setTimeout(load, 250);
  }));

  /* ------------------------------ create wizard ------------------------------ */
  function openCreate() {
    if (!canCreate()) {
      UI.toast('Only an administrator can create servers.', 'error');
      return;
    }
    UI.modal({
      title: 'Create a workload',
      narrow: true,
      body: `<div class="workload-chooser"><span class="eyebrow">Provisioning</span><h2>What do you want to create?</h2><p>Choose a Minecraft server or an isolated Docker workload. Docker workloads use a real local Docker daemon and provide an SSHX browser-session link after creation.</p><div class="workload-choice-grid"><button class="workload-choice" data-workload="minecraft"><span class="workload-choice-icon blue">${ICONS.servers}</span><span><b>Minecraft server</b><small>Paper, Fabric, Forge and other supported distributions with an upstream version picker.</small></span><i>${ICONS.play}</i></button><button class="workload-choice" data-workload="container"><span class="workload-choice-icon violet">${ICONS.container}</span><span><b>Docker container</b><small>Ubuntu, Debian, Python or Node.js with files and an SSHX browser terminal.</small></span><i>${ICONS.play}</i></button></div></div>`,
      footer: '<button class="btn" data-close>Cancel</button>',
      onMount(root, { close }) {
        root.querySelectorAll('[data-workload]').forEach((button) => button.onclick = () => {
          const kind = button.dataset.workload; close();
          if (kind === 'container') openContainerCreate(); else openMinecraftCreate();
        });
      },
    });
  }

  async function openMinecraftCreate() {
    if (!canCreate()) return UI.toast('Only an administrator can create servers.', 'error');
    try { catalogue = catalogue || await API.get('/system/catalogue'); }
    catch (err) { UI.toast(`Could not load the server catalogue: ${err.message}`, 'error'); return; }

    const isAdmin = ['admin', 'owner'].includes(store.user?.role);
    const stepLabels = ['Details', 'Version', 'Review'];
    const state = {
      step: 1, busy: false, loadingVersions: false, versionError: '',
      name: '', description: '', serverType: 'PAPER', version: '', versions: [],
      memory: catalogue.defaultMemory || 2048, diskLimit: 0, cpuLimit: 0, maxPlayers: 20,
      port: '', ip: '', subdomain: '', ownerId: store.user?.id || '',
      eulaAccepted: false, autoStart: false, install: true, nodeId: 'local', backend: '',
    };
    let nodes = [{ id: 'local', name: 'Local node', local: true, status: 'online', backend: 'process' }];
    let owners = [{ id: store.user?.id || '', username: store.user?.username || 'You', role: store.user?.role || 'user' }];
    try {
      const res = await API.get('/nodes');
      nodes = res.nodes || nodes;
      const available = nodes.filter((n) => n.status !== 'offline');
      state.nodeId = (available.find((n) => n.id === 'local') || available[0] || nodes[0]).id;
    } catch (_) { /* non-admins can still create on the local node */ }
    if (isAdmin) {
      try {
        const res = await API.get('/users');
        owners = (res.users || []).filter((user) => !user.suspended);
      } catch (err) { UI.toast(`Could not load owner accounts: ${err.message}`, 'warn'); }
    }

    UI.modal({
      title: 'New Minecraft server', wide: true,
      body: `<section class="create-wizard" id="createWizard">
        <div class="create-wizard-top"><div><span class="eyebrow">Provisioning</span><h2>Create a server</h2><p>Set the server limits, select the exact upstream version, then confirm the installation.</p></div><span class="wizard-counter" id="wizCounter">Step 1 of 3</span></div>
        <nav class="wizard-steps three" id="wizSteps" aria-label="Server creation steps"></nav>
        <div class="wizard-panel" id="wizBody"></div>
      </section>`,
      footer: `<button class="btn ghost" data-close>Cancel</button><button class="btn" id="wizPrev">Back</button><button class="btn primary" id="wizNext">Continue</button>`,
      onMount(root, { close }) {
        const body = root.querySelector('#wizBody');
        const next = root.querySelector('#wizNext');
        const prev = root.querySelector('#wizPrev');
        const owner = () => owners.find((user) => user.id === state.ownerId) || owners[0] || { username: 'Unknown user' };
        const node = () => nodes.find((n) => n.id === state.nodeId) || nodes[0] || { name: 'Local node', backend: 'process' };
        const type = () => catalogue.types.find((t) => t.id === state.serverType) || catalogue.types[0];
        const value = (name) => body.querySelector(`[name="${name}"]`);

        prev.onclick = () => { if (!state.busy && state.step > 1) { state.step -= 1; paint(); } };
        next.onclick = () => advance();
        paint();

        function readDetails() {
          const name = value('name');
          const nextType = value('serverType')?.value || state.serverType;
          state.name = name?.value.trim() || state.name;
          state.description = value('description')?.value.trim() || '';
          state.memory = Math.max(256, parseInt(value('memory')?.value, 10) || 2048);
          state.diskLimit = Math.max(0, parseInt(value('diskLimit')?.value, 10) || 0);
          state.cpuLimit = Math.max(0, parseInt(value('cpuLimit')?.value, 10) || 0);
          state.maxPlayers = Math.max(1, parseInt(value('maxPlayers')?.value, 10) || 20);
          state.port = value('port')?.value.trim() || '';
          state.ip = value('ip')?.value.trim() || '';
          state.subdomain = value('subdomain')?.value.trim() || '';
          state.eulaAccepted = Boolean(value('eula')?.checked);
          state.autoStart = Boolean(value('autoStart')?.checked);
          if (value('ownerId')) state.ownerId = value('ownerId').value;
          if (value('nodeId')) state.nodeId = value('nodeId').value;
          if (value('backend')) state.backend = value('backend').value;
          if (nextType !== state.serverType) {
            state.serverType = nextType; state.version = ''; state.versions = []; state.versionError = '';
          }
          if (!state.name) { UI.toast('Give your server a name before continuing', 'error'); name?.focus(); return false; }
          if (state.name.length > 60) { UI.toast('Server name must be 60 characters or fewer', 'error'); return false; }
          if (state.description.length > 500) { UI.toast('Description must be 500 characters or fewer', 'error'); return false; }
          if (!state.eulaAccepted) { UI.toast('Accept the Minecraft EULA before creating a server', 'warn'); return false; }
          return true;
        }

        async function loadVersions(force = false) {
          if (!force && versionCache[state.serverType]) {
            state.versions = versionCache[state.serverType];
            state.version = state.version || state.versions[0]?.id || '';
            return;
          }
          state.versionError = '';
          try {
            const data = await API.get(`/system/versions/${state.serverType}`);
            state.versions = Array.isArray(data.versions) ? data.versions : [];
            versionCache[state.serverType] = state.versions;
            state.version = data.latest || state.versions[0]?.id || '';
            if (!state.version) state.versionError = 'The upstream did not return any selectable versions.';
          } catch (err) {
            state.versions = []; state.version = '';
            state.versionError = `Could not load versions for ${state.serverType}: ${err.message}`;
          }
        }

        async function advance() {
          if (state.busy) return;
          if (state.step === 1 && !readDetails()) return;
          if (state.step === 3) { submit(); return; }
          if (state.step === 2 && !state.version) { UI.toast('Select a server version before reviewing', 'warn'); return; }
          state.busy = true;
          if (state.step === 1) {
            state.step = 2;
            state.loadingVersions = true;
            paint(); // Version is painted before its provider request can resolve.
            await loadVersions();
            state.loadingVersions = false;
          } else state.step = 3;
          state.busy = false;
          paint();
        }

        function stepNav() {
          root.querySelector('#wizCounter').textContent = `Step ${state.step} of ${stepLabels.length}`;
          root.querySelector('#wizSteps').innerHTML = stepLabels.map((label, i) => {
            const number = i + 1;
            const status = number < state.step ? 'done' : number === state.step ? 'active' : '';
            return `<button type="button" class="wizard-step ${status}" data-step="${number}" ${number > state.step || state.busy ? 'disabled' : ''}><i>${number < state.step ? ICONS.check : number}</i><span>${label}</span></button>`;
          }).join('');
          root.querySelectorAll('[data-step]').forEach((button) => button.onclick = () => { if (!state.busy) { state.step = Number(button.dataset.step); paint(); } });
          prev.style.visibility = state.step === 1 ? 'hidden' : '';
          prev.disabled = state.busy;
          next.disabled = state.busy || (state.step === 2 && (state.loadingVersions || !state.version));
          next.textContent = state.step === 1 ? 'Choose version' : state.step === 2 ? 'Review server' : 'Create server';
        }

        function detailPage() {
          const ownerField = isAdmin
            ? `<label class="field">Owner<select name="ownerId">${owners.map((user) => `<option value="${esc(user.id)}" ${user.id === state.ownerId ? 'selected' : ''}>${esc(user.username)} · ${esc(user.role || 'user')}</option>`).join('')}</select><span class="hint">The account that owns this server.</span></label>`
            : `<label class="field">Owner<input value="${esc(owner().username)}" disabled><span class="hint">Servers you create belong to you.</span></label>`;
          const ipField = isAdmin
            ? `<label class="field">IP address <span class="field-optional">Optional</span><input name="ip" value="${esc(state.ip)}" placeholder="Automatic · 0.0.0.0"><span class="hint">Admin-managed bind address; editable later.</span></label>`
            : `<label class="field">IP allocation<input value="Automatic allocation" disabled><span class="hint">An administrator may set a bind IP later.</span></label>`;
          return `<div class="wizard-content"><div class="wizard-intro"><span class="wizard-intro-icon">${ICONS.servers}</span><div><h3>Server details</h3><p>Set ownership and hard resource limits before choosing the Minecraft version.</p></div></div>
            <div class="create-field-grid">
              <label class="field field-wide">Server name<input name="name" placeholder="Survival SMP" value="${esc(state.name)}" maxlength="60" autofocus><span class="hint">Visible to everyone with access to this server.</span></label>
              <label class="field field-wide">Description <span class="field-optional">Optional</span><textarea name="description" maxlength="500" placeholder="A short description for your players">${esc(state.description)}</textarea><span class="hint">Shown on server cards and in Administration.</span></label>
              <label class="field">Server software<select name="serverType">${catalogue.types.map((software) => `<option value="${esc(software.id)}" ${software.id === state.serverType ? 'selected' : ''}>${esc(software.name)} — ${esc(software.description)}</option>`).join('')}</select><span class="hint">Choose the distribution before versions load.</span></label>
              ${ownerField}
              <label class="field">RAM<input type="number" name="memory" value="${state.memory}" min="256" step="256"><span class="hint">MB memory limit</span></label>
              <label class="field">Disk<input type="number" name="diskLimit" value="${state.diskLimit}" min="0" step="1024"><span class="hint">MB · 0 means no panel limit</span></label>
              <label class="field">CPU<input type="number" name="cpuLimit" value="${state.cpuLimit}" min="0" step="10"><span class="hint">Percent · 0 means no panel limit</span></label>
              <label class="field">Max players<input type="number" name="maxPlayers" value="${state.maxPlayers}" min="1" max="1000"><span class="hint">Player cap</span></label>
              ${ipField}
              <label class="field">Port <span class="field-optional">Optional</span><input type="number" name="port" value="${state.port}" placeholder="Auto allocate" min="1024" max="65535"><span class="hint">Leave blank to allocate automatically.</span></label>
              <label class="field">Subdomain <span class="field-optional">Optional</span><input name="subdomain" value="${esc(state.subdomain)}" placeholder="survival" maxlength="40"><span class="hint">Created when DNS is configured by an admin.</span></label>
              ${nodes.length > 1 ? `<label class="field">Node<select name="nodeId">${nodes.map((n) => `<option value="${esc(n.id)}" ${n.id === state.nodeId ? 'selected' : ''}>${esc(n.name)} · ${esc(n.status || 'unknown')}</option>`).join('')}</select></label>` : ''}
              <label class="field ${nodes.length > 1 ? '' : 'field-wide'}">Runtime<select name="backend"><option value="" ${state.backend ? '' : 'selected'}>Use ${esc(node().name)} default (${esc(node().backend || 'process')})</option><option value="docker" ${state.backend === 'docker' ? 'selected' : ''}>Docker container — isolated and resource-limited</option><option value="process" ${state.backend === 'process' ? 'selected' : ''}>Java process — direct on the node</option></select></label>
            </div>
            <div class="wizard-toggles"><label class="checkbox wizard-check"><input type="checkbox" name="eula" ${state.eulaAccepted ? 'checked' : ''}><span><b>I accept the Minecraft EULA</b><small>Required before the server may start.</small></span></label><label class="checkbox wizard-check"><input type="checkbox" name="autoStart" ${state.autoStart ? 'checked' : ''}><span><b>Start on panel boot</b><small>Start this server when the panel restarts.</small></span></label></div>
          </div>`;
        }

        function versionPage() {
          const cards = state.versions.map((version) => `<button type="button" class="version-card ${version.id === state.version ? 'active' : ''}" data-version="${esc(version.id)}"><span>${esc(version.id)}</span>${version.id === state.version ? ICONS.check : ''}</button>`).join('');
          return `<div class="wizard-content"><div class="wizard-intro"><span class="wizard-intro-icon blue">${ICONS.star}</span><div><h3>Choose ${esc(type()?.name || state.serverType)} version</h3><p>Versions are loaded directly from the selected software provider.</p></div></div>
            <div class="version-toolbar"><span class="badge blue">${esc(state.serverType)}</span>${state.version ? `<span class="tiny dim">Selected <b class="mono">${esc(state.version)}</b></span>` : '<span class="tiny dim">Select a version to continue</span>'}<input type="search" id="versionSearch" placeholder="Filter versions…" ${state.loadingVersions ? 'disabled' : ''}></div>
            <div class="version-list" id="versionList">${state.loadingVersions ? `<div class="version-loading">${UI.spinner(18)}<span>Loading real ${esc(state.serverType)} versions…</span></div>` : state.versionError ? `<div class="version-error"><span>${ICONS.warn}</span><div><b>Versions could not be loaded</b><small>${esc(state.versionError)}</small></div><button class="btn sm" id="retryVersions">Retry</button></div>` : cards || '<div class="empty-version">No versions are available for this software right now.</div>'}</div>
          </div>`;
        }

        function reviewPage() {
          return `<div class="wizard-content"><div class="wizard-intro"><span class="wizard-intro-icon green">${ICONS.check}</span><div><h3>Ready to provision</h3><p>Review the owner, resource limits, and real software version before creating the server.</p></div></div>
            <div class="review-hero"><div><b>${esc(state.name)}</b><span>${esc(type()?.name || state.serverType)} · ${esc(state.version)} · ${state.memory} MB RAM</span>${state.description ? `<small>${esc(state.description)}</small>` : ''}</div><span class="badge green"><i class="dot green"></i>Ready</span></div>
            <dl class="review-grid"><div><dt>Owner</dt><dd>${esc(owner().username)}</dd></div><div><dt>Software</dt><dd>${esc(type()?.name || state.serverType)}</dd></div><div><dt>Version</dt><dd>${esc(state.version)}</dd></div><div><dt>RAM</dt><dd>${state.memory} MB</dd></div><div><dt>Disk</dt><dd>${state.diskLimit ? `${state.diskLimit} MB` : 'No panel limit'}</dd></div><div><dt>CPU</dt><dd>${state.cpuLimit ? `${state.cpuLimit}%` : 'No panel limit'}</dd></div><div><dt>IP</dt><dd>${esc(state.ip || 'Automatic allocation')}</dd></div><div><dt>Port</dt><dd>${state.port || 'Automatic allocation'}</dd></div><div><dt>Node</dt><dd>${esc(node().name)}</dd></div></dl>
            <label class="checkbox wizard-check install-check"><input type="checkbox" name="install" ${state.install ? 'checked' : ''}><span><b>Install server files now</b><small>Downloads the selected jar and matching Java runtime. Progress continues in the console.</small></span></label>
          </div>`;
        }

        function bindPage() {
          body.querySelectorAll('[data-version]').forEach((button) => button.onclick = () => {
            state.version = button.dataset.version;
            body.querySelectorAll('[data-version]').forEach((item) => item.classList.toggle('active', item === button));
            next.disabled = false;
          });
          body.querySelector('#versionSearch')?.addEventListener('input', (event) => {
            const query = event.target.value.toLowerCase();
            body.querySelectorAll('[data-version]').forEach((item) => { item.hidden = !item.dataset.version.toLowerCase().includes(query); });
          });
          body.querySelector('#retryVersions')?.addEventListener('click', async () => {
            if (state.loadingVersions) return;
            state.loadingVersions = true; paint(); await loadVersions(true); state.loadingVersions = false; paint();
          });
        }

        function paint() { stepNav(); body.innerHTML = state.step === 1 ? detailPage() : state.step === 2 ? versionPage() : reviewPage(); bindPage(); }

        async function submit() {
          if (state.busy) return;
          state.install = Boolean(value('install')?.checked ?? state.install);
          state.busy = true; next.disabled = true; next.innerHTML = `${UI.spinner(14)} Creating…`;
          try {
            const res = await API.post('/servers', {
              name: state.name, description: state.description, ownerId: state.ownerId,
              serverType: state.serverType, version: state.version, memory: state.memory,
              diskLimit: state.diskLimit, cpuLimit: state.cpuLimit, maxPlayers: state.maxPlayers,
              ip: state.ip || undefined, port: state.port || undefined, eulaAccepted: state.eulaAccepted,
              autoStart: state.autoStart, install: state.install, nodeId: state.nodeId,
              backend: state.backend || undefined, subdomain: state.subdomain || undefined,
            });
            UI.toast(`Server “${res.server.name}” created`, 'success');
            if (res.subdomainError) UI.toast(`Subdomain not created: ${res.subdomainError}`, 'warn');
            close(); location.href = `server.html?id=${res.server.id}`;
          } catch (err) { UI.toast(err.message, 'error'); state.busy = false; paint(); }
        }
      },
    });
  }


  async function openContainerCreate() {
    if (!canCreate()) return UI.toast('Only an administrator can create servers.', 'error');
    const templates = [
      { id: 'ubuntu-22.04', name: 'Ubuntu 22.04', image: 'ubuntu:22.04', note: 'General Linux VM-style workload', tone: 'orange' },
      { id: 'ubuntu-20.04', name: 'Ubuntu 20.04', image: 'ubuntu:20.04', note: 'Compatible Ubuntu environment', tone: 'orange' },
      { id: 'debian-12', name: 'Debian 12', image: 'debian:12', note: 'Current stable Debian workload', tone: 'blue' },
      { id: 'debian-11', name: 'Debian 11', image: 'debian:11', note: 'Previous Debian stable release', tone: 'blue' },
      { id: 'python-3.12', name: 'Python 3.12', image: 'python:3.12-slim', note: 'Ready for Python bots and apps', tone: 'green' },
      { id: 'node-20', name: 'Node.js 20', image: 'node:20-bookworm-slim', note: 'Ready for Node.js bots and apps', tone: 'green' },
    ];
    let owners = [{ id: store.user?.id || '', username: store.user?.username || 'You', role: store.user?.role || 'owner' }];
    try {
      const result = await API.get('/users');
      owners = (result.users || []).filter((user) => !user.suspended);
    } catch (err) { UI.toast(`Could not load owner accounts: ${err.message}`, 'error'); return; }

    const labels = ['Details', 'Image', 'Review'];
    const state = { step: 1, busy: false, name: '', description: '', memory: 2048, diskLimit: 0, cpuLimit: 100, ownerId: store.user?.id || owners[0]?.id || '', template: '', install: true };
    UI.modal({
      title: 'New Docker container', wide: true,
      body: `<section class="create-wizard container-wizard" id="containerWizard"><div class="create-wizard-top"><div><span class="eyebrow">Docker workload</span><h2>Create an isolated container</h2><p>Images are pulled from Docker Hub by the local Docker daemon. The container receives a persistent /data directory, real limits, files, backups, and a shell.</p></div><span class="wizard-counter" id="containerCounter">Step 1 of 3</span></div><nav class="wizard-steps three" id="containerSteps" aria-label="Container creation steps"></nav><div class="wizard-panel" id="containerBody"></div></section>`,
      footer: `<button class="btn ghost" data-close>Cancel</button><button class="btn" id="containerPrev">Back</button><button class="btn primary" id="containerNext">Continue</button>`,
      onMount(root, { close }) {
        const body = root.querySelector('#containerBody');
        const next = root.querySelector('#containerNext');
        const prev = root.querySelector('#containerPrev');
        const owner = () => owners.find((user) => user.id === state.ownerId) || owners[0] || { username: 'Unknown user' };
        const image = () => templates.find((template) => template.id === state.template);
        const field = (name) => body.querySelector(`[name="${name}"]`);
        prev.onclick = () => { if (!state.busy && state.step > 1) { state.step -= 1; paint(); } };
        next.onclick = () => advance();
        paint();

        function readDetails() {
          const name = field('name');
          state.name = name?.value.trim() || '';
          state.description = field('description')?.value.trim() || '';
          state.memory = Math.max(256, parseInt(field('memory')?.value, 10) || 2048);
          state.diskLimit = Math.max(0, parseInt(field('diskLimit')?.value, 10) || 0);
          state.cpuLimit = Math.max(1, parseInt(field('cpuLimit')?.value, 10) || 100);
          state.ownerId = field('ownerId')?.value || state.ownerId;
          if (!state.name) { UI.toast('Give this container a name before continuing', 'error'); name?.focus(); return false; }
          if (state.name.length > 60) { UI.toast('Container name must be 60 characters or fewer', 'error'); return false; }
          if (state.description.length > 500) { UI.toast('Description must be 500 characters or fewer', 'error'); return false; }
          return true;
        }
        function advance() {
          if (state.busy) return;
          if (state.step === 1 && !readDetails()) return;
          if (state.step === 2 && !state.template) { UI.toast('Select a container image before continuing', 'warn'); return; }
          if (state.step === 3) { submit(); return; }
          state.step += 1; paint();
        }
        function nav() {
          root.querySelector('#containerCounter').textContent = `Step ${state.step} of ${labels.length}`;
          root.querySelector('#containerSteps').innerHTML = labels.map((label, index) => { const number = index + 1; const status = number < state.step ? 'done' : number === state.step ? 'active' : ''; return `<button type="button" class="wizard-step ${status}" data-container-step="${number}" ${number > state.step || state.busy ? 'disabled' : ''}><i>${number < state.step ? ICONS.check : number}</i><span>${label}</span></button>`; }).join('');
          root.querySelectorAll('[data-container-step]').forEach((button) => button.onclick = () => { if (!state.busy) { state.step = Number(button.dataset.containerStep); paint(); } });
          prev.style.visibility = state.step === 1 ? 'hidden' : '';
          prev.disabled = state.busy;
          next.disabled = state.busy || (state.step === 2 && !state.template);
          next.textContent = state.step === 1 ? 'Choose image' : state.step === 2 ? 'Review container' : 'Create container';
        }
        function details() {
          return `<div class="wizard-content"><div class="wizard-intro"><span class="wizard-intro-icon violet">${ICONS.container}</span><div><h3>Container details</h3><p>The workload runs only in Docker on the local node. It is not simulated and a Docker daemon error is shown exactly if provisioning fails.</p></div></div><div class="create-field-grid"><label class="field field-wide">Container name<input name="name" placeholder="Discord bot" value="${esc(state.name)}" maxlength="60" autofocus><span class="hint">Used in the panel and Docker runtime record.</span></label><label class="field field-wide">Description <span class="field-optional">Optional</span><textarea name="description" maxlength="500" placeholder="What this bot or workload does">${esc(state.description)}</textarea></label><label class="field">Owner<select name="ownerId">${owners.map((user) => `<option value="${esc(user.id)}" ${user.id === state.ownerId ? 'selected' : ''}>${esc(user.username)} · ${esc(user.role || 'user')}</option>`).join('')}</select><span class="hint">Gets access to this container.</span></label><label class="field">RAM<input type="number" name="memory" value="${state.memory}" min="256" step="256"><span class="hint">MB hard Docker memory limit</span></label><label class="field">Disk<input type="number" name="diskLimit" value="${state.diskLimit}" min="0" step="1024"><span class="hint">MB · 0 means no panel limit</span></label><label class="field">CPU<input type="number" name="cpuLimit" value="${state.cpuLimit}" min="1" step="10"><span class="hint">Percent · hard Docker CPU limit</span></label><div class="container-note field-wide"><span>${ICONS.folder}</span><div><b>Persistent files at <code>/data</code></b><small>The Files tab maps to this directory. It survives container restarts and is included in panel backups.</small></div></div></div></div>`;
        }
        function images() {
          return `<div class="wizard-content"><div class="wizard-intro"><span class="wizard-intro-icon blue">${ICONS.container}</span><div><h3>Select an image</h3><p>The selected image is automatically pulled by Docker after you create the container.</p></div></div><div class="container-image-grid">${templates.map((template) => `<button type="button" class="container-image-choice ${state.template === template.id ? 'active' : ''}" data-template="${template.id}"><span class="container-image-icon ${template.tone}">${template.family === 'bot' ? ICONS.terminal : ICONS.container}</span><span><b>${esc(template.name)}</b><small>${esc(template.note)}</small><code>${esc(template.image)}</code></span><i>${state.template === template.id ? ICONS.check : ''}</i></button>`).join('')}</div></div>`;
        }
        function review() {
          const selected = image();
          return `<div class="wizard-content"><div class="wizard-intro"><span class="wizard-intro-icon green">${ICONS.check}</span><div><h3>Ready to create</h3><p>Docker will pull the selected image, create the isolated workload, then start it with a persistent <code>/data</code> directory.</p></div></div><div class="review-hero"><div><b>${esc(state.name)}</b><span>${esc(selected?.name || '')} · ${state.memory} MB RAM · Docker workload</span>${state.description ? `<small>${esc(state.description)}</small>` : ''}</div><span class="badge green"><i class="dot green"></i>Ready</span></div><dl class="review-grid"><div><dt>Owner</dt><dd>${esc(owner().username)}</dd></div><div><dt>Image</dt><dd>${esc(selected?.image || '')}</dd></div><div><dt>RAM</dt><dd>${state.memory} MB</dd></div><div><dt>Disk</dt><dd>${state.diskLimit ? `${state.diskLimit} MB` : 'No panel limit'}</dd></div><div><dt>CPU</dt><dd>${state.cpuLimit}% hard cgroup limit</dd></div><div><dt>Console</dt><dd>Logs + SSHX link</dd></div></dl><div class="container-review-note"><span>${ICONS.terminal}</span><div><b>SSHX runs inside this container</b><small>After the container is prepared, Console displays SSHX’s generated browser-session link for its real terminal.</small></div></div></div>`;
        }
        function bind() { body.querySelectorAll('[data-template]').forEach((button) => button.onclick = () => { state.template = button.dataset.template; paint(); }); }
        function paint() { nav(); body.innerHTML = state.step === 1 ? details() : state.step === 2 ? images() : review(); bind(); }
        async function submit() {
          if (state.busy) return;
          state.busy = true; next.disabled = true; next.innerHTML = `${UI.spinner(14)} Creating…`;
          try {
            const response = await API.post('/servers', { workloadType: 'container', containerTemplate: state.template, serverType: 'CONTAINER', name: state.name, description: state.description, ownerId: state.ownerId, memory: state.memory, diskLimit: state.diskLimit, cpuLimit: state.cpuLimit, backend: 'docker', install: true });
            UI.toast(`Container “${response.server.name}” is being created`, 'success'); close(); location.href = `server.html?id=${response.server.id}`;
          } catch (err) { UI.toast(err.message, 'error'); state.busy = false; paint(); }
        }
      },
    });
  }


  await load();
  if (new URLSearchParams(location.search).get('create') === '1' || location.hash === '#create') {
    history.replaceState(null, '', location.pathname);
    if (canCreate()) openCreate();
  }
})();
