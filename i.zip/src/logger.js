'use strict';
const db = require('./db');

const COLORS = { reset: '\x1b[0m', gray: '\x1b[90m', green: '\x1b[32m', yellow: '\x1b[33m', red: '\x1b[31m', cyan: '\x1b[36m', magenta: '\x1b[35m' };

function stamp() { return new Date().toISOString().replace('T', ' ').slice(0, 19); }

function write(level, scope, msg) {
  const color = { info: COLORS.cyan, warn: COLORS.yellow, error: COLORS.red, debug: COLORS.gray, ok: COLORS.green }[level] || COLORS.reset;
  const line = `${COLORS.gray}${stamp()}${COLORS.reset} ${color}${level.toUpperCase().padEnd(5)}${COLORS.reset} ${COLORS.magenta}[${scope}]${COLORS.reset} ${msg}`;
  (level === 'error' ? console.error : console.log)(line);
}

const logger = {
  info: (scope, msg) => write('info', scope, msg),
  ok: (scope, msg) => write('ok', scope, msg),
  warn: (scope, msg) => write('warn', scope, msg),
  error: (scope, msg) => write('error', scope, msg),
  debug: (scope, msg) => process.env.DEBUG && write('debug', scope, msg),
  /** persist an audit-trail entry */
  activity(actor, action, meta = {}) {
    try { db.log({ actor, action, ...meta }); } catch (_) {}
  },
};

module.exports = logger;
