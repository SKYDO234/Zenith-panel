'use strict';
const express = require('express');
const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const auth = require('../auth');
const { uid } = require('../utils');

const router = express.Router();

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,24}$/;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

/** Public panel info (used by the login screen before authentication). */
router.get('/panel', (req, res) => {
  res.json({
    panelName: db.settings().panelName || cfg.panelName,
    theme: db.settings().theme || 'midnight',
    accentColor: db.settings().accentColor || '#3b82f6',
    panelLogo: db.settings().panelLogo || '',
    panelBackground: db.settings().panelBackground || '',
    panelBackgroundOpacity: Number.isFinite(Number(db.settings().panelBackgroundOpacity)) ? Number(db.settings().panelBackgroundOpacity) : 28,
    allowRegistration: db.settings().allowRegistration ?? cfg.allowRegistration,
    registrationOpen: db.settings().allowRegistration ?? cfg.allowRegistration,
    needsSetup: (db.get('users') || []).length === 0,
    version: cfg.version,
    node: process.version,
  });
});

router.post('/login', async (req, res) => {
  // `install.sh` (and scripts/createuser.js) write the owner straight into
  // data/db.json. Pick that up before we look the account up, otherwise a
  // freshly installed panel answers "Invalid credentials" to the owner it
  // just created.
  try { db.reloadIfChanged(); } catch (_) {}
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password are required' });
  const key = `${req.ip}:${String(username).toLowerCase()}`;
  if (auth.attemptsLeft(key) <= 0) {
    return res.status(429).json({ error: 'Too many failed attempts. Try again later.' });
  }
  const user = db.find('users', (u) => u.username.toLowerCase() === String(username).toLowerCase() || (u.email && u.email.toLowerCase() === String(username).toLowerCase()));
  if (!user || !(await auth.verifyPassword(password, auth.hashOf(user)))) {
    auth.registerAttempt(key);
    logger.warn('auth', `failed login for ${username} from ${req.ip}`);
    return res.status(401).json({ error: 'Invalid credentials', attemptsLeft: auth.attemptsLeft(key) });
  }
  if (user.suspended) return res.status(403).json({ error: 'This account is suspended' });
  auth.clearAttempts(key);
  db.update('users', user.id, { lastLoginAt: new Date().toISOString(), lastLoginIp: req.ip });
  db.log({ actor: user.username, action: 'auth.login', detail: req.ip });
  res.json({ token: auth.signToken(user), user: auth.publicUser({ ...user, lastLoginAt: new Date().toISOString() }) });
});

router.post('/register', async (req, res) => {
  try { db.reloadIfChanged(); } catch (_) {}
  const settings = db.settings();
  const registrationOpen = settings.allowRegistration ?? cfg.allowRegistration;
  const userCount = (db.get('users') || []).length;
  if (!registrationOpen && userCount > 0) return res.status(403).json({ error: 'Registration is disabled - ask an administrator for an account' });
  const { username, password, email } = req.body || {};
  if (!USERNAME_RE.test(String(username || ''))) return res.status(400).json({ error: 'Username must be 3-24 characters (letters, numbers, . _ -)' });
  if (String(password || '').length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (email && !EMAIL_RE.test(email)) return res.status(400).json({ error: 'Invalid e-mail address' });
  if (db.find('users', (u) => u.username.toLowerCase() === String(username).toLowerCase())) return res.status(409).json({ error: 'That username is taken' });

  const isFirst = userCount === 0;
  const user = {
    id: uid('usr'),
    username,
    email: email || '',
    password: await auth.hashPassword(password),
    role: isFirst ? 'owner' : 'user',
    passwordVersion: 0,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    suspended: false,
  };
  db.insert('users', user);
  db.log({ actor: user.username, action: 'auth.register', detail: isFirst ? 'first user (owner)' : 'user' });
  res.status(201).json({ token: auth.signToken(user), user: auth.publicUser(user) });
});

router.get('/me', auth.authenticate, (req, res) => {
  const servers = (db.get('servers') || []).filter((s) => auth.canAccess(req.user, s)).length;
  res.json({ user: auth.publicUser(req.user), servers, settings: publicSettings() });
});

router.post('/password', auth.authenticate, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (String(newPassword || '').length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
  if (!(await auth.verifyPassword(currentPassword, auth.hashOf(req.user)))) return res.status(401).json({ error: 'Current password is incorrect' });
  db.update('users', req.user.id, {
    password: await auth.hashPassword(newPassword),
    passwordVersion: (req.user.passwordVersion || 0) + 1,
    passwordChangedAt: new Date().toISOString(),
  });
  db.log({ actor: req.user.username, action: 'auth.password' });
  res.json({ ok: true, message: 'Password updated - other sessions were signed out' });
});

router.patch('/profile', auth.authenticate, (req, res) => {
  const patch = {};
  if (req.body.email !== undefined) {
    if (req.body.email && !EMAIL_RE.test(req.body.email)) return res.status(400).json({ error: 'Invalid e-mail address' });
    patch.email = req.body.email;
  }
  if (req.body.avatarColor !== undefined) patch.avatarColor = String(req.body.avatarColor).slice(0, 32);
  if (req.body.avatar !== undefined) {
    const avatar = String(req.body.avatar || '');
    if (avatar === '') patch.avatar = '';
    else if (!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(avatar)) return res.status(400).json({ error: 'Avatars must be PNG/JPEG/WebP data URLs' });
    else if (avatar.length > 220000) return res.status(413).json({ error: 'That image is too large - crop it to something smaller' });
    else patch.avatar = avatar;
  }
  const user = db.update('users', req.user.id, patch);
  res.json({ user: auth.publicUser(user) });
});

function publicSettings() {
  const s = db.settings();
  return {
    panelName: s.panelName,
    theme: s.theme || 'midnight',
    accentColor: s.accentColor || '#3b82f6',
    panelLogo: s.panelLogo || '',
    panelBackground: s.panelBackground || '',
    panelBackgroundOpacity: Number.isFinite(Number(s.panelBackgroundOpacity)) ? Number(s.panelBackgroundOpacity) : 28,
    allowRegistration: s.allowRegistration ?? cfg.allowRegistration,
    defaultMemory: s.defaultMemory,
    defaultPort: s.defaultPort,
    maxServersPerUser: s.maxServersPerUser,
    version: cfg.version,
  };
}
exports.publicSettings = publicSettings;

module.exports = router;
