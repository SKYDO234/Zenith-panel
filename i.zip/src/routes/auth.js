'use strict';
const express = require('express');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const auth = require('../auth');
const { uid } = require('../utils');

const router = express.Router();

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,24}$/;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

/* ------------------------- external identities ------------------------- */
// OAuth callback state and browser-token exchanges are intentionally short lived
// and one-time. They contain no panel JWT and are safe to discard after a restart.
const discordStates = new Map();
const browserExchanges = new Map();
let firebaseCerts = { until: 0, keys: {} };

function pruneExternalAuth() {
  const now = Date.now();
  for (const [key, value] of discordStates) if (!value || value.expiresAt <= now) discordStates.delete(key);
  for (const [key, value] of browserExchanges) if (!value || value.expiresAt <= now) browserExchanges.delete(key);
}
setInterval(pruneExternalAuth, 10 * 60e3).unref();

function oauthSettings() {
  const s = db.settings() || {};
  const firebaseReady = Boolean(s.firebaseGoogleEnabled && s.firebaseApiKey && s.firebaseAuthDomain && s.firebaseProjectId && s.firebaseAppId);
  const discordClientId = String(s.discordOAuthClientId || process.env.DISCORD_OAUTH_CLIENT_ID || '').trim();
  const discordSecret = String(s.discordOAuthClientSecret || process.env.DISCORD_OAUTH_CLIENT_SECRET || '').trim();
  return {
    allowSignup: s.oauthAllowRegistration === true,
    firebase: firebaseReady ? {
      apiKey: String(s.firebaseApiKey), authDomain: String(s.firebaseAuthDomain), projectId: String(s.firebaseProjectId), appId: String(s.firebaseAppId),
    } : null,
    discord: s.discordOAuthEnabled && discordClientId && discordSecret ? { clientId: discordClientId, clientSecret: discordSecret } : null,
  };
}

function panelOrigin(req) {
  // PANEL_URL is the deliberate, documented authority for OAuth redirects.
  // It avoids trusting an arbitrary Host header sent to a reverse proxy.
  const configured = String(cfg.panelUrl || '').replace(/\/+$/, '');
  try {
    const url = new URL(configured);
    if (url.protocol === 'https:' || url.protocol === 'http:') return configured;
  } catch (_) {}
  return `${req.protocol}://${req.get('host')}`;
}

function readCookie(req, name) {
  const raw = String(req.headers.cookie || '');
  const pair = raw.split(';').map((item) => item.trim()).find((item) => item.startsWith(`${name}=`));
  if (!pair) return '';
  try { return decodeURIComponent(pair.slice(name.length + 1)); } catch (_) { return ''; }
}
function sameSecret(left, right) {
  if (!left || !right) return false;
  const a = Buffer.from(String(left)); const b = Buffer.from(String(right));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function setDiscordStateCookie(res, state, secure) {
  res.setHeader('Set-Cookie', `zenith_discord_state=${encodeURIComponent(state)}; Max-Age=600; Path=/api/auth/discord; HttpOnly; SameSite=Lax${secure ? '; Secure' : ''}`);
}
function clearDiscordStateCookie(res, secure) {
  res.setHeader('Set-Cookie', `zenith_discord_state=; Max-Age=0; Path=/api/auth/discord; HttpOnly; SameSite=Lax${secure ? '; Secure' : ''}`);
}
function externalUsername(seed, provider) {
  const clean = String(seed || provider).toLowerCase().replace(/[^a-z0-9_.-]+/g, '-').replace(/^[._-]+|[._-]+$/g, '') || provider;
  const base = clean.slice(0, 20).padEnd(3, 'user');
  let candidate = base;
  let index = 2;
  while (db.find('users', (user) => String(user.username || '').toLowerCase() === candidate.toLowerCase())) {
    const suffix = `-${index++}`;
    candidate = `${base.slice(0, 24 - suffix.length)}${suffix}`;
  }
  return candidate;
}

async function establishExternalUser({ provider, subject, email, displayName, ip }) {
  const normalizedEmail = String(email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(normalizedEmail)) throw Object.assign(new Error(`${provider} did not return a verified e-mail address`), { status: 400 });
  const key = provider === 'google' ? 'google' : 'discord';
  let user = db.find('users', (item) => item.oauthProviders && String(item.oauthProviders[key] || '') === String(subject));
  if (!user) {
    user = db.find('users', (item) => String(item.email || '').toLowerCase() === normalizedEmail);
    if (user && user.oauthProviders && user.oauthProviders[key] && String(user.oauthProviders[key]) !== String(subject)) {
      throw Object.assign(new Error(`This e-mail is already linked to a different ${provider} account`), { status: 409 });
    }
  }
  if (!user) {
    if (!oauthSettings().allowSignup) throw Object.assign(new Error('OAuth sign-up is disabled. Ask an administrator for an account or enable OAuth sign-up in Panel Settings.'), { status: 403 });
    user = {
      id: uid('usr'), username: externalUsername(displayName || normalizedEmail.split('@')[0], key), email: normalizedEmail,
      password: '', role: 'user', passwordVersion: 0, createdAt: new Date().toISOString(), lastLoginAt: new Date().toISOString(),
      suspended: false, oauthProviders: { [key]: String(subject) },
    };
    db.insert('users', user);
    db.log({ actor: user.username, action: 'auth.oauth_register', detail: provider });
  } else {
    if (user.suspended) throw Object.assign(new Error('This account is suspended'), { status: 403 });
    user = db.update('users', user.id, {
      email: user.email || normalizedEmail,
      oauthProviders: { ...(user.oauthProviders || {}), [key]: String(subject) },
      lastLoginAt: new Date().toISOString(), lastLoginIp: ip,
    });
    db.log({ actor: user.username, action: 'auth.oauth_login', detail: provider });
  }
  if (user.suspended) throw Object.assign(new Error('This account is suspended'), { status: 403 });
  return { token: auth.signToken(user), user: auth.publicUser(user) };
}

async function firebaseSigningKeys() {
  if (firebaseCerts.until > Date.now() && Object.keys(firebaseCerts.keys).length) return firebaseCerts.keys;
  const response = await fetch('https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com', { signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error(`Google signing-key service returned HTTP ${response.status}`);
  const keys = await response.json();
  const cache = String(response.headers.get('cache-control') || '').match(/max-age=(\d+)/);
  firebaseCerts = { keys, until: Date.now() + Math.max(60, Math.min(86400, Number(cache && cache[1]) || 3600)) * 1000 };
  return keys;
}
async function verifyFirebaseGoogleToken(idToken, firebase) {
  const decoded = jwt.decode(String(idToken || ''), { complete: true });
  if (!decoded || !decoded.header || !decoded.header.kid) throw Object.assign(new Error('Firebase returned an invalid ID token'), { status: 401 });
  const keys = await firebaseSigningKeys();
  const certificate = keys[decoded.header.kid];
  if (!certificate) throw Object.assign(new Error('Firebase token signing key is not recognised; sign in again'), { status: 401 });
  return new Promise((resolve, reject) => jwt.verify(String(idToken), certificate, {
    algorithms: ['RS256'], audience: firebase.projectId, issuer: `https://securetoken.google.com/${firebase.projectId}`,
  }, (err, payload) => err ? reject(Object.assign(new Error(`Firebase token verification failed: ${err.message}`), { status: 401 })) : resolve(payload)));
}
function issueBrowserExchange(result) {
  pruneExternalAuth();
  const code = crypto.randomBytes(32).toString('base64url');
  browserExchanges.set(code, { ...result, expiresAt: Date.now() + 2 * 60e3 });
  return code;
}

/** Public panel info (used by the login screen before authentication). */
router.get('/panel', (req, res) => {
  res.json({
    panelName: db.settings().panelName || cfg.panelName,
    theme: db.settings().theme || 'midnight',
    accentColor: db.settings().accentColor || '#3b82f6',
    panelLogo: db.settings().panelLogo || '',
    panelBackground: db.settings().panelBackground || '',
    panelBackgroundOpacity: Number.isFinite(Number(db.settings().panelBackgroundOpacity)) ? Number(db.settings().panelBackgroundOpacity) : 28,
    allowRegistration: db.settings().allowRegistration ?? cfg.allowRegistration,
    registrationOpen: db.settings().allowRegistration ?? cfg.allowRegistration,
    oauthRegistrationOpen: oauthSettings().allowSignup,
    authProviders: {
      google: oauthSettings().firebase ? { enabled: true, firebase: oauthSettings().firebase } : { enabled: false },
      discord: oauthSettings().discord ? { enabled: true } : { enabled: false },
    },
    needsSetup: (db.get('users') || []).length === 0,
    version: cfg.version,
    node: process.version,
  });
});

/** Exchange a Firebase Google ID token only after cryptographically verifying it. */
router.post('/firebase/google', async (req, res) => {
  const providers = oauthSettings();
  if (!providers.firebase) return res.status(503).json({ error: 'Google sign-in is not configured by this panel administrator' });
  try {
    const payload = await verifyFirebaseGoogleToken(req.body && req.body.idToken, providers.firebase);
    if (!payload.email_verified || !payload.email || !payload.sub) return res.status(401).json({ error: 'Google must provide a verified e-mail address for this panel' });
    // Firebase signs provider data into this claim. Accepting a non-Google
    // Firebase token here would make the button label inaccurate.
    const provider = payload.firebase && payload.firebase.sign_in_provider;
    if (provider && provider !== 'google.com') return res.status(401).json({ error: 'This Firebase token was not issued by Google sign-in' });
    res.json(await establishExternalUser({ provider: 'google', subject: payload.sub, email: payload.email, displayName: payload.name || payload.email.split('@')[0], ip: req.ip }));
  } catch (err) {
    res.status(err.status || 401).json({ error: err.message || 'Google sign-in could not be verified' });
  }
});

/** Begin a Discord OAuth2 authorisation-code flow. */
router.get('/discord/start', (req, res) => {
  const providers = oauthSettings();
  if (!providers.discord) return res.status(503).send('Discord sign-in is not configured by this panel administrator');
  pruneExternalAuth();
  const state = crypto.randomBytes(32).toString('base64url');
  const origin = panelOrigin(req);
  const redirectUri = `${origin}/api/auth/discord/callback`;
  discordStates.set(state, { expiresAt: Date.now() + 10 * 60e3, redirectUri });
  setDiscordStateCookie(res, state, origin.startsWith('https://'));
  const url = new URL('https://discord.com/api/oauth2/authorize');
  url.searchParams.set('client_id', providers.discord.clientId);
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'identify email');
  url.searchParams.set('state', state);
  res.redirect(302, url.toString());
});

/** Finish Discord OAuth, keeping the panel JWT out of redirect URLs. */
router.get('/discord/callback', async (req, res) => {
  const providers = oauthSettings();
  const state = String(req.query.state || '');
  const entry = discordStates.get(state);
  const origin = panelOrigin(req);
  const returnToLogin = (error) => res.redirect(302, `${origin}/index.html?oauth_error=${encodeURIComponent(error)}`);
  clearDiscordStateCookie(res, origin.startsWith('https://'));
  discordStates.delete(state);
  if (!providers.discord) return returnToLogin('Discord sign-in is no longer configured');
  if (!entry || entry.expiresAt <= Date.now() || !sameSecret(state, readCookie(req, 'zenith_discord_state'))) return returnToLogin('Discord sign-in state expired or did not match. Try again.');
  if (req.query.error) return returnToLogin(`Discord authorisation was not completed: ${req.query.error_description || req.query.error}`);
  const code = String(req.query.code || '');
  if (!code) return returnToLogin('Discord did not return an authorisation code');
  try {
    const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, signal: AbortSignal.timeout(10000),
      body: new URLSearchParams({ client_id: providers.discord.clientId, client_secret: providers.discord.clientSecret, grant_type: 'authorization_code', code, redirect_uri: entry.redirectUri }),
    });
    const tokenBody = await tokenResponse.json().catch(() => ({}));
    if (!tokenResponse.ok || !tokenBody.access_token) throw new Error(tokenBody.error_description || `Discord token exchange returned HTTP ${tokenResponse.status}`);
    const userResponse = await fetch('https://discord.com/api/users/@me', { headers: { Authorization: `Bearer ${tokenBody.access_token}` }, signal: AbortSignal.timeout(10000) });
    const discordUser = await userResponse.json().catch(() => ({}));
    if (!userResponse.ok) throw new Error(discordUser.message || `Discord profile request returned HTTP ${userResponse.status}`);
    if (!discordUser.verified || !discordUser.email || !discordUser.id) throw Object.assign(new Error('Discord must provide a verified e-mail address; ensure the app requests identify and email scopes'), { status: 400 });
    const result = await establishExternalUser({ provider: 'discord', subject: discordUser.id, email: discordUser.email, displayName: discordUser.global_name || discordUser.username, ip: req.ip });
    return res.redirect(302, `${origin}/index.html?oauth=${encodeURIComponent(issueBrowserExchange(result))}`);
  } catch (err) {
    return returnToLogin(err.message || 'Discord sign-in failed');
  }
});

/** Consume a one-time Discord browser exchange code after the redirect. */
router.post('/oauth/complete', (req, res) => {
  pruneExternalAuth();
  const code = String(req.body && req.body.code || '');
  const result = browserExchanges.get(code);
  browserExchanges.delete(code);
  if (!result || result.expiresAt <= Date.now()) return res.status(400).json({ error: 'This sign-in link expired. Start Discord sign-in again.' });
  res.json({ token: result.token, user: result.user });
});

router.post('/login', async (req, res) => {
  // `install.sh` (and scripts/createuser.js) write the owner straight into
  // data/db.json. Pick that up before we look the account up, otherwise a
  // freshly installed panel answers "Invalid credentials" to the owner it
  // just created.
  try { db.reloadIfChanged(); } catch (_) {}
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password are required' });
  const key = `${req.ip}:${String(username).toLowerCase()}`;
  if (auth.attemptsLeft(key) <= 0) {
    return res.status(429).json({ error: 'Too many failed attempts. Try again later.' });
  }
  const user = db.find('users', (u) => u.username.toLowerCase() === String(username).toLowerCase() || (u.email && u.email.toLowerCase() === String(username).toLowerCase()));
  if (!user || !(await auth.verifyPassword(password, auth.hashOf(user)))) {
    auth.registerAttempt(key);
    logger.warn('auth', `failed login for ${username} from ${req.ip}`);
    return res.status(401).json({ error: 'Invalid credentials', attemptsLeft: auth.attemptsLeft(key) });
  }
  if (user.suspended) return res.status(403).json({ error: 'This account is suspended' });
  auth.clearAttempts(key);
  db.update('users', user.id, { lastLoginAt: new Date().toISOString(), lastLoginIp: req.ip });
  db.log({ actor: user.username, action: 'auth.login', detail: req.ip });
  res.json({ token: auth.signToken(user), user: auth.publicUser({ ...user, lastLoginAt: new Date().toISOString() }) });
});

router.post('/register', async (req, res) => {
  try { db.reloadIfChanged(); } catch (_) {}
  const settings = db.settings();
  const registrationOpen = settings.allowRegistration ?? cfg.allowRegistration;
  const userCount = (db.get('users') || []).length;
  if (!registrationOpen && userCount > 0) return res.status(403).json({ error: 'Registration is disabled - ask an administrator for an account' });
  const { username, password, email } = req.body || {};
  if (!USERNAME_RE.test(String(username || ''))) return res.status(400).json({ error: 'Username must be 3-24 characters (letters, numbers, . _ -)' });
  if (String(password || '').length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (email && !EMAIL_RE.test(email)) return res.status(400).json({ error: 'Invalid e-mail address' });
  if (db.find('users', (u) => u.username.toLowerCase() === String(username).toLowerCase())) return res.status(409).json({ error: 'That username is taken' });

  const isFirst = userCount === 0;
  const user = {
    id: uid('usr'),
    username,
    email: email || '',
    password: await auth.hashPassword(password),
    role: isFirst ? 'owner' : 'user',
    passwordVersion: 0,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    suspended: false,
  };
  db.insert('users', user);
  db.log({ actor: user.username, action: 'auth.register', detail: isFirst ? 'first user (owner)' : 'user' });
  res.status(201).json({ token: auth.signToken(user), user: auth.publicUser(user) });
});

router.get('/me', auth.authenticate, (req, res) => {
  const servers = (db.get('servers') || []).filter((s) => auth.canAccess(req.user, s)).length;
  res.json({ user: auth.publicUser(req.user), servers, settings: publicSettings() });
});

router.post('/password', auth.authenticate, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (String(newPassword || '').length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
  if (!(await auth.verifyPassword(currentPassword, auth.hashOf(req.user)))) return res.status(401).json({ error: 'Current password is incorrect' });
  db.update('users', req.user.id, {
    password: await auth.hashPassword(newPassword),
    passwordVersion: (req.user.passwordVersion || 0) + 1,
    passwordChangedAt: new Date().toISOString(),
  });
  db.log({ actor: req.user.username, action: 'auth.password' });
  res.json({ ok: true, message: 'Password updated - other sessions were signed out' });
});

router.patch('/profile', auth.authenticate, (req, res) => {
  const patch = {};
  if (req.body.email !== undefined) {
    if (req.body.email && !EMAIL_RE.test(req.body.email)) return res.status(400).json({ error: 'Invalid e-mail address' });
    patch.email = req.body.email;
  }
  if (req.body.avatarColor !== undefined) patch.avatarColor = String(req.body.avatarColor).slice(0, 32);
  if (req.body.avatar !== undefined) {
    const avatar = String(req.body.avatar || '');
    if (avatar === '') patch.avatar = '';
    else if (!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(avatar)) return res.status(400).json({ error: 'Avatars must be PNG/JPEG/WebP data URLs' });
    else if (avatar.length > 220000) return res.status(413).json({ error: 'That image is too large - crop it to something smaller' });
    else patch.avatar = avatar;
  }
  const user = db.update('users', req.user.id, patch);
  res.json({ user: auth.publicUser(user) });
});

function publicSettings() {
  const s = db.settings();
  return {
    panelName: s.panelName,
    theme: s.theme || 'midnight',
    accentColor: s.accentColor || '#3b82f6',
    panelLogo: s.panelLogo || '',
    panelBackground: s.panelBackground || '',
    panelBackgroundOpacity: Number.isFinite(Number(s.panelBackgroundOpacity)) ? Number(s.panelBackgroundOpacity) : 28,
    allowRegistration: s.allowRegistration ?? cfg.allowRegistration,
    defaultMemory: s.defaultMemory,
    defaultPort: s.defaultPort,
    maxServersPerUser: s.maxServersPerUser,
    version: cfg.version,
  };
}
exports.publicSettings = publicSettings;

module.exports = router;
