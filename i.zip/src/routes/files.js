'use strict';
/** File manager API - mounted at /api/servers/:id/files */
const express = require('express');
const path = require('path');
const multer = require('multer');
const cfg = require('../config');
const auth = require('../auth');
const files = require('../services/files');
const { exists, formatBytes } = require('../utils');

const router = express.Router({ mergeParams: true });
const upload = multer({ dest: path.join(cfg.dataDir, 'tmp'), limits: { fileSize: cfg.maxUploadSize } });

router.use(auth.authenticate, auth.serverScope('files'));

router.get('/', async (req, res) => {
  try {
    const data = await files.list(req.server, req.query.path || '', { showHidden: req.query.hidden !== 'false' });
    res.json(data);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/content', async (req, res) => {
  try {
    res.json(await files.read(req.server, req.query.path, { tail: req.query.tail ? parseInt(req.query.tail, 10) : undefined }));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/content', async (req, res) => {
  try {
    res.json(await files.write(req.server, req.body.path, req.body.content));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/mkdir', async (req, res) => {
  try {
    res.json(await files.mkdir(req.server, req.body.path));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/rename', async (req, res) => {
  try {
    res.json(await files.rename(req.server, req.body.from, req.body.to));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/copy', async (req, res) => {
  try {
    res.json(await files.copy(req.server, req.body.from, req.body.to));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/zip', async (req, res) => {
  try {
    res.json(await files.zip(req.server, req.body.path, req.body.name));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/unzip', async (req, res) => {
  try {
    res.json(await files.unzip(req.server, req.body.path, { to: req.body.to }));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/delete', async (req, res) => {
  try {
    res.json(await files.remove(req.server, req.body.paths || req.body.path));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/search', async (req, res) => {
  try {
    res.json({ results: await files.search(req.server, req.query.q, req.query.path || '') });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/download', async (req, res) => {
  try {
    const target = files.resolve(req.server, req.query.path);
    if (!(await exists(target))) return res.status(404).json({ error: 'File not found' });
    const stat = require('fs').statSync(target);
    if (stat.isDirectory()) {
      // zip on the fly for folder downloads
      const AdmZip = require('adm-zip');
      const zipFile = new AdmZip();
      zipFile.addLocalFolder(target, path.basename(target));
      const buf = zipFile.toBuffer();
      res.setHeader('Content-Disposition', `attachment; filename="${path.basename(target)}.zip"`);
      res.setHeader('Content-Type', 'application/zip');
      return res.send(buf);
    }
    await files.streamDownload(req.server, req.query.path, res);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/upload', upload.array('files', 25), async (req, res) => {
  try {
    const dir = req.body.path || '';
    const saved = [];
    for (const file of req.files || []) {
      saved.push(await files.saveUpload(req.server, dir, file.originalname, file.path));
    }
    res.json({ uploaded: saved, count: saved.length, totalPretty: formatBytes(saved.reduce((a, b) => a + b.size, 0)) });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/** Download a file from a URL straight into the server directory (e.g. a plugin jar). */
const { download } = require('../utils');
router.post('/pull', async (req, res) => {
  const { url, path: destPath, filename } = req.body || {};
  if (!/^https?:\/\//i.test(String(url || ''))) return res.status(400).json({ error: 'A http(s) url is required' });
  try {
    const name = filename || decodeURIComponent(new URL(url).pathname.split('/').pop()) || 'download.bin';
    const target = files.resolve(req.server, path.posix.join(String(destPath || '').replace(/\\/g, '/'), name));
    res.json({ ok: true, message: `Downloading ${name} in the background` });
    await download(url, target);
  } catch (err) { /* response already sent */ }
});

module.exports = router;
