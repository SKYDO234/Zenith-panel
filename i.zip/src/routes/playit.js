'use strict';
/** playit.gg tunnel API - mounted at /api/servers/:id/playit */
const express = require('express');
const auth = require('../auth');
const playit = require('../services/playit');
const db = require('../db');
const runtime = require('../services/runtime');

const router = express.Router({ mergeParams: true });
router.use(auth.authenticate, auth.serverScope('network'));

router.get('/', (req, res) => {
  const status = playit.status(req.server.id);
  res.json({
    ...status,
    instructions: [
      'Start the tunnel to install (first run only) and launch the playit agent.',
      'Open the claim link that appears below and sign in to your playit.gg account.',
      'In the playit dashboard create a tunnel: type "Minecraft Java", local address 127.0.0.1, local port ' + req.server.port + '.',
      'Copy the public address (for example example.playit.gg:12345) and share it with your players.',
    ],
    docs: 'https://playit.gg/',
  });
});

router.post('/start', async (req, res) => {
  try {
    const status = await playit.start(req.server, { secret: req.body.secret });
    runtime.state(req.server.id).logs.push('[playit] agent started');
    db.log({ actor: req.user.username, action: 'playit.start', serverId: req.server.id, serverName: req.server.name });
    res.json({ ok: true, status });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/stop', async (req, res) => {
  try {
    const status = await playit.stop(req.server.id);
    runtime.state(req.server.id).logs.push('[playit] agent stopped');
    res.json({ ok: true, status });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/reset', async (req, res) => {
  try {
    const status = await playit.reset(req.server.id);
    runtime.state(req.server.id).logs.push('[playit] tunnel reset - start it again to get a fresh claim link');
    res.json({ ok: true, status, message: 'Tunnel reset. Start it again to generate a new claim link.' });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/** Generate a fresh claim link without starting the daemon yet. */
router.post('/claim-url', async (req, res) => {
  try {
    const claim = await playit.claimUrl(req.server, { name: req.server.name });
    res.json({ ok: true, ...claim, status: playit.status(req.server.id) });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/claim', async (req, res) => {
  const status = await playit.markClaimed(req.server.id);
  res.json({ ok: true, status });
});

router.post('/secret', async (req, res) => {
  const { secret } = req.body || {};
  if (!secret) return res.status(400).json({ error: 'secret is required' });
  try {
    const status = await playit.setSecret(req.server, secret);
    runtime.state(req.server.id).logs.push('[playit] secret key updated');
    res.json({ ok: true, status });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/autostart', (req, res) => {
  const playitConf = { ...(req.server.playit || {}), autostart: !!req.body.autostart };
  db.update('servers', req.server.id, { playit: playitConf });
  res.json({ ok: true, playit: playitConf });
});

/** Download/refresh the agent binary. */
router.post('/install', async (req, res) => {
  try {
    const bin = await playit.ensureBinary((p) => runtime.setInstallProgress(req.server.id, { step: 'playit', percent: p.percent, note: `playit agent ${p.percent}%` }));
    runtime.state(req.server.id).logs.push(`[playit] agent installed at ${bin}`);
    runtime.setInstallProgress(req.server.id, { step: 'done', percent: 100, note: 'playit agent ready' });
    res.json({ ok: true, binary: bin });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/logs', (req, res) => {
  const logs = runtime.getLogs(req.server.id, 0).lines.map((l) => l.line).filter((l) => l.includes('[playit]'));
  res.json({ logs });
});

module.exports = router;
