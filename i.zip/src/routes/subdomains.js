'use strict';
/**
 * Subdomain endpoints (per server).
 *   GET    /api/servers/:id/subdomains          list + the suggested label
 *   POST   /api/servers/:id/subdomains          { sub, ip? } create DNS records
 *   DELETE /api/servers/:id/subdomains/:subId   remove them again
 *
 * Also exposes the panel-wide provider config through /api/settings/dns so the
 * admin UI can verify a token without leaving the page.
 */
const express = require('express');
const db = require('../db');
const auth = require('../auth');
const dns = require('../services/dns');
const { uid, formatBytes } = require('../utils');

const router = express.Router({ mergeParams: true });

function listFor(server) {
  return (server.subdomains || []).map((s) => ({
    ...s,
    address: `${s.host}:${s.port}`,
    srv: `_minecraft._tcp.${s.host}`,
    configured: dns.settings().provider === 'cloudflare',
  }));
}

router.get('/', auth.authenticate, auth.serverScope('network'), (req, res) => {
  const settings = dns.settings();
  const taken = (db.get('servers') || []).flatMap((s) => (s.subdomains || []).map((x) => x.sub));
  res.json({
    subdomains: listFor(req.server),
    baseDomain: settings.domain,
    provider: settings.provider,
    configured: dns.configured(),
    suggested: dns.suggest(req.server.name, taken),
    serverIp: req.server.ip || '0.0.0.0',
  });
});

router.post('/', auth.authenticate, auth.serverScope('network'), async (req, res) => {
  const { sub, ip } = req.body || {};
  const label = dns.slugify(sub);
  if (!label || label.length < 2) return res.status(400).json({ error: 'Pick a subdomain label (2+ characters: a-z, 0-9, -)' });
  const settings = dns.settings();
  if (!settings.domain) {
    return res.status(400).json({ error: 'No base domain configured yet - ask an admin to set it in Admin → Settings → Subdomains' });
  }
  const host = dns.fqdn(label, settings.domain);
  // the host must be unique across the whole panel, this server included
  const clash = (db.get('servers') || []).find((s) => (s.subdomains || []).some((x) => x.host === host));
  if (clash) return res.status(409).json({ error: `${host} is already used by "${clash.name}"` });

  try {
    const result = await dns.createRecords({ sub: label, name: req.server.name, port: req.server.port, ip: ip || settings.ip });
    const record = {
      id: uid('sub'),
      sub: label,
      host: result.host,
      port: req.server.port,
      provider: result.provider,
      records: result.created.length ? result.created : result.records,
      createdAt: new Date().toISOString(),
      createdBy: req.user.username,
    };
    db.update('servers', req.server.id, { subdomains: [...(req.server.subdomains || []), record] });
    db.log({ actor: req.user.username, action: 'subdomain.create', serverId: req.server.id, serverName: req.server.name, detail: host });
    res.status(201).json({
      subdomain: { ...record, address: `${record.host}:${record.port}`, srv: `_minecraft._tcp.${record.host}`, configured: result.provider === 'cloudflare' },
      manual: result.provider !== 'cloudflare',
      message: result.provider === 'cloudflare'
        ? `Players can now join ${record.host}`
        : `Create these records at your DNS provider, then players can join ${record.host}`,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/:subId', auth.authenticate, auth.serverScope('network'), async (req, res) => {
  const record = (req.server.subdomains || []).find((s) => s.id === req.params.subId);
  if (!record) return res.status(404).json({ error: 'Subdomain not found' });
  let removal = { deleted: [] };
  try {
    removal = await dns.deleteRecords({ sub: record.sub, port: record.port, ip: record.ip });
  } catch (err) {
    // Even if the provider call fails, the panel record goes away so the admin
    // is not stuck with a phantom entry.
    db.log({ actor: req.user.username, action: 'subdomain.delete.failed', serverId: req.server.id, detail: err.message });
  }
  db.update('servers', req.server.id, { subdomains: (req.server.subdomains || []).filter((s) => s.id !== req.params.subId) });
  db.log({ actor: req.user.username, action: 'subdomain.delete', serverId: req.server.id, serverName: req.server.name, detail: record.host });
  res.json({ ok: true, removed: record.host, provider: removal });
});

module.exports = router;
module.exports.listFor = listFor;
void formatBytes;
