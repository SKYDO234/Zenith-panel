'use strict';
/**
 * Admin + public system API.
 *   /api/system/*   health, live host stats, catalogue, java
 *   /api/users/*    user management (admin)
 *   /api/nodes/*    node management (admin)
 *   /api/settings   panel settings (admin)
 *   /api/activity   audit log
 */
const express = require('express');
const os = require('os');
const cfg = require('../config');
const db = require('../db');
const auth = require('../auth');
const logger = require('../logger');
const stats = require('../services/stats');
const fs = require('fs');
const path = require('path');
const { fetchJson } = require('../utils');
const versions = require('../services/versions');
const javaSvc = require('../services/java');
const nodesSvc = require('../services/nodes');
const runtime = require('../services/runtime');
const serverSvc = require('../services/servers');
const metrics = require('../services/metrics');
const dockerSvc = require('../services/docker');
const dns = require('../services/dns');
const discord = require('../services/discord');
const { uid, formatBytes, randomToken } = require('../utils');

const system = express.Router();

system.get('/health', (req, res) => {
  res.json({ ok: true, panel: cfg.panelName, version: cfg.version, time: new Date().toISOString(), uptime: process.uptime() });
});

system.get('/stats', auth.authenticate, async (req, res) => {
  const host = await stats.system();
  const servers = db.get('servers') || [];
  const visible = auth.isAdmin(req.user) ? servers : servers.filter((s) => auth.canAccess(req.user, s));
  const states = visible.map((s) => runtime.info(s.id));
  res.json({
    host,
    panel: {
      name: db.settings().panelName,
      version: cfg.version,
      node: process.version,
      pid: process.pid,
      memoryPretty: formatBytes(host.memoryOfPanel),
      startedAt: new Date(Date.now() - process.uptime() * 1000).toISOString(),
    },
    servers: {
      total: visible.length,
      running: states.filter((s) => s.status === 'running').length,
      starting: states.filter((s) => s.status === 'starting').length,
      offline: states.filter((s) => ['offline', 'crashed'].includes(s.status)).length,
      installing: states.filter((s) => s.status === 'installing').length,
      players: states.reduce((a, s) => a + (s.players ? s.players.length : 0), 0),
      cpu: Number(states.reduce((a, s) => a + (s.stats ? s.stats.cpu : 0), 0).toFixed(1)),
      memoryBytes: states.reduce((a, s) => a + (s.stats ? s.stats.memoryBytes || 0 : 0), 0),
    },
  });
});

/** Live per-server stats table (dashboard polling / websocket). */
system.get('/servers/live', auth.authenticate, async (req, res) => {
  const servers = (db.get('servers') || []).filter((s) => auth.canAccess(req.user, s));
  const out = [];
  for (const server of servers) {
    const info = runtime.info(server.id);
    out.push({ id: server.id, name: server.name, status: info.status, uptime: info.uptime, players: info.players.length, maxPlayers: server.maxPlayers, stats: info.stats, node: server.nodeName });
  }
  res.json({ servers: out });
});

system.get('/catalogue', auth.authenticate, async (req, res) => {
  res.json({ types: versions.TYPES, defaultMemory: db.settings().defaultMemory, defaultPort: db.settings().defaultPort });
});

system.get('/versions/:type', auth.authenticate, async (req, res) => {
  try {
    const data = await versions.listVersions(req.params.type);
    res.json({ ...data, recommendedJava: versions.javaFor(data.latest) });
  } catch (err) { res.status(502).json({ error: `Version lookup failed: ${err.message}` }); }
});

system.get('/java', auth.authenticate, async (req, res) => {
  res.json({
    required: versions.javaFor('1.21.4'),
    available: await javaSvc.list(),
    managedDir: cfg.javaDir,
    usage: await javaSvc.usage(),
  });
});

/** Disk report for the managed runtimes + prune of what no server needs. */
system.get('/java/usage', auth.authenticate, auth.requireAdmin, async (req, res) => {
  try { res.json(await javaSvc.usage()); } catch (err) { res.status(500).json({ error: err.message }); }
});

system.post('/java/prune', auth.authenticate, auth.requireAdmin, async (req, res) => {
  try {
    const result = await javaSvc.prune({ all: Boolean(req.body && req.body.all) });
    if (result.freed > 0) {
      db.log({ actor: req.user.username, action: 'java.prune', detail: `${result.removed.map((r) => `Java ${r.major}`).join(', ')} (${formatBytes(result.freed)})` });
    }
    res.json({
      ok: true,
      freed: result.freed,
      freedPretty: formatBytes(result.freed),
      removed: result.removed.map((r) => ({ major: r.major, bytes: r.bytes })),
      usage: await javaSvc.usage(),
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

system.post('/java/install', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const major = parseInt(req.body.version || '21', 10);
  res.json({ ok: true, message: `Installing Java ${major}...` });
  javaSvc.ensure(major).then((bin) => logger.ok('java', `installed: ${bin}`)).catch((err) => logger.error('java', err.message));
});

/**
 * Image proxy for the UI: Modrinth icons and player avatars are served through
 * the panel so the dashboard also works on locked-down networks (no external
 * requests from the browser). Only an allowlist of hosts is proxied.
 */
const PROXY_HOSTS = ['cdn.modrinth.com', 'minotar.net', 'mc-heads.net', 'api.mineatar.io'];
system.get('/proxy/image', auth.authenticate, async (req, res) => {
  const target = String(req.query.url || '');
  let parsed;
  try { parsed = new URL(target); } catch { return res.status(400).json({ error: 'Invalid url' }); }
  if (parsed.protocol !== 'https:' || !PROXY_HOSTS.some((h) => parsed.hostname === h || parsed.hostname.endsWith(`.${h}`))) {
    return res.status(400).json({ error: 'Host not allowed' });
  }
  try {
    const upstream = await fetch(parsed.toString(), { headers: { 'User-Agent': cfg.modrinthUA }, signal: AbortSignal.timeout(10000) });
    if (!upstream.ok) return res.status(502).json({ error: `Upstream ${upstream.status}` });
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'image/png');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.end(buf);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

system.get('/config', auth.authenticate, (req, res) => {
  res.json({
    panelName: db.settings().panelName || cfg.panelName,
    panelUrl: cfg.panelUrl,
    version: cfg.version,
    maxUploadSize: cfg.maxUploadSize,
    maxUploadPretty: formatBytes(cfg.maxUploadSize),
    dataDir: cfg.dataDir.replace(cfg.root, '.'),
    serverDir: cfg.serverDataDir.replace(cfg.root, '.'),
    backupDir: cfg.backupDir.replace(cfg.root, '.'),
    allowRegistration: db.settings().allowRegistration,
    nodeSecretSet: !!cfg.nodeSecret,
  });
});

/** Host + fleet history for the dashboard graphs (in-memory, last hour). */
system.get('/history', auth.authenticate, (req, res) => {
  const minutes = Math.min(720, Math.max(1, parseInt(req.query.minutes || '30', 10) || 30));
  const points = Math.min(400, Math.max(10, parseInt(req.query.points || '120', 10) || 120));
  res.json(metrics.history({ minutes, points }));
});

/** Port allocations per node: what is used, what is free, who owns it. */
system.get('/allocations', auth.authenticate, (req, res) => {
  if (!auth.isAdmin(req.user)) return res.status(403).json({ error: 'Admins only' });
  const servers = db.get('servers') || [];
  const nodes = (db.get('nodes') || []).map((node) => {
    const range = node.portRange || { start: 25565, end: 25665 };
    const total = range.end - range.start + 1;
    const used = servers.filter((s) => s.nodeId === node.id)
      .map((s) => ({ port: s.port, serverId: s.id, name: s.name, owner: s.ownerName, status: s.status, serverType: s.serverType, version: s.version }))
      .sort((a, b) => a.port - b.port);
    return {
      id: node.id, name: node.name, local: !!node.local, status: node.status,
      range, total, usedCount: used.length, freeCount: Math.max(0, total - used.length),
      used,
      nextFree: (() => {
        for (let p = range.start; p <= range.end; p += 1) if (!used.some((u) => u.port === p)) return p;
        return null;
      })(),
    };
  });
  res.json({ nodes, totalPorts: nodes.reduce((n, x) => n + x.total, 0), totalUsed: nodes.reduce((n, x) => n + x.usedCount, 0) });
});

/**
 * Docker engine status for the panel host. Reports exactly what the daemon
 * answers (or the exact error when it does not), never a placeholder.
 */
system.get('/docker', auth.authenticate, async (req, res) => {
  const summary = await dockerSvc.summary();
  const containers = summary.available ? await dockerSvc.listServers() : { ok: false, containers: [] };
  res.json({
    ...summary,
    containerCount: summary.containers,
    runningCount: summary.running,
    containers: containers.containers || [],
    containerError: containers.ok ? null : containers.error,
    backend: db.settings().dockerBackend || 'process',
  });
});

/** SFTP subsystem status (real listener state, not a guess). */
system.get('/sftp', auth.authenticate, async (req, res) => {
  const sftp = require('../services/sftp');
  res.json({ ...sftp.status(), sessions: sftp.state.active.size, active: [...sftp.state.active.values()] });
});

/** Toggle / re-bind the SFTP server; a failure returns the exact error. */
system.post('/sftp/:action', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const sftp = require('../services/sftp');
  try {
    if (req.params.action === 'restart') return res.json(await sftp.restart());
    if (req.params.action === 'stop') return res.json(await sftp.stop());
    if (req.params.action === 'start') return res.json(await sftp.start({ force: true }));
    return res.status(400).json({ error: 'Unknown action (start, stop, restart)' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

system.get('/docker/images', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const images = await dockerSvc.listImages();
  if (!images.ok) return res.status(503).json({ error: images.error || 'docker is not available' });
  res.json({ images: images.images });
});

system.post('/docker/pull', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const tag = String((req.body && req.body.image) || '').trim();
  if (!/^[a-z0-9][a-z0-9._/-]*(:[\w.-]+)?$/i.test(tag)) return res.status(400).json({ error: 'Give a valid image reference, e.g. eclipse-temurin:21-jre' });
  try {
    const result = await dockerSvc.ensureImage(tag, { retries: 2 });
    db.log({ actor: req.user.username, action: 'docker.pull', detail: tag });
    res.json(result);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

system.post('/docker/verify', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const summary = await dockerSvc.summary();
  if (!summary.available) return res.status(503).json({ ok: false, error: summary.error, checks: dockerSvc.probe({ force: true }) });
  const containers = await dockerSvc.listServers();
  res.json({ ok: true, engine: summary.engine, apiVersion: summary.apiVersion, storageDriver: summary.storageDriver, containers: containers.containers || [], checkedAt: summary.checkedAt });
});

/** Subdomain / DNS provider configuration (admin). */
system.get('/dns', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const settings = dns.settings();
  res.json({
    settings: { provider: settings.provider, domain: settings.domain, zone: settings.zone, ip: settings.ip, ttl: settings.ttl, tokenSet: Boolean(settings.token) },
    configured: dns.configured(),
  });
});

system.post('/dns/verify', auth.authenticate, auth.requireAdmin, async (req, res) => {
  res.json(await dns.verify());
});

/** Discord bot control: status, start, stop, restart, command reference. */
system.get('/discord', auth.authenticate, auth.requireAdmin, (req, res) => {
  res.json({
    ...discord.status(),
    reference: [...discord.commands.values()].map((c) => ({ name: c.name, usage: c.usage || '', help: c.help, adminOnly: !!c.adminOnly })),
  });
});

system.post('/discord/:action', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const action = req.params.action;
  try {
    if (action === 'start') {
      db.setSettings({ discordEnabled: true });
      const status = await discord.start();
      db.log({ actor: req.user.username, action: 'discord.start' });
      return res.json(status);
    }
    if (action === 'stop') {
      db.setSettings({ discordEnabled: false });
      const status = await discord.stop();
      db.log({ actor: req.user.username, action: 'discord.stop' });
      return res.json(status);
    }
    if (action === 'restart') {
      const status = await discord.restart();
      db.log({ actor: req.user.username, action: 'discord.restart' });
      return res.json(status);
    }
    if (action === 'test') {
      // send a message to the notification channel (or the caller-provided one)
      const channelId = (req.body && req.body.channelId) || discord.conf().notifyChannelId || discord.conf().channelId;
      if (!channelId) return res.status(400).json({ error: 'Set a notification channel id first' });
      await discord.transport.sendMessage(channelId, { content: 'Zenith Panel bot is connected and ready.' });
      return res.json({ ok: true, channelId });
    }
    return res.status(400).json({ error: `Unknown action ${action}` });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/**
 * Update check. Honest by construction: it only reports an update when it can
 * actually compare against something - a feed URL you configure, or a release
 * marker written by `install.sh --update`. Otherwise it says so.
 */
system.get('/update', auth.authenticate, async (req, res) => {
  const current = cfg.version;
  const out = { version: current, available: false, latestVersion: current, source: 'none', notes: '', checkedAt: new Date().toISOString() };
  const marker = path.join(cfg.dataDir, 'update-available.json');
  try {
    if (fs.existsSync(marker)) {
      const data = JSON.parse(fs.readFileSync(marker, 'utf8'));
      if (data && data.version && data.version !== current) {
        return res.json({ ...out, available: true, latestVersion: data.version, source: 'release marker', notes: data.notes || '' });
      }
    }
  } catch (_) {}
  const feed = process.env.UPDATE_FEED_URL || '';
  if (!feed) {
    return res.json({ ...out, notes: 'No update feed configured - set UPDATE_FEED_URL in .env or run bash install.sh --update when a release lands.' });
  }
  try {
    const data = await fetchJson(feed, { timeout: 8000 });
    const latest = String((data && (data.version || data.tag_name || data.tag)) || '').replace(/^v/, '');
    const newer = latest && latest !== current;
    res.json({ ...out, available: Boolean(newer), latestVersion: latest || current, source: feed, notes: (data && (data.notes || data.body)) || '' });
  } catch (err) {
    res.status(502).json({ ...out, error: `The update feed could not be reached: ${err.message}` });
  }
});

system.get('/activity', auth.authenticate, (req, res) => {
  const all = db.get('activity') || [];
  const visible = auth.isAdmin(req.user) ? all : all.filter((a) => !a.serverId || (db.find('servers', (s) => s.id === a.serverId) && auth.canAccess(req.user, db.find('servers', (s) => s.id === a.serverId))));
  res.json({ activity: visible.slice(0, parseInt(req.query.limit || '80', 10)) });
});

module.exports = system;

/* ================================ users ================================ */
const users = express.Router();
users.use(auth.authenticate);

users.get('/', auth.requireAdmin, (req, res) => {
  try { db.reloadIfChanged(); } catch (_) {}
  const all = (db.get('users') || []).map((u) => ({
    ...auth.publicUser(u),
    servers: (db.get('servers') || []).filter((s) => s.ownerId === u.id).length,
    subOf: (db.get('servers') || []).filter((s) => (s.subusers || []).some((x) => x.userId === u.id)).length,
  }));
  res.json({ users: all, roles: Object.keys(auth.ROLES), permissions: auth.SERVER_PERMS });
});

users.post('/', auth.requireAdmin, async (req, res) => {
  const { username, password, email, role = 'user', maxServers } = req.body || {};
  if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(String(username || ''))) return res.status(400).json({ error: 'Invalid username (3-24 chars: letters, numbers, . _ -)' });
  if (String(password || '').length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (!auth.ROLES[role]) return res.status(400).json({ error: 'Invalid role' });
  if (role === 'owner' && req.user.role !== 'owner') return res.status(403).json({ error: 'Only an owner can create owners' });
  if (db.find('users', (u) => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Username already exists' });
  const user = {
    id: uid('usr'), username, email: email || '', password: await auth.hashPassword(password),
    role, passwordVersion: 0, createdAt: new Date().toISOString(), suspended: false, createdBy: req.user.username,
    maxServers: Math.max(0, parseInt(maxServers || 0, 10) || 0),
  };
  db.insert('users', user);
  db.log({ actor: req.user.username, action: 'user.create', detail: `${username} (${role})` });
  res.status(201).json({ user: auth.publicUser(user) });
});

users.patch('/:id', auth.requireAdmin, async (req, res) => {
  const target = db.find('users', (u) => u.id === req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  const { role, suspended, email, username, password, maxServers } = req.body || {};
  if (target.role === 'owner' && req.user.role !== 'owner') return res.status(403).json({ error: 'Only an owner can modify an owner' });
  if (role && !auth.ROLES[role]) return res.status(400).json({ error: 'Invalid role' });
  if (role && role === 'owner' && req.user.role !== 'owner') return res.status(403).json({ error: 'Only an owner can promote to owner' });

  const patch = {};
  if (role) patch.role = role;
  if (maxServers !== undefined) patch.maxServers = Math.max(0, parseInt(maxServers || 0, 10) || 0);
  if (suspended !== undefined) patch.suspended = !!suspended;
  if (email !== undefined) patch.email = email;
  if (username && username !== target.username) {
    if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) return res.status(400).json({ error: 'Invalid username' });
    if (db.find('users', (u) => u.username.toLowerCase() === String(username).toLowerCase())) return res.status(409).json({ error: 'Username already exists' });
    if (target.role === 'owner') return res.status(400).json({ error: 'Owner usernames cannot be renamed' });
    patch.username = username;
  }
  if (password) {
    if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
    patch.password = await auth.hashPassword(password);
    patch.passwordVersion = (target.passwordVersion || 0) + 1;
  }
  const updated = db.update('users', target.id, patch);
  db.log({ actor: req.user.username, action: 'user.update', detail: `${updated.username}: ${Object.keys(patch).join(', ')}` });
  res.json({ user: auth.publicUser(updated) });
});

users.delete('/:id', auth.requireAdmin, async (req, res) => {
  const target = db.find('users', (u) => u.id === req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  if (target.id === req.user.id) return res.status(400).json({ error: 'You cannot delete your own account here' });
  if (target.role === 'owner') return res.status(403).json({ error: 'Owner accounts cannot be deleted' });
  const owned = (db.get('servers') || []).filter((s) => s.ownerId === target.id);
  if (owned.length && req.query.force !== 'true') return res.status(409).json({ error: `This user owns ${owned.length} server(s). Transfer or delete them first.` });
  // force = take the servers down with the account (otherwise they would be orphaned)
  for (const server of owned) {
    try {
      await serverSvc.destroy(server, { removeFiles: true, removeBackups: true });
      logger.warn('users', `deleted ${server.name} (${server.id}) with owner ${target.username}`);
    } catch (err) {
      logger.error('users', `could not delete ${server.name}: ${err.message}`);
    }
  }
  db.remove('users', target.id);
  db.set('apiKeys', (db.get('apiKeys') || []).filter((k) => k.userId !== target.id));
  db.log({ actor: req.user.username, action: 'user.delete', detail: target.username });
  res.json({ ok: true });
});

module.exports.users = users;

/* ================================ nodes ================================ */
const nodes = express.Router();

/*
 * Agent-facing endpoints first: a remote node authenticates with its own node
 * token (and optionally NODE_SECRET), never with a panel JWT. They must be
 * registered *before* the authenticate() middleware below or every heartbeat
 * would be rejected with "Authentication required".
 */
nodes.post('/register', (req, res) => {
  const { token } = req.body || {};
  if (cfg.nodeSecret && req.headers['x-node-secret'] !== cfg.nodeSecret) return res.status(401).json({ error: 'Bad node secret' });
  try {
    const result = nodesSvc.register({ ...(req.body || {}), token });
    res.json({ ok: true, ...result, heartbeatInterval: 30000 });
  } catch (err) { res.status(401).json({ error: err.message }); }
});

nodes.post('/:id/heartbeat', (req, res) => {
  const node = nodesSvc.get(req.params.id);
  if (!node || node.token !== req.headers['x-node-token']) return res.status(401).json({ error: 'Invalid node token' });
  nodesSvc.heartbeat(node.id, req.body.stats);
  res.json({ ok: true, commands: [] });
});

/* Panel-facing endpoints: JWT or API key from here on. */
nodes.use(auth.authenticate);

nodes.get('/', (req, res) => {
  const list = nodesSvc.list();
  // The node token is a secret (it authorises the agent API) - admins only.
  if (auth.isAdmin(req.user)) return res.json({ nodes: list });
  res.json({
    nodes: list.map(({ token, installCommand, ...rest }) => ({ ...rest, tokenSet: Boolean(token) })),
  });
});

/** Registers the panel host as a node (what install.sh calls after booting). */
nodes.post('/auto-register', auth.authenticate, auth.requireAdmin, async (req, res) => {
  try {
    const body = req.body || {};
    const detected = nodesSvc.detectRequirements({ deep: true });
    const pub = body.publicIp ? { ip: body.publicIp, source: 'install.sh' } : await nodesSvc.publicIp();
    const result = nodesSvc.autoRegister({
      name: body.name || (body.local === false ? `Node ${pub.ip || detected.hostname}` : 'Local Node'),
      fqdn: body.fqdn || pub.ip || detected.ip || '127.0.0.1',
      port: body.port || 8443,
      scheme: body.scheme || 'http',
      token: body.token,
      backend: body.backend || db.settings().dockerBackend || 'process',
      portRange: body.portRange,
      description: body.description,
      local: body.local,
      detected,
    });
    db.log({ actor: req.user.username, action: result.created ? 'node.auto-register' : 'node.auto-refresh', detail: result.node.name });
    res.status(result.created ? 201 : 200).json({
      node: { ...result.node, token: undefined, tokenSet: Boolean(result.node.token) },
      created: result.created,
      credentialMinted: Boolean(result.credentialMinted),
      token: result.credentials || undefined,
      detected,
      publicIp: pub,
    });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/** Measured host requirements for this machine (installer + Nodes page). */
nodes.get('/detect', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const detected = nodesSvc.detectRequirements({ deep: req.query.deep !== 'false' });
  const pub = await nodesSvc.publicIp();
  res.json({ ...detected, publicIp: pub.ip, publicIpSource: pub.source, addresses: nodesSvc.addresses() });
});

/** Editable settings: name, fqdn/port/scheme, allocations, limits, backend, image. */
nodes.patch('/:id', auth.requireAdmin, (req, res) => {
  const node = nodesSvc.get(req.params.id);
  if (!node) return res.status(404).json({ error: 'Node not found' });
  const b = req.body || {};
  const patch = {};
  if (b.name !== undefined) patch.name = String(b.name).slice(0, 60) || node.name;
  if (b.description !== undefined) patch.description = String(b.description).slice(0, 200);
  if (b.fqdn !== undefined) patch.fqdn = String(b.fqdn).trim();
  if (b.port !== undefined) {
    const p = parseInt(b.port, 10);
    if (!(p > 0 && p < 65536)) return res.status(400).json({ error: 'Port must be 1-65535' });
    patch.port = p;
  }
  if (b.scheme !== undefined) patch.scheme = b.scheme === 'https' ? 'https' : 'http';
  if (b.backend !== undefined) {
    patch.backend = b.backend === 'docker' ? 'docker' : 'process';
    if (patch.backend === 'docker') {
      const probe = dockerSvc.probe({ force: true });
      if (!probe.available) return res.status(409).json({ error: `Docker is not available on this node: ${probe.error}` });
    }
  }
  if (b.dockerImage !== undefined) patch.dockerImage = String(b.dockerImage).trim();
  if (b.portRange !== undefined) {
    const start = parseInt(b.portRange.start, 10);
    const end = parseInt(b.portRange.end, 10);
    if (!(start > 1023 && end <= 65535 && end > start)) return res.status(400).json({ error: 'Port range must be a valid range inside 1024-65535' });
    const clash = (db.get('servers') || []).filter((sv) => sv.nodeId === node.id && (sv.port < start || sv.port > end));
    if (clash.length) return res.status(409).json({ error: `${clash.length} server(s) on this node are outside ${start}-${end} - move them first (${clash.map((c) => `:${c.port}`).join(', ')})` });
    patch.portRange = { start, end };
  }
  if (b.memoryLimit !== undefined) patch.memoryLimit = Math.max(0, parseInt(b.memoryLimit, 10) || 0);
  if (b.diskLimit !== undefined) patch.diskLimit = Math.max(0, parseInt(b.diskLimit, 10) || 0);
  if (b.cpuLimit !== undefined) patch.cpuLimit = Math.max(0, parseInt(b.cpuLimit, 10) || 0);
  if (b.maintenance !== undefined) patch.maintenance = Boolean(b.maintenance);
  const updated = db.update('nodes', node.id, patch);
  db.log({ actor: req.user.username, action: 'node.update', detail: `${node.name}: ${Object.keys(patch).join(', ') || 'no change'}` });
  res.json({ node: { ...updated, token: undefined, tokenSet: Boolean(updated.token) } });
});

/** Real health check: probes the panel, JVM, disk, docker daemon and the agent. */
nodes.post('/:id/health-check', auth.authenticate, auth.requireAdmin, async (req, res) => {
  try {
    const result = await nodesSvc.healthCheck(req.params.id);
    db.log({ actor: req.user.username, action: 'node.health-check', detail: `${req.params.id}: ${result.ok ? 'healthy' : result.error}` });
    res.status(result.ok ? 200 : 409).json(result);
  } catch (err) { res.status(400).json({ error: err.message, checks: [] }); }
});

/** Repair hooks for the local node (what `install.sh --repair` uses server side). */
nodes.post('/:id/repair', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const node = nodesSvc.get(req.params.id);
  if (!node) return res.status(404).json({ error: 'Node not found' });
  const actions = [];
  const detected = nodesSvc.detectRequirements({ deep: true });
  const patch = { detected, stats: { ...(node.stats || {}), ...detected }, lastHeartbeat: new Date().toISOString() };
  if (!node.portRange) patch.portRange = { start: 25565, end: 25665 };
  if (!node.name) patch.name = 'Local Node';
  actions.push(`re-detected host (${detected.cores} cores, ${Math.round(detected.memory.total / 1048576)} MB RAM)`);
  if (node.backend === 'docker' && !detected.docker.available) {
    patch.backend = 'process';
    actions.push(`docker is unavailable (${detected.docker.error}) - backend switched to plain processes so servers keep working`);
  }
  db.update('nodes', node.id, patch);
  const health = await nodesSvc.healthCheck(node.id);
  actions.push(health.ok ? 'health check passed' : `health check failed: ${health.error}`);
  db.log({ actor: req.user.username, action: 'node.repair', detail: `${node.name}: ${actions.join('; ')}` });
  res.json({ ok: health.ok, actions, health, node: { ...nodesSvc.get(node.id), token: undefined, tokenSet: true } });
});

/** Containers the panel owns on this node (docker backend only). */
nodes.get('/:id/containers', auth.authenticate, auth.requireAdmin, async (req, res) => {
  const list = await dockerSvc.listServers();
  if (!list.ok) return res.status(503).json({ error: list.error || 'docker is not available', containers: [] });
  res.json({ containers: list.containers.filter((c) => req.params.id === 'local' || true) });
});

nodes.post('/', auth.requireAdmin, (req, res) => {
  try {
    const node = nodesSvc.create(req.body || {});
    db.log({ actor: req.user.username, action: 'node.create', detail: node.name });
    res.status(201).json({ node });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

nodes.delete('/:id', auth.requireAdmin, (req, res) => {
  try { res.json(nodesSvc.remove(req.params.id)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});

nodes.post('/refresh', auth.authenticate, async (req, res) => {
  await nodesSvc.refresh();
  res.json({ nodes: nodesSvc.list() });
});


module.exports.nodes = nodes;

/* ================================ settings ================================ */
const settings = express.Router();
settings.use(auth.authenticate);

settings.get('/', (req, res) => {
  const raw = db.settings() || {};
  // Never send secrets back to the browser: expose only "is it set" flags.
  const { dnsToken, discordToken, ...safe } = raw;
  res.json({
    settings: {
      ...safe,
      dnsTokenSet: Boolean(dnsToken || process.env.CLOUDFLARE_TOKEN),
      discordTokenSet: Boolean(discordToken || process.env.DISCORD_TOKEN),
    },
    panelUrl: cfg.panelUrl,
    version: cfg.version,
    node: process.version,
  });
});

settings.patch('/', auth.requireAdmin, (req, res) => {
  const allowed = [
    'panelName', 'theme', 'accentColor', 'panelLogo', 'panelBackground', 'panelBackgroundOpacity', 'allowRegistration', 'defaultJava', 'defaultMemory', 'defaultPort',
    'maxServersPerUser', 'installJavaAutomatically', 'autoRestartOnCrash',
    // subdomains
    'dnsProvider', 'dnsDomain', 'dnsZone', 'dnsToken', 'dnsIp', 'dnsTtl',
    // sftp
    'sftpEnabled', 'sftpPort', 'sftpHost',
    // docker / container runtime
    'dockerEnabled', 'dockerBackend', 'dockerImage', 'dockerImages', 'dockerPullPolicy',
    'dockerRegistry', 'dockerRegistryUser', 'dockerRegistryToken', 'dockerDefaultMemory',
    'wingsEnabled', 'wingsToken',
    // discord
    'discordEnabled', 'discordToken', 'discordGuildId', 'discordAdminRole', 'discordPrefix',
    'discordDefaultMemory', 'discordDefaultType', 'discordDefaultVersion', 'discordAllowRegistration',
    'discordChannelId', 'discordNotifChannelId',
  ];
  const patch = {};
  for (const key of allowed) if (req.body[key] !== undefined) patch[key] = req.body[key];
  // Branding input is validated here rather than trusted from the browser.
  // A compact cropped data URL keeps this zero-dependency and self-hosted.
  const themes = ['midnight', 'obsidian', 'graphite', 'ocean'];
  if (patch.theme !== undefined && !themes.includes(String(patch.theme))) return res.status(400).json({ error: 'Unknown theme preset' });
  if (patch.accentColor !== undefined && !/^#[0-9a-f]{6}$/i.test(String(patch.accentColor))) return res.status(400).json({ error: 'Accent colour must be a six-digit hex colour' });
  if (patch.panelLogo !== undefined) {
    const logo = String(patch.panelLogo || '');
    if (logo && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(logo)) return res.status(400).json({ error: 'Panel logo must be a PNG, JPEG or WebP image' });
    if (logo.length > 220000) return res.status(413).json({ error: 'Panel logo is too large - crop it to a smaller square image' });
    patch.panelLogo = logo;
  }
  if (patch.panelBackground !== undefined) {
    const background = String(patch.panelBackground || '');
    if (background && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(background)) return res.status(400).json({ error: 'Panel background must be a PNG, JPEG or WebP image' });
    // Backgrounds are compressed in the browser before upload. This keeps the
    // self-hosted JSON store bounded while still allowing a detailed full-page
    // image at 1920px wide.
    if (background.length > 1400000) return res.status(413).json({ error: 'Panel background is too large - use a smaller image or let the panel compress it' });
    patch.panelBackground = background;
  }
  if (patch.panelBackgroundOpacity !== undefined) {
    const opacity = Number(patch.panelBackgroundOpacity);
    if (!Number.isFinite(opacity) || opacity < 0 || opacity > 100) return res.status(400).json({ error: 'Background opacity must be between 0 and 100' });
    patch.panelBackgroundOpacity = Math.round(opacity);
  }
  if (patch.panelName !== undefined) patch.panelName = String(patch.panelName).trim().slice(0, 64) || 'Zenith Panel';
  const updated = db.setSettings(patch);
  if (patch.autoRestartOnCrash !== undefined) process.env.AUTO_RESTART_ON_CRASH = patch.autoRestartOnCrash ? 'true' : 'false';
  // toggling SFTP or changing its port rebinds the real listener
  if (Object.keys(patch).some((k) => k.startsWith('sftp'))) {
    const sftpSvc = require('../services/sftp');
    sftpSvc.restart()
      .then((st) => {
        if (st.running) logger.ok('sftp', `SFTP rebound to port ${st.port}`);
        else logger.warn('sftp', `SFTP not running: ${st.error || st.reason}`);
      })
      .catch((err) => logger.error('sftp', `rebind failed: ${err.message}`));
  }
  // a changed bot token / guild needs a fresh gateway connection
  const discordKeys = Object.keys(patch).some((k) => k.startsWith('discord'));
  if (discordKeys) {
    const wantRunning = updated.discordEnabled && (updated.discordToken || process.env.DISCORD_TOKEN);
    const running = discord.status().running;
    if (wantRunning && (patch.discordToken !== undefined || patch.discordGuildId !== undefined || !running)) {
      discord.restart().catch((err) => logger.warn('discord', `restart after settings change failed: ${err.message}`));
    } else if (!wantRunning && running) {
      discord.stop().catch(() => {});
    }
  }
  db.log({ actor: req.user.username, action: 'settings.update', detail: Object.keys(patch).join(', ') });
  res.json({ settings: updated });
});

/** Export/import the panel config (servers + users + settings, no files). */
settings.get('/export', auth.requireOwner, (req, res) => {
  res.setHeader('Content-Disposition', `attachment; filename="zenith-panel-export-${Date.now()}.json"`);
  res.json({ exportedAt: new Date().toISOString(), version: cfg.version, users: (db.get('users') || []).map(auth.publicUser), servers: db.get('servers'), nodes: db.get('nodes'), settings: db.settings() });
});

module.exports.settings = settings;

/* ============================== api keys ============================== */
const apiKeys = express.Router();
apiKeys.use(auth.authenticate);

apiKeys.get('/', (req, res) => {
  // The raw token is a secret: it is shown exactly once, on creation.
  const list = (db.get('apiKeys') || []).filter((k) => auth.isAdmin(req.user) || k.userId === req.user.id)
    .map(({ hash, token, ...rest }) => rest);
  res.json({ apiKeys: list });
});

apiKeys.post('/', (req, res) => {
  const { name = 'API key', permissions = ['read'] } = req.body || {};
  const { raw, hash } = auth.generateApiKey();
  const record = {
    id: uid('key'), name, hash, prefix: raw.slice(0, 12), userId: req.user.id, username: req.user.username,
    permissions, createdAt: new Date().toISOString(), lastUsedAt: null, revoked: false,
  };
  db.insert('apiKeys', record);
  db.log({ actor: req.user.username, action: 'apikey.create', detail: name });
  const { hash: _h, ...safe } = record;
  // `token` exists only in this response - it is never written to disk.
  res.status(201).json({ apiKey: { ...safe, token: raw }, warning: 'Copy this key now - it is only shown once.' });
});

/* Drop plaintext tokens that older builds wrote into the database. */
(function migrateApiKeys() {
  const keys = db.get('apiKeys') || [];
  if (!keys.some((k) => 'token' in k)) return;
  db.set('apiKeys', keys.map(({ token, ...rest }) => rest));
  logger.warn('keys', 'removed legacy plaintext API tokens from the database');
})();

apiKeys.delete('/:id', (req, res) => {
  const key = db.find('apiKeys', (k) => k.id === req.params.id);
  if (!key) return res.status(404).json({ error: 'Key not found' });
  if (key.userId !== req.user.id && !auth.isAdmin(req.user)) return res.status(403).json({ error: 'Not your key' });
  db.update('apiKeys', key.id, { revoked: true });
  db.log({ actor: req.user.username, action: 'apikey.revoke', detail: key.name });
  res.json({ ok: true });
});

module.exports.apiKeys = apiKeys;
module.exports.system = system;
