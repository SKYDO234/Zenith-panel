'use strict';
/**
 * Docker runtime.
 *
 * Minecraft servers can run inside real Docker containers instead of child
 * processes. This module is a thin, honest wrapper around the `docker` CLI:
 *
 *   * every call returns the command's real stdout/stderr - failures are
 *     surfaced with the exact message Docker printed, never swallowed;
 *   * availability is probed, never assumed (`probe()`);
 *   * stats come from `docker stats` (the kernel's numbers), not estimates.
 *
 * Container layout used by the panel:
 *   image      eclipse-temurin:<major>-jre   (or a per-node override)
 *   mount      <panel servers dir>/<server id>  ->  /data
 *   command    java <jvm flags> -jar <jar> nogui
 *   ports      1:1 mapping of the allocation (tcp + udp), so server.properties
 *              keeps working unchanged and playit/tunnels can point at the host
 *   limits     --memory <memory + overhead>m  --cpus <cores>
 *
 * Console: containers are created with `-i` (stdin open) and the panel attaches
 * with `docker start -a -i`, so the JVM's stdin is the panel's pipe - exactly
 * like the child-process runtime.
 */
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const logger = require('../logger');
const cfg = require('../config');

const OVERHEAD_MB = 384;   // JVM/native overhead on top of -Xmx, inside the cgroup
let probeCache = { at: 0, value: null };

/* ------------------------------- helpers ------------------------------- */

/** Run the docker CLI, collecting real stdout/stderr. Never throws on exit != 0. */
function run(args, { timeout = 60000, input = null, onLine = null } = {}) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn('docker', args, { stdio: ['pipe', 'pipe', 'pipe'] });
    } catch (err) {
      return resolve({ code: -1, stdout: '', stderr: err.message, spawnError: err.message });
    }
    let stdout = '';
    let stderr = '';
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      try { child.kill('SIGKILL'); } catch (_) { /* gone */ }
      settled = true;
      resolve({ code: -1, stdout, stderr: `${stderr}\n[docker] timed out after ${timeout / 1000}s`, timedOut: true });
    }, timeout);
    if (timer.unref) timer.unref();

    const feed = (chunk, isErr) => {
      const text = chunk.toString('utf8');
      if (isErr) stderr += text; else stdout += text;
      if (onLine) text.split(/\r?\n/).filter(Boolean).forEach((l) => onLine(l, isErr));
    };
    child.stdout.on('data', (d) => feed(d, false));
    child.stderr.on('data', (d) => feed(d, true));
    child.on('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ code: -1, stdout, stderr: `${stderr}${err.message}`, spawnError: err.message });
    });
    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ code, stdout, stderr });
    });
    if (input != null) {
      try { child.stdin.write(input); child.stdin.end(); } catch (_) { /* pipe closed */ }
    }
  });
}
exports.run = run;

/** Synchronous probe - used where the caller cannot await (status endpoints). */
function runSync(args, { timeout = 8000 } = {}) {
  try {
    const res = spawnSync('docker', args, { encoding: 'utf8', timeout });
    return { code: res.status === null ? -1 : res.status, stdout: res.stdout || '', stderr: res.stderr || (res.error ? res.error.message : '') };
  } catch (err) {
    return { code: -1, stdout: '', stderr: err.message };
  }
}
exports.runSync = runSync;

function parseJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

function parseSize(text) {
  const m = String(text || '').trim().match(/^([\d.]+)\s*([KMGTP]?i?B)?$/i);
  if (!m) return 0;
  const value = parseFloat(m[1]);
  const unit = (m[2] || 'B').toLowerCase();
  const mult = { b: 1, kb: 1e3, kib: 1024, mb: 1e6, mib: 1048576, gb: 1e9, gib: 1073741824, tb: 1e12, tib: 1099511627776 }[unit] || 1;
  return Math.round(value * mult);
}
exports.parseSize = parseSize;

/* ----------------------------- availability ----------------------------- */

/**
 * Is a working Docker daemon reachable?
 * @returns {{ available: boolean, engine: string|null, client: string|null, apiVersion: string|null,
 *             storageDriver: string|null, error: string|null, checkedAt: string }}
 */
function probe({ force = false, maxAgeMs = 10000 } = {}) {
  if (!force && probeCache.value && Date.now() - probeCache.at < maxAgeMs) return probeCache.value;
  const res = runSync(['version', '--format', '{{json .}}']);
  const stamp = new Date().toISOString();
  let value;
  if (res.code !== 0) {
    const error = (res.stderr || res.stdout || 'docker CLI not available').trim().split('\n').slice(0, 4).join(' ').trim();
    value = {
      available: false, engine: null, client: null, apiVersion: null, storageDriver: null,
      error: res.spawnError || error || 'docker is not installed or the daemon is not reachable',
      checkedAt: stamp,
    };
  } else {
    const parsed = parseJson(res.stdout) || {};
    const server = parsed.Server || null;
    if (!server) {
      value = { available: false, engine: null, client: (parsed.Client || {}).Version || null, apiVersion: null, storageDriver: null, error: 'docker CLI answered but no daemon is reachable (is dockerd running?)', checkedAt: stamp };
    } else {
      value = {
        available: true,
        engine: server.Version || null,
        client: (parsed.Client || {}).Version || null,
        apiVersion: server.APIVersion || null,
        storageDriver: server.Driver || null,
        error: null,
        checkedAt: stamp,
      };
    }
  }
  probeCache = { at: Date.now(), value };
  return value;
}
exports.probe = probe;

/** `docker info` - real host/engine numbers (never synthesised). */
async function info() {
  const res = await run(['info', '--format', '{{json .}}'], { timeout: 15000 });
  if (res.code !== 0) return { ok: false, error: (res.stderr || res.stdout || '').trim(), raw: null };
  const raw = parseJson(res.stdout);
  if (!raw) return { ok: false, error: 'docker info returned unexpected output', raw: res.stdout.slice(0, 400) };
  return {
    ok: true, raw,
    engine: raw.ServerVersion || null,
    driver: raw.Driver || null,
    root: raw.DockerRootDir || null,
    cpus: raw.NCPU || null,
    memory: raw.MemTotal || null,
    containers: raw.Containers || 0,
    running: raw.ContainersRunning || 0,
    images: raw.Images || 0,
    os: raw.OperatingSystem || null,
    kernel: raw.KernelVersion || null,
    architecture: raw.Architecture || null,
  };
}
exports.info = info;

/* -------------------------------- images -------------------------------- */

const DEFAULT_IMAGE = (major) => `eclipse-temurin:${major}-jre`;

// Curated, pinned-family images for general-purpose container hosting. The
// panel deliberately does not accept an arbitrary image tag from the create
// flow: it can report the real Docker pull failure while keeping the admin UI
// auditable and safe.
const WORKLOAD_IMAGES = Object.freeze({
  'ubuntu-22.04': { id: 'ubuntu-22.04', name: 'Ubuntu 22.04', image: 'ubuntu:22.04', family: 'vm' },
  'ubuntu-20.04': { id: 'ubuntu-20.04', name: 'Ubuntu 20.04', image: 'ubuntu:20.04', family: 'vm' },
  'debian-12': { id: 'debian-12', name: 'Debian 12', image: 'debian:12', family: 'vm' },
  'debian-11': { id: 'debian-11', name: 'Debian 11', image: 'debian:11', family: 'vm' },
  'python-3.12': { id: 'python-3.12', name: 'Python 3.12', image: 'python:3.12-slim', family: 'bot' },
  'node-20': { id: 'node-20', name: 'Node.js 20', image: 'node:20-bookworm-slim', family: 'bot' },
});
exports.WORKLOAD_IMAGES = WORKLOAD_IMAGES;
function workloadImage(id) { return WORKLOAD_IMAGES[String(id || '')] || null; }
exports.workloadImage = workloadImage;

function imageFor(server, node = null) {
  if (node && node.dockerImage) return node.dockerImage;
  const major = parseInt(server && server.javaVersion, 10) || 21;
  return DEFAULT_IMAGE(major);
}
exports.imageFor = imageFor;
exports.DEFAULT_IMAGE = DEFAULT_IMAGE;

async function imagePresent(tag) {
  const res = await run(['image', 'inspect', tag, '--format', '{{.Id}}'], { timeout: 15000 });
  return res.code === 0 && Boolean(res.stdout.trim());
}
exports.imagePresent = imagePresent;

/** Pull an image with retries; streams real docker output to onLine(). */
async function ensureImage(tag, { onLine = null, retries = 3 } = {}) {
  if (await imagePresent(tag)) return { ok: true, tag, pulled: false };
  let last = '';
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    if (onLine) onLine(`[docker] pulling ${tag} (attempt ${attempt}/${retries})`);
    const res = await run(['pull', tag], { timeout: 20 * 60 * 1000, onLine: (line, isErr) => { if (onLine && !isErr) onLine(`  ${line}`); } });
    if (res.code === 0) {
      logger.ok('docker', `pulled image ${tag}`);
      return { ok: true, tag, pulled: true, attempts: attempt };
    }
    last = (res.stderr || res.stdout || 'unknown docker pull error').trim();
    logger.warn('docker', `docker pull ${tag} failed (attempt ${attempt}): ${last.split('\n').slice(-1)[0]}`);
    if (attempt < retries) await new Promise((r) => setTimeout(r, attempt * 2000));
  }
  throw new Error(`docker pull ${tag} failed after ${retries} attempts: ${last.split('\n').slice(-3).join(' ')}`);
}
exports.ensureImage = ensureImage;

/**
 * Run a short-lived SteamCMD install job against a panel-managed game directory.
 * The game files remain in the workload's /data bind; only the installer
 * container is removed. `envForward` forwards named host variables without
 * serialising their values into the server record or panel logs.
 */
async function runGameInstall({ image, dir, command, envForward = [], env = {}, user = '', shellEntrypoint = false, onLine = null }) {
  const source = path.resolve(dir);
  if (!fs.existsSync(source)) throw new Error(`game server directory does not exist: ${source}`);
  const args = ['run', '--rm', '-i', '--init', '--mount', `type=bind,src=${bindSourcePath(source)},dst=/data`, '-w', '/data'];
  for (const name of envForward) {
    if (process.env[name]) args.push('-e', name);
  }
  for (const [key, value] of Object.entries(env)) args.push('-e', `${key}=${value}`);
  if (user) args.push('--user', String(user));
  if (shellEntrypoint) args.push('--entrypoint', '/bin/bash');
  else args.push('--entrypoint', '/home/steam/steamcmd/steamcmd.sh');
  args.push(image, ...(command || []).map(String));
  return run(args, { timeout: 45 * 60 * 1000, onLine });
}
exports.runGameInstall = runGameInstall;

async function listImages() {
  const res = await run(['images', '--format', '{{json .}}'], { timeout: 15000 });
  if (res.code !== 0) return { ok: false, error: res.stderr.trim(), images: [] };
  const images = res.stdout.split('\n').filter(Boolean).map(parseJson).filter(Boolean)
    .map((i) => ({ repository: i.Repository, tag: i.Tag, id: i.ID, size: i.Size }));
  return { ok: true, images };
}
exports.listImages = listImages;

/* ------------------------------ containers ------------------------------ */

function containerName(serverId) {
  return `zenith-${String(serverId).replace(/[^a-zA-Z0-9_.-]/g, '-')}`;
}
exports.containerName = containerName;

/**
 * Translate a panel-visible server directory into the path understood by the
 * Docker daemon. Normally panel and daemon run on the same host, so this is
 * simply the original absolute directory. When the panel itself runs in a
 * Docker container, the daemon socket belongs to the host and cannot resolve
 * `/app/servers/...`; `DOCKER_BIND_ROOT` supplies the *host* absolute path for
 * the same server-data root (for example `${PWD}/servers` in docker compose).
 *
 * This is deliberately scoped to the panel-managed server-data root. It never
 * maps arbitrary paths, and the resulting path is only passed to Docker for
 * the workload's one permitted `/data` bind mount.
 */
function bindSourcePath(dir) {
  const source = path.resolve(dir);
  const configuredRoot = String(process.env.DOCKER_BIND_ROOT || '').trim();
  if (!configuredRoot) return source;
  if (!path.isAbsolute(configuredRoot)) {
    throw new Error('DOCKER_BIND_ROOT must be an absolute host path to the panel server-data directory');
  }
  const panelRoot = path.resolve(cfg.serverDataDir);
  const relative = path.relative(panelRoot, source);
  if (relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative))) {
    return path.resolve(configuredRoot, relative);
  }
  // Docker helpers occasionally operate on a temporary non-server directory.
  // Do not apply a broad prefix rewrite to that path.
  return source;
}
exports.bindSourcePath = bindSourcePath;

// Generic VPS workloads get names that are stable, unique, and valid in Linux
// UTS/Docker contexts. They are generated from the server record—not a user
// supplied label—so one tenant cannot select another tenant's hostname/network.
function workloadHostname(serverId) {
  return `vps-${String(serverId).replace(/[^a-zA-Z0-9-]/g, '').replace(/^srv/, '').slice(0, 52)}`.slice(0, 63);
}
exports.workloadHostname = workloadHostname;
function workloadNetworkName(serverId) {
  return `zenith-vps-${String(serverId).replace(/[^a-zA-Z0-9_.-]/g, '-').slice(0, 48)}`;
}
exports.workloadNetworkName = workloadNetworkName;

/** Each managed VPS gets a dedicated bridge. This preserves outbound access for
 * SSHX while keeping the workload out of the shared Docker bridge and away from
 * other panel workload interfaces. */
// Docker versions differ in their missing-network diagnostics. Modern
// engines commonly say `Error response from daemon: network <name> not found`,
// whereas older releases say `No such network`. Treat both as the expected
// create-on-first-use condition; anything else is still surfaced verbatim.
function networkIsMissing(output) {
  return /(?:no such network|network(?:\s+[^\n:]*)?\s+not found)/i.test(String(output || ''));
}
exports.networkIsMissing = networkIsMissing;

async function ensureWorkloadNetwork(serverId) {
  const name = workloadNetworkName(serverId);
  const present = await run(['network', 'inspect', name, '--format', '{{.Id}}'], { timeout: 15000 });
  if (present.code === 0 && present.stdout.trim()) return { name, id: present.stdout.trim(), created: false };
  if (present.code !== 0 && !networkIsMissing(present.stderr || present.stdout)) {
    throw new Error(`docker network inspect ${name} failed: ${(present.stderr || present.stdout || '').trim().split('\n').slice(-3).join(' ')}`);
  }
  const created = await run(['network', 'create', '--driver', 'bridge', '--label', `zenith.managed=true`, '--label', `zenith.server=${serverId}`, name], { timeout: 30000 });
  if (created.code !== 0) throw new Error(`docker network create failed: ${(created.stderr || created.stdout || '').trim().split('\n').slice(-3).join(' ')}`);
  return { name, id: created.stdout.trim(), created: true };
}
exports.ensureWorkloadNetwork = ensureWorkloadNetwork;
async function removeWorkloadNetwork(serverId) {
  const name = workloadNetworkName(serverId);
  const res = await run(['network', 'rm', name], { timeout: 30000 });
  if (res.code !== 0 && !networkIsMissing(res.stderr || res.stdout)) {
    throw new Error(`docker network rm ${name} failed: ${(res.stderr || res.stdout || '').trim().split('\n').slice(-3).join(' ')}`);
  }
  return { ok: true, name };
}
exports.removeWorkloadNetwork = removeWorkloadNetwork;

/** Inspect a container; returns null when it does not exist. */
async function inspect(name) {
  const res = await run(['inspect', name, '--format', '{{json .}}'], { timeout: 15000 });
  if (res.code !== 0) {
    const err = res.stderr || '';
    if (/No such (object|container)/i.test(err)) return null;
    throw new Error((err || res.stdout || `docker inspect ${name} failed`).trim().split('\n').slice(0, 3).join(' '));
  }
  const raw = parseJson(res.stdout);
  if (!raw) return null;
  return {
    raw,
    name: raw.Name ? raw.Name.replace(/^\//, '') : name,
    id: raw.Id,
    running: Boolean(raw.State && raw.State.Running),
    status: (raw.State && raw.State.Status) || 'unknown',
    exitCode: raw.State ? raw.State.ExitCode : null,
    error: raw.State ? raw.State.Error : '' || '',
    startedAt: raw.State ? raw.State.StartedAt : null,
    finishedAt: raw.State ? raw.State.FinishedAt : null,
    image: raw.Config ? raw.Config.Image : null,
    hostname: raw.Config ? raw.Config.Hostname : null,
    memoryLimit: raw.HostConfig ? raw.HostConfig.Memory : null,
    memorySwap: raw.HostConfig ? raw.HostConfig.MemorySwap : null,
    nanoCpus: raw.HostConfig ? raw.HostConfig.NanoCpus : null,
    pidsLimit: raw.HostConfig ? raw.HostConfig.PidsLimit : null,
    namespaces: raw.HostConfig ? {
      pid: raw.HostConfig.PidMode || 'private', uts: raw.HostConfig.UTSMode || 'private',
      ipc: raw.HostConfig.IpcMode || 'private', network: raw.HostConfig.NetworkMode || 'default',
    } : null,
    privileged: Boolean(raw.HostConfig && raw.HostConfig.Privileged),
    rootFilesystemDriver: raw.GraphDriver ? raw.GraphDriver.Name || null : null,
    securityOpt: raw.HostConfig ? raw.HostConfig.SecurityOpt || [] : [],
    mounts: (raw.Mounts || []).map((mount) => ({ type: mount.Type, source: mount.Source, destination: mount.Destination, rw: mount.RW !== false, propagation: mount.Propagation || null })),
    ports: raw.NetworkSettings ? raw.NetworkSettings.Ports : null,
  };
}
exports.inspect = inspect;

/**
 * Create (not start) a container for a server.
 * @param {object} opts
 *   name, image, dir, memoryMb, cpuCores, ports:[n], javaArgs:[..], jar, env:{}
 */
async function create(opts) {
  const { name, image, dir, memoryMb = 2048, memoryOverheadMb = OVERHEAD_MB, cpuCores = 0, ports = [], javaArgs = [], jar = 'server.jar', command = null, entrypoint = '', user = '', env = {}, tty = false, isolatedWorkload = false, hostname = '', network = '', pidsLimit = 512 } = opts;
  if (!name || !image || !dir) throw new Error('docker.create requires name, image and dir');
  if (!fs.existsSync(dir)) throw new Error(`server directory does not exist: ${dir}`);
  if (isolatedWorkload && (!hostname || !network)) throw new Error('isolated Docker workload requires a hostname and dedicated network');

  const safeDir = path.resolve(dir);
  // Validate the panel-visible directory locally. `bindDir` may be a host path
  // that is intentionally not visible inside a containerised panel process.
  const bindDir = bindSourcePath(safeDir);
  const args = ['create', '--name', name, '-i'];
  if (tty) args.push('-t');
  if (isolatedWorkload) {
    // Docker's default PID, UTS and IPC modes are private. Do not pass the
    // literal string "private" to `--pid`: recent Docker CLIs accept host or
    // container:<id> there and reject `--pid private`. We verify the daemon's
    // actual inspect values below and reject any host namespace instead.
    // The only host path exposed is this workload's panel-managed /data.
    args.push('--hostname', hostname, '--network', network);
    args.push('--pids-limit', String(Math.max(64, Math.min(4096, Number(pidsLimit) || 512))));
    // Application/bot code does not need Linux capabilities. This remains a
    // normal non-privileged Docker container, with its capability set dropped.
    args.push('--cap-drop', 'ALL');
    args.push('--security-opt', 'no-new-privileges:true');
    args.push('--mount', `type=bind,src=${bindDir},dst=/data,bind-propagation=rprivate`);
  } else {
    args.push('-v', `${bindDir}:/data`);
  }
  args.push('-w', '/data');
  const memoryLimitMb = Math.max(256, Number(memoryMb) || 256) + Math.max(0, Number(memoryOverheadMb) || 0);
  args.push('--memory', `${memoryLimitMb}m`);
  args.push('--memory-swap', `${memoryLimitMb}m`);
  if (cpuCores > 0) args.push('--cpus', String(cpuCores));
  args.push('--restart', 'no');
  for (const p of ports.filter(Boolean)) {
    args.push('-p', `${p}:${p}/tcp`, '-p', `${p}:${p}/udp`);
  }
  for (const [k, v] of Object.entries(env)) args.push('-e', `${k}=${v}`);
  if (entrypoint) args.push('--entrypoint', String(entrypoint));
  if (user) args.push('--user', String(user));
  args.push(image);
  if (Array.isArray(command) && command.length) {
    args.push(...command.map(String));
  } else if (String(jar).endsWith('.sh')) {
    args.push('bash', `./${path.basename(jar)}`, 'nogui');
  } else {
    args.push('java', ...javaArgs, '-jar', path.basename(jar), 'nogui');
  }
  const res = await run(args, { timeout: 60000 });
  if (res.code !== 0) {
    throw new Error(`docker create failed: ${(res.stderr || res.stdout || '').trim().split('\n').slice(-3).join(' ')}`);
  }
  return { id: res.stdout.trim(), name, hostname: hostname || null, network: network || null, command: `docker ${args.join(' ')}` };
}
exports.create = create;

/** Remove a container (force). Missing containers are not an error. */
async function remove(name) {
  const res = await run(['rm', '-f', '-v', name], { timeout: 30000 });
  if (res.code !== 0 && !/No such container/i.test(res.stderr || '')) {
    throw new Error(`docker rm ${name} failed: ${(res.stderr || '').trim()}`);
  }
  return { ok: true };
}
exports.remove = remove;

/** Verify Docker's actual inspect result; do not infer isolation from requested
 * flags. A mismatch is a hard provisioning error rather than a cosmetic label. */
async function verifyWorkloadIsolation(name, { hostname, network, dir, memoryMb, cpuCores }) {
  const details = await inspect(name);
  if (!details) return { ok: false, errors: ['Docker did not return the newly created container'] };
  const expectedDir = bindSourcePath(dir);
  const mounts = details.mounts || [];
  const dataMount = mounts.find((mount) => mount.destination === '/data' && path.resolve(mount.source || '') === expectedDir && mount.rw);
  const extraMounts = mounts.filter((mount) => mount.destination !== '/data');
  const namespaces = details.namespaces || {};
  const errors = [];
  if (details.hostname !== hostname) errors.push(`hostname is ${details.hostname || 'unset'}, expected ${hostname}`);
  if (namespaces.pid === 'host') errors.push('PID namespace is host');
  if (namespaces.uts === 'host') errors.push('UTS namespace is host');
  if (namespaces.ipc === 'host') errors.push('IPC namespace is host');
  if (namespaces.network === 'host' || namespaces.network !== network) errors.push(`network namespace is ${namespaces.network || 'unset'}, expected dedicated ${network}`);
  if (details.privileged) errors.push('container is privileged');
  if (!Array.isArray(details.securityOpt) || !details.securityOpt.includes('no-new-privileges:true')) errors.push('no-new-privileges security option is absent');
  if (!dataMount) errors.push('the only permitted /data mount is missing or not writable');
  if (extraMounts.length) errors.push(`unexpected host mount(s): ${extraMounts.map((mount) => mount.destination || '?').join(', ')}`);
  if (!details.rootFilesystemDriver) errors.push('Docker did not report a container root filesystem driver');
  if (Number(details.pidsLimit || 0) !== 512) errors.push(`PID cgroup is ${details.pidsLimit || 0}, expected 512`);
  const expectedMemory = Math.max(256, Number(memoryMb) || 256) * 1024 * 1024;
  if (Number(details.memoryLimit || 0) !== expectedMemory) errors.push(`memory cgroup is ${details.memoryLimit || 0}, expected ${expectedMemory}`);
  if (cpuCores > 0 && Number(details.nanoCpus || 0) !== Math.round(Number(cpuCores) * 1e9)) errors.push(`CPU cgroup is ${details.nanoCpus || 0}, expected ${Math.round(Number(cpuCores) * 1e9)}`);
  return {
    ok: errors.length === 0, errors, hostname: details.hostname, network: namespaces.network,
    mounts, namespaces, rootFilesystemDriver: details.rootFilesystemDriver, memoryLimitBytes: Number(details.memoryLimit || 0), cpuLimitCores: Number(details.nanoCpus || 0) / 1e9,
    pidsLimit: details.pidsLimit, kernelShared: true,
  };
}
exports.verifyWorkloadIsolation = verifyWorkloadIsolation;

/** Read factual in-container identity values using a fixed, non-user-supplied
 * command. Docker shares the host kernel by design; this deliberately does not
 * pretend otherwise. */
async function workloadIdentity(name) {
  const script = [
    'set -eu',
    'test -r /etc/os-release',
    '. /etc/os-release',
    'printf "HOSTNAME=%s\\n" "$(hostname)"',
    'printf "OS_ID=%s\\n" "${ID:-}"',
    'printf "OS_VERSION_ID=%s\\n" "${VERSION_ID:-}"',
    'printf "OS_PRETTY_NAME=%s\\n" "${PRETTY_NAME:-}"',
    'if [ -r /sys/fs/cgroup/memory.max ]; then printf "MEMORY_LIMIT=%s\\n" "$(cat /sys/fs/cgroup/memory.max)"; elif [ -r /sys/fs/cgroup/memory/memory.limit_in_bytes ]; then printf "MEMORY_LIMIT=%s\\n" "$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes)"; else printf "MEMORY_LIMIT=unknown\\n"; fi',
    'if [ -r /sys/fs/cgroup/cpu.max ]; then printf "CPU_LIMIT=%s\\n" "$(cat /sys/fs/cgroup/cpu.max)"; elif [ -r /sys/fs/cgroup/cpu/cpu.cfs_quota_us ]; then printf "CPU_LIMIT=%s/%s\\n" "$(cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us)" "$(cat /sys/fs/cgroup/cpu/cpu.cfs_period_us)"; else printf "CPU_LIMIT=unknown\\n"; fi',
  ].join('; ');
  const res = await run(['exec', name, '/bin/sh', '-lc', script], { timeout: 15000 });
  if (res.code !== 0) throw new Error(`docker exec identity check failed: ${(res.stderr || res.stdout || '').trim().split('\n').slice(-3).join(' ')}`);
  const values = {};
  for (const line of String(res.stdout || '').split(/\r?\n/)) {
    const at = line.indexOf('=');
    if (at > 0) values[line.slice(0, at)] = line.slice(at + 1);
  }
  if (!values.HOSTNAME || !values.OS_ID) throw new Error('container identity check returned no hostname or /etc/os-release ID');
  return { hostname: values.HOSTNAME, os: { id: values.OS_ID, versionId: values.OS_VERSION_ID || '', prettyName: values.OS_PRETTY_NAME || '' }, cgroup: { memoryLimit: values.MEMORY_LIMIT || 'unknown', cpuLimit: values.CPU_LIMIT || 'unknown' }, kernelShared: true };
}
exports.workloadIdentity = workloadIdentity;

/**
 * Attach to a container: `docker start -a -i` re-attaches stdout/stderr *and*
 * stdin, so the returned child process behaves exactly like a JVM child process.
 */
function attach(name, { onLine = null, onExit = null } = {}) {
  const child = spawn('docker', ['start', '-a', '-i', name], { stdio: ['pipe', 'pipe', 'pipe'] });
  child.stdin.on('error', () => { /* container stopped */ });
  if (onLine) {
    child.stdout.on('data', (d) => onLine(d.toString('utf8')));
    child.stderr.on('data', (d) => onLine(d.toString('utf8')));
  }
  child.on('error', (err) => { if (onExit) onExit(null, err.message); });
  child.on('exit', (code, signal) => { if (onExit) onExit(code, signal); });
  return child;
}
exports.attach = attach;

/** Graceful stop; falls back to SIGKILL inside the container after `timeout`. */
async function stop(name, { timeout = 25 } = {}) {
  const res = await run(['stop', '-t', String(timeout), name], { timeout: (timeout + 15) * 1000 });
  if (res.code !== 0 && !/No such container/i.test(res.stderr || '')) {
    throw new Error(`docker stop ${name} failed: ${(res.stderr || '').trim()}`);
  }
  return { ok: true, output: res.stdout.trim() };
}
exports.stop = stop;

async function kill(name) {
  const res = await run(['kill', name], { timeout: 20000 });
  if (res.code !== 0 && !/is not running|No such container/i.test(res.stderr || '')) {
    throw new Error(`docker kill ${name} failed: ${(res.stderr || '').trim()}`);
  }
  return { ok: true };
}
exports.kill = kill;

/** Real per-container stats from the kernel via `docker stats`. */
async function stats(name) {
  const res = await run(['stats', '--no-stream', '--format', '{{json .}}', name], { timeout: 20000 });
  if (res.code !== 0) return { ok: false, error: (res.stderr || '').trim() };
  const raw = parseJson(res.stdout.trim().split('\n').filter(Boolean).pop() || '');
  if (!raw) return { ok: false, error: 'docker stats returned no data' };
  const [memUsed, memLimit] = String(raw.MemUsage || '').split('/').map((s) => parseSize(s.trim()));
  return {
    ok: true,
    cpu: Number(String(raw.CPUPerc || '0').replace('%', '')) || 0,
    memoryBytes: memUsed || 0,
    memoryLimitBytes: memLimit || 0,
    memoryPercent: Number(String(raw.MemPerc || '0').replace('%', '')) || 0,
    netIO: raw.NetIO || null,
    blockIO: raw.BlockIO || null,
    pids: Number(raw.PIDs) || 0,
    raw,
  };
}
exports.stats = stats;

/** `docker logs` tail - used when the panel has no live attach (e.g. after a restart). */
async function logs(name, { tail = 400 } = {}) {
  const res = await run(['logs', '--tail', String(tail), name], { timeout: 30000 });
  if (res.code !== 0 && !/No such container/i.test(res.stderr || '')) {
    return { ok: false, error: (res.stderr || '').trim(), text: '' };
  }
  return { ok: true, text: `${res.stdout || ''}${res.stderr || ''}` };
}
exports.logs = logs;

/** Run a one-off command in the image with the server dir mounted (loader installers). */
async function runOnce({ image, dir, command, onLine = null, memoryMb = 2048 }) {
  const args = ['run', '--rm', '-i', '--memory', `${memoryMb}m`, '-w', '/data', '-v', `${bindSourcePath(dir)}:/data`, image, ...command];
  const res = await run(args, { timeout: 45 * 60 * 1000, onLine: (line, isErr) => { if (onLine && !isErr) onLine(line); } });
  if (res.code !== 0) throw new Error(`docker run failed: ${(res.stderr || res.stdout || '').trim().split('\n').slice(-3).join(' ')}`);
  return { ok: true, output: res.stdout };
}
exports.runOnce = runOnce;

/** Containers the panel owns (used by the Nodes page and by startup reconciliation). */
async function listServers() {
  const res = await run(['ps', '-a', '--filter', 'name=zenith-', '--format', '{{json .}}'], { timeout: 20000 });
  if (res.code !== 0) return { ok: false, error: (res.stderr || '').trim(), containers: [] };
  const containers = res.stdout.split('\n').filter(Boolean).map(parseJson).filter(Boolean)
    .map((c) => ({
      name: c.Names, id: c.ID, image: c.Image, status: c.Status, state: c.State,
      ports: c.Ports, serverId: String(c.Names || '').replace(/^zenith-/, ''),
    }));
  return { ok: true, containers };
}
exports.listServers = listServers;

/** Human summary for the Nodes page / installer output. */
async function summary() {
  const p = probe({ force: true });
  if (!p.available) return { available: false, error: p.error, checkedAt: p.checkedAt };
  const i = await info();
  return {
    available: true,
    engine: p.engine,
    apiVersion: p.apiVersion,
    storageDriver: p.storageDriver,
    error: null,
    checkedAt: p.checkedAt,
    driver: i.ok ? i.driver : null,
    containers: i.ok ? i.containers : null,
    running: i.ok ? i.running : null,
    images: i.ok ? i.images : null,
    memory: i.ok ? i.memory : null,
    cpus: i.ok ? i.cpus : null,
    os: i.ok ? i.os : null,
    kernel: i.ok ? i.kernel : null,
    root: i.ok ? i.root : null,
    infoError: i.ok ? null : i.error,
  };
}
exports.summary = summary;
