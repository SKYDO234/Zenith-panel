'use strict';
/**
 * playit.gg tunnel integration (agent v1.x).
 *
 * playit v1 split the old single binary into two parts:
 *   playit-agent : the daemon that maintains the tunnel(s)
 *   playit-cli   : daemon client - claiming, secrets, service management
 *
 * Claim flow implemented here (one agent + one secret per Minecraft server):
 *   1. playit-cli claim generate            -> short claim code
 *   2. playit-cli claim url <code> --name X -> the URL the user opens
 *   3. playit-cli claim exchange <code>     -> blocks until claimed, returns the secret
 *   4. playit-agent --secret <key> -l <log> -> tunnel up
 *
 * All output is mirrored into the server console and pushed to the UI over the
 * console websocket as `playit` events.
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const { spawn } = require('child_process');

const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { download, exists, ensureDir, stripAnsi } = require('../utils');

const ASSETS = {
  'linux-x64': { agent: 'playit-linux-amd64', cli: 'playit-cli-linux-amd64' },
  'linux-arm64': { agent: 'playit-linux-aarch64', cli: 'playit-cli-linux-aarch64' },
  'linux-arm': { agent: 'playit-linux-armv7', cli: 'playit-cli-linux-armv7' },
  'linux-ia32': { agent: 'playit-linux-i686', cli: 'playit-cli-linux-i686' },
  'darwin-x64': { agent: 'playit-darwin-amd64', cli: 'playit-cli-darwin-amd64' },
  'darwin-arm64': { agent: 'playit-darwin-aarch64', cli: 'playit-cli-darwin-aarch64' },
  'win32-x64': { agent: 'playit-windows-x86_64.exe', cli: 'playit-cli-windows-x86_64.exe' },
  'win32-ia32': { agent: 'playit-windows-x86.exe', cli: 'playit-cli-windows-x86.exe' },
};

const ext = () => (process.platform === 'win32' ? '.exe' : '');
const assetSet = () => ASSETS[`${process.platform}-${process.arch}`] || ASSETS['linux-x64'];
const agentBin = () => path.join(cfg.playitBinDir, `playit-agent${ext()}`);
const cliBin = () => path.join(cfg.playitBinDir, `playit-cli${ext()}`);
exports.agentBin = agentBin;
exports.cliBin = cliBin;

const dirFor = (serverId) => path.join(cfg.serverDataDir, serverId, '.playit');
const secretFile = (serverId) => path.join(dirFor(serverId), 'playit.toml');
const socketFile = (serverId) => path.join(dirFor(serverId), process.platform === 'win32' ? 'playitd.pipe' : 'playitd.sock');
const logFile = (serverId) => path.join(dirFor(serverId), 'agent.log');

/** serverId -> live state */
const agents = new Map();
function state(serverId) {
  if (!agents.has(serverId)) {
    agents.set(serverId, {
      serverId, proc: null, claimProc: null, claimCode: null, claimUrl: null,
      tunnels: [], status: 'stopped', lastLine: null, startedAt: null, error: null,
      secret: null, watcher: null,
    });
  }
  return agents.get(serverId);
}

function emit(serverId, extra = {}) {
  const runtime = require('./runtime');
  runtime.events.emit('event', { serverId, type: 'playit', data: status(serverId) });
  void extra;
}

function log(serverId, line) {
  const runtime = require('./runtime');
  runtime.state(serverId).logs.push(`[playit] ${line}`);
}

/* ------------------------------ binaries ------------------------------ */
async function ensureBinary(onProgress = () => {}) {
  await ensureDir(cfg.playitBinDir);
  const assets = assetSet();
  const out = { agent: agentBin(), cli: cliBin() };
  for (const [kind, name] of Object.entries(assets)) {
    const target = out[kind];
    if (fs.existsSync(target)) continue;
    const staging = `${target}.download`;
    const url = `https://github.com/playit-cloud/playit-agent/releases/latest/download/${name}`;
    logger.info('playit', `downloading ${name}...`);
    const res = await download(url, staging, { onProgress });
    await fsp.rename(staging, target);
    if (process.platform !== 'win32') await fsp.chmod(target, 0o755);
    logger.ok('playit', `${kind} ready (${res.size} bytes)`);
  }
  return out;
}
exports.ensureBinary = ensureBinary;

/* ------------------------------ helpers ------------------------------ */
function run(bin, args, { cwd, timeout = 30000 } = {}) {
  return new Promise((resolve) => {
    const proc = spawn(bin, args, { cwd, env: { ...process.env, NO_COLOR: '1' } });
    let stdout = '', stderr = '', done = false;
    const finish = (code) => { if (!done) { done = true; resolve({ code, stdout: stdout.trim(), stderr: stderr.trim() }); } };
    const timer = timeout ? setTimeout(() => { try { proc.kill('SIGKILL'); } catch (_) {} finish(-1); }, timeout) : null;
    proc.stdout.on('data', (d) => { stdout += d.toString(); });
    proc.stderr.on('data', (d) => { stderr += d.toString(); });
    proc.on('error', (err) => { clearTimeout(timer); stderr += err.message; finish(-1); });
    proc.on('exit', (code) => { clearTimeout(timer); finish(code); });
  });
}

function parseTunnels(text) {
  const found = new Set();
  for (const m of String(text).matchAll(/([a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:playit\.gg|playit\.xyz|at\.playit\.gg)):(\d+)/gi)) {
    found.add(`${m[1]}:${m[2]}`);
  }
  return [...found];
}

function tailLog(serverId) {
  const st = state(serverId);
  const file = logFile(serverId);
  if (!fs.existsSync(file)) return () => {};
  let offset = fs.statSync(file).size > 40000 ? fs.statSync(file).size - 20000 : 0;
  const read = () => {
    try {
      const stat = fs.statSync(file);
      if (stat.size <= offset) return;
      const fd = fs.openSync(file, 'r');
      const buf = Buffer.alloc(stat.size - offset);
      fs.readSync(fd, buf, 0, buf.length, offset);
      fs.closeSync(fd);
      offset = stat.size;
      const text = stripAnsi(buf.toString('utf8'));
      for (const line of text.split(/\r?\n/)) {
        if (!line.trim()) continue;
        st.lastLine = line.trim();
        const tunnels = parseTunnels(line);
        tunnels.forEach((t) => { if (!st.tunnels.includes(t)) st.tunnels.push(t); });
        if (/error|failed|denied/i.test(line)) st.error = line.trim().slice(0, 300);
        if (/registered|tunnel|connected|ready/i.test(line)) st.status = 'connected';
      }
      persist(serverId);
      emit(serverId);
    } catch (_) { /* file being rotated */ }
  };
  st.watcher = setInterval(read, 2000);
  st.watcher.unref?.();
  read();
  return read;
}

function persist(serverId) {
  const server = db.find('servers', (s) => s.id === serverId);
  if (!server) return;
  const st = state(serverId);
  db.update('servers', serverId, {
    playit: {
      ...(server.playit || {}),
      enabled: !!st.proc,
      status: st.status,
      claimUrl: st.claimUrl,
      tunnels: st.tunnels,
      lastLine: st.lastLine,
    },
  });
}

/* ------------------------------ claim flow ------------------------------ */
/**
 * Generate a claim link for a server (no account needed yet).
 * Returns { code, url }.
 */
async function claimUrl(server, { name } = {}) {
  await ensureBinary();
  const gen = await run(cliBin(), ['claim', 'generate']);
  const code = (gen.stdout || '').split('\n').map((l) => l.trim()).filter(Boolean).pop();
  if (!code) throw new Error(`Could not generate a claim code (${gen.stderr || 'no output'})`);
  const urlRes = await run(cliBin(), ['claim', 'url', code, '--name', name || server.name]);
  const url = (urlRes.stdout || '').match(/https:\/\/playit\.gg\/\S+/);
  const st = state(server.id);
  st.claimCode = code;
  st.claimUrl = url ? url[0] : null;
  st.status = 'unclaimed';
  log(server.id, `claim link ready: ${st.claimUrl || '(open playit.gg and enter code ' + code + ')'}`);
  persist(server.id);
  emit(server.id);
  return { code, url: st.claimUrl, claimCode: code };
}
exports.claimUrl = claimUrl;

/** Wait (in the background) for the user to claim, then store the secret. */
function startExchange(server, code) {
  const st = state(server.id);
  if (st.claimProc) return;
  log(server.id, 'waiting for you to open the claim link in your browser...');
  const proc = spawn(cliBin(), ['claim', 'exchange', code, '--wait', '0'], { env: { ...process.env, NO_COLOR: '1' } });
  st.claimProc = proc;
  let out = '';
  proc.stdout.on('data', (d) => { out += d.toString(); });
  proc.stderr.on('data', (d) => { out += d.toString(); });
  proc.on('exit', async (exitCode) => {
    st.claimProc = null;
    const secret = (out.match(/[A-Za-z0-9+/=_-]{20,}/g) || []).find((s) => s.length >= 20) || null;
    const parsed = out.match(/secret[^:]*:\s*"?([^"\s]+)"?/i);
    const key = parsed ? parsed[1] : secret;
    if (exitCode === 0 && key) {
      st.secret = key;
      await ensureDir(dirFor(server.id));
      await fsp.writeFile(secretFile(server.id), `secret_key = "${key}"\n`);
      db.update('servers', server.id, { playitSecret: key, playit: { ...(server.playit || {}), claimed: true, status: 'connected' } });
      log(server.id, 'agent claimed - starting the tunnel daemon');
      st.claimUrl = null;
      try { await start(server, { secret: key }); } catch (err) { log(server.id, `daemon start failed: ${err.message}`); }
    } else {
      st.error = `claim not completed (exit ${exitCode})`;
      log(server.id, `claim exchange ended without a secret - open the link again or reset the tunnel`);
    }
    persist(server.id);
    emit(server.id);
  });
  proc.on('error', (err) => { st.claimProc = null; log(server.id, `claim exchange failed: ${err.message}`); });
}
exports.startExchange = startExchange;

/* ------------------------------ daemon ------------------------------ */
async function start(server, { secret } = {}) {
  const st = state(server.id);
  if (st.proc) return status(server.id);
  await ensureBinary((p) => {
    require('./runtime').setInstallProgress(server.id, { step: 'playit', percent: p.percent, note: `playit binaries ${p.percent}%` });
  });
  await ensureDir(dirFor(server.id));

  let key = secret || server.playitSecret || cfg.playitGlobalSecret || '';
  if (!key && fs.existsSync(secretFile(server.id))) {
    const txt = await fsp.readFile(secretFile(server.id), 'utf8');
    const m = txt.match(/secret_key\s*=\s*"([^"]+)"/);
    if (m) key = m[1];
  }

  // no secret yet -> walk the user through the claim flow
  if (!key) {
    log(server.id, 'no secret key found - generating a claim link (free, takes a minute)');
    try {
      const { code, url } = await claimUrl(server);
      startExchange(server, code);
      return { ...status(server.id), pendingClaim: true, claimUrl: url };
    } catch (err) {
      st.error = err.message;
      log(server.id, `could not start the claim flow: ${err.message}`);
      throw err;
    }
  }

  st.error = null;
  st.status = 'starting';
  st.tunnels = [];
  await fsp.writeFile(secretFile(server.id), `secret_key = "${key}"\n`).catch(() => {});
  await fsp.rm(logFile(server.id), { force: true }).catch(() => {});

  const args = ['--secret', key, '--socket-path', socketFile(server.id), '--log-path', logFile(server.id)];
  const proc = spawn(agentBin(), args, { cwd: dirFor(server.id), env: { ...process.env, NO_COLOR: '1' } });
  st.proc = proc;
  st.startedAt = Date.now();
  st.secret = key;
  st.status = 'connected';
  tailLog(server.id);
  log(server.id, `tunnel daemon started for 127.0.0.1:${server.port}`);

  proc.stdout.on('data', (d) => handleAgentOutput(server.id, d.toString()));
  proc.stderr.on('data', (d) => handleAgentOutput(server.id, d.toString()));
  proc.on('error', (err) => { st.error = err.message; st.proc = null; st.status = 'error'; log(server.id, `daemon error: ${err.message}`); emit(server.id); });
  proc.on('exit', (code) => {
    st.proc = null;
    st.status = 'stopped';
    if (st.watcher) { clearInterval(st.watcher); st.watcher = null; }
    if (code && code !== 0) st.error = `playit daemon exited with code ${code}`;
    log(server.id, `tunnel daemon stopped (code ${code})`);
    persist(server.id);
    emit(server.id);
  });

  db.update('servers', server.id, {
    playitSecret: key,
    playit: { ...(server.playit || {}), enabled: true, status: 'connected', claimed: true },
  });
  logger.ok('playit', `tunnel daemon running for ${server.name}`);
  emit(server.id);
  return status(server.id);
}
exports.start = start;

function handleAgentOutput(serverId, chunk) {
  const st = state(serverId);
  for (const line of stripAnsi(chunk).split(/\r?\n/)) {
    if (!line.trim()) continue;
    st.lastLine = line.trim();
    parseTunnels(line).forEach((t) => { if (!st.tunnels.includes(t)) st.tunnels.push(t); });
    if (/error|failed/i.test(line)) st.error = line.trim().slice(0, 300);
    log(serverId, line.trim());
  }
  persist(serverId);
  emit(serverId);
}

async function stop(serverId) {
  const st = state(serverId);
  if (st.claimProc) { try { st.claimProc.kill('SIGTERM'); } catch (_) {} st.claimProc = null; }
  if (st.watcher) { clearInterval(st.watcher); st.watcher = null; }
  if (st.proc) {
    try { st.proc.kill('SIGTERM'); } catch (_) {}
    setTimeout(() => { try { st.proc && st.proc.kill('SIGKILL'); } catch (_) {} }, 4000);
  }
  st.proc = null;
  st.status = 'stopped';
  const server = db.find('servers', (s) => s.id === serverId);
  if (server) db.update('servers', serverId, { playit: { ...(server.playit || {}), enabled: false, status: 'stopped' } });
  emit(serverId);
  return status(serverId);
}
exports.stop = stop;

/** Forget the secret so a brand new claim link is generated. */
async function reset(serverId) {
  await stop(serverId);
  try { await run(cliBin(), ['reset'], { timeout: 10000 }); } catch (_) {}
  await fsp.rm(dirFor(serverId), { recursive: true, force: true }).catch(() => {});
  const st = state(serverId);
  st.claimUrl = null; st.claimCode = null; st.tunnels = []; st.error = null; st.secret = null;
  const server = db.find('servers', (s) => s.id === serverId);
  if (server) db.update('servers', serverId, { playitSecret: '', playit: { enabled: false, status: 'stopped', tunnels: [], claimUrl: null, claimed: false } });
  log(serverId, 'tunnel reset - start it again to get a fresh claim link');
  return status(serverId);
}
exports.reset = reset;

async function setSecret(server, secret) {
  await ensureDir(dirFor(server.id));
  await fsp.writeFile(secretFile(server.id), `secret_key = "${String(secret).replace(/"/g, '')}"\n`);
  db.update('servers', server.id, { playitSecret: String(secret), playit: { ...(server.playit || {}), claimed: true } });
  const st = state(server.id);
  st.secret = String(secret);
  st.claimUrl = null;
  if (st.proc) { await stop(server.id); await start({ ...server, playitSecret: secret }); }
  return status(server.id);
}
exports.setSecret = setSecret;

async function markClaimed(serverId) {
  const server = db.find('servers', (s) => s.id === serverId);
  if (server) db.update('servers', serverId, { playit: { ...(server.playit || {}), claimed: true, status: 'connected' } });
  return status(serverId);
}
exports.markClaimed = markClaimed;

function status(serverId) {
  const st = state(serverId);
  const server = db.find('servers', (s) => s.id === serverId);
  const persisted = (server && server.playit) || {};
  const tunnels = st.tunnels.length ? st.tunnels : persisted.tunnels || [];
  return {
    running: !!st.proc,
    pendingClaim: !!st.claimProc,
    status: st.proc ? 'connected' : st.claimProc ? 'unclaimed' : st.status,
    claimUrl: st.claimUrl || persisted.claimUrl || null,
    claimCode: st.claimCode || null,
    tunnels,
    publicAddress: tunnels[0] || null,
    localAddress: server ? `127.0.0.1:${server.port}` : null,
    error: st.error,
    lastLine: st.lastLine || persisted.lastLine || null,
    startedAt: st.startedAt,
    binaries: { agent: agentBin(), cli: cliBin(), installed: fs.existsSync(agentBin()) && fs.existsSync(cliBin()) },
    binaryInstalled: fs.existsSync(agentBin()) && fs.existsSync(cliBin()),
    hasSecret: !!(st.secret || (server && server.playitSecret) || cfg.playitGlobalSecret),
    autostart: !!persisted.autostart,
    accountLinked: !!persisted.claimed,
  };
}
exports.status = status;

async function stopAll() {
  for (const [id, st] of agents) {
    if (st.proc) { try { st.proc.kill('SIGTERM'); } catch (_) {} }
    if (st.claimProc) { try { st.claimProc.kill('SIGTERM'); } catch (_) {} }
    if (st.watcher) clearInterval(st.watcher);
    void id;
  }
}
exports.stopAll = stopAll;
