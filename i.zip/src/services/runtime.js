'use strict';
/**
 * Runtime / process supervisor.
 *
 * Every Minecraft server is a child process of the panel (the "local" node
 * runtime). This module owns:
 *   - lifecycle: install -> start -> stop/restart/kill
 *   - stdin/stdout piping with a rolling log buffer per server
 *   - player tracking (join/leave detection) and readiness detection
 *   - crash detection & optional auto-restart
 *   - an event bus the WebSocket layer subscribes to
 */
const { spawn } = require('child_process');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const EventEmitter = require('events');

const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { stripAnsi, sleep, formatBytes } = require('../utils');
const stats = require('./stats');
const docker = require('./docker');

class RingBuffer {
  constructor(limit) { this.limit = limit; this.items = []; this.seq = 0; }
  push(line) {
    this.seq += 1;
    this.items.push({ seq: this.seq, line, at: Date.now() });
    if (this.items.length > this.limit) this.items.splice(0, this.items.length - this.limit);
  }
  since(seq) { return this.items.filter((i) => i.seq > seq); }
  all() { return this.items.map((i) => i.line); }
  text() { return this.all().join('\n'); }
  clear() { this.items = []; }
}

const STATUS = {
  OFFLINE: 'offline',
  STARTING: 'starting',
  RUNNING: 'running',
  STOPPING: 'stopping',
  INSTALLING: 'installing',
  CRASHED: 'crashed',
  SUSPENDED: 'suspended',
};

/** id -> runtime state */
const runtimes = new Map();
const events = new EventEmitter();
events.setMaxListeners(0);

function serverDir(server) { return path.join(cfg.serverDataDir, server.id); }

/** Servers on a non-local node are executed by that node's agent. */
function isRemote(server) {
  return Boolean(server && server.nodeId && server.nodeId !== 'local');
}
exports.isRemote = isRemote;

/**
 * Which backend runs servers on this node?
 *   'process' (default) - a child process of the panel/agent
 *   'docker'            - a real Docker container (see services/docker.js)
 * Precedence: server.backend -> node.backend -> NODE_RUNTIME env -> 'process'.
 */
function backendFor(server) {
  const nodeId = (server && server.nodeId) || 'local';
  const node = db.find('nodes', (n) => n.id === nodeId) || null;
  const raw = (server && server.backend) || (node && node.backend) || process.env.NODE_RUNTIME || 'process';
  return raw === 'docker' ? 'docker' : 'process';
}
exports.backendFor = backendFor;

function usesDocker(server) {
  return !isRemote(server) && backendFor(server) === 'docker';
}
exports.usesDocker = usesDocker;

/** General-purpose images are Docker workloads, not Minecraft JVM servers. */
function isContainerWorkload(server) { return Boolean(server && server.workloadType === 'container'); }
exports.isContainerWorkload = isContainerWorkload;

function defaultContainerName(server) {
  return docker.containerName(server.id);
}
exports.defaultContainerName = defaultContainerName;

function state(serverId) {
  // Accept a server record too - silently keying state by an object would create
  // a phantom entry and make everything report "offline".
  if (serverId && typeof serverId === 'object') serverId = serverId.id;
  if (!runtimes.has(serverId)) {
    runtimes.set(serverId, {
      id: serverId,
      proc: null,
      status: STATUS.OFFLINE,
      logs: new RingBuffer(cfg.logBufferLines),
      startedAt: null,
      exitCode: null,
      players: new Map(),
      maxPlayers: 20,
      installProgress: null,
      lastError: null,
      manualStop: false,
      remotePid: null,
      remoteStats: null,
      container: null,          // docker container name when backend === 'docker'
      containerId: null,
      stats: { cpu: 0, memory: 0, memoryBytes: 0, uptime: 0, tps: null },
      started: 0,
    });
  }
  return runtimes.get(serverId);
}

function emit(id, type, data) { events.emit('event', { serverId: id, type, data }); }

/**
 * Same fan-out as appendLog() but for lines the panel produced itself or
 * mirrored from a remote node agent (no ANSI stripping surprises, no jvm
 * readiness heuristics that would be wrong for mirrored output).
 */
function pushExternalLog(serverId, chunk) {
  appendLog(serverId, chunk);
}
exports.pushExternalLog = pushExternalLog;

function setStatus(serverId, status, extra = {}) {
  const rt = state(serverId);
  rt.status = status;
  db.update('servers', serverId, { status, ...extra });
  emit(serverId, 'status', { status, ...extra });
}

function appendLog(serverId, chunk) {
  const rt = state(serverId);
  const clean = stripAnsi(String(chunk));
  const lines = clean.split(/\r?\n/);
  const n = lines.length;
  for (let i = 0; i < n; i++) {
    const raw = lines[i];
    if (raw === '' && (i === n - 1 || i === 0)) continue; // drop split filler lines
    rt.logs.push(raw);
  }
  const payload = lines.filter((l, i) => !(l === '' && i === n - 1)).join('\n');
  if (payload.trim()) emit(serverId, 'log', payload);
  inspectOutput(serverId, clean);
}

/** Persist the exact sshx session announced by a general-purpose workload and
 * push it to an already-open Console page. The URL is a capability link, not
 * a panel credential, so it is cleared when that session ends. */
function setSshxState(serverId, patch) {
  const server = db.find('servers', (s) => s.id === serverId);
  if (!server || !isContainerWorkload(server)) return null;
  const current = { status: 'offline', url: '', error: '', updatedAt: null, ...(server.sshx || {}) };
  const next = { ...current, ...patch, updatedAt: new Date().toISOString() };
  db.update('servers', serverId, { sshx: next });
  state(serverId).sshx = next;
  emit(serverId, 'sshx', next);
  return next;
}
exports.setSshxState = setSshxState;

const PLAYER_RE = {
  join: /\[\w+ INFO\]: (\w{3,16})\[?[^\]]*\]? joined the game|(\w{3,16}) joined the game/i,
  leave: /(\w{3,16}) left the game/i,
  maxPlayers: /max-players=(\d+)/i,
};

function inspectOutput(serverId, text) {
  const rt = state(serverId);
  const server = db.find('servers', (s) => s.id === serverId);
  if (isContainerWorkload(server)) {
    const session = String(text).match(/https:\/\/sshx\.io\/[^\s'"<>]+/i);
    if (session) {
      const url = session[0].replace(/[.,;:!?]+$/, '');
      if ((server.sshx || {}).url !== url || (server.sshx || {}).status !== 'ready') {
        setSshxState(serverId, { status: 'ready', url, error: '' });
        db.log({ actor: 'system', action: 'container.sshx.ready', serverId, serverName: server.name, detail: url });
      }
    }
    const ended = String(text).match(/\[sshx\] session ended \(exit ([0-9]+)\)/i);
    if (ended) setSshxState(serverId, { status: Number(ended[1]) === 0 ? 'offline' : 'error', url: '', error: `sshx session ended with code ${ended[1]}` });
  }
  if (/Done \([0-9.]+s\)! For help, type "help"/.test(text) || /For help, type "help"/.test(text)) {
    if (rt.status === STATUS.STARTING) setStatus(serverId, STATUS.RUNNING);
    emit(serverId, 'ready', { at: Date.now() });
  }
  if (/\[Server thread\/INFO\]: Starting minecraft server version/i.test(text)) {
    emit(serverId, 'boot', {});
  }
  for (const line of text.split(/\r?\n/)) {
    const join = line.match(PLAYER_RE.join);
    if (join) {
      const name = join[1] || join[2];
      if (name) { rt.players.set(name.toLowerCase(), { name, joinedAt: Date.now() }); emit(serverId, 'players', [...rt.players.values()]); }
    }
    const leave = line.match(PLAYER_RE.leave);
    if (leave) {
      const name = leave[1];
      if (name) { rt.players.delete(name.toLowerCase()); emit(serverId, 'players', [...rt.players.values()]); }
    }
    const maxP = line.match(PLAYER_RE.maxPlayers);
    if (maxP) rt.maxPlayers = parseInt(maxP[1], 10);
    const err = line.match(/(Exception|Error|FAILED TO|Could not load|Unable to access)/);
    if (err) rt.lastError = line.slice(0, 400);
  }
}

/* --------------------------- command builder --------------------------- */
const AIKAR_FLAGS = [
  '-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=200',
  '-XX:+UnlockExperimentalVMOptions', '-XX:+DisableExplicitGC', '-XX:+AlwaysPreTouch',
  '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=8M',
  '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4',
  '-XX:InitiatingHeapOccupancyPercent=15', '-XX:G1MixedGCLiveThresholdPercent=90',
  '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32', '-XX:+PerfDisableSharedMem',
  '-XX:MaxTenuringThreshold=1', '-Dusing.aikars.flags=https://mcflags.emc.gs', '-Daikars.new.flags=true',
];

function resolveJava(server) {
  if (server.javaPath) {
    const p = server.javaPath;
    if (fs.existsSync(p)) return p;
  }
  const managed = path.join(cfg.javaDir, `jre-${server.javaVersion || '21'}`, 'bin', 'java');
  if (fs.existsSync(managed)) return managed;
  return process.env.JAVA_BIN || cfg.javaBin || 'java';
}

/**
 * Guarantee the JVM a server needs is actually available.
 * Installs provision Java up front, but data/java can be wiped (fresh clone,
 * re-install, moved host) - in that case we download the runtime instead of
 * silently launching with whatever `java` happens to be on PATH.
 */
async function ensureJavaFor(server) {
  const java = require('./java');
  const { javaFor } = require('./versions');

  if (server.javaPath && fs.existsSync(server.javaPath)) return server.javaPath;

  const required = Number(server.javaVersion || javaFor(server.version) || 21);
  const managed = await java.managedPath(required);
  if (managed) {
    db.update('servers', server.id, { javaPath: managed, javaVersion: required });
    return managed;
  }

  appendLog(server.id, `[Zenith] Java ${required} runtime not found - downloading Temurin JRE ${required} (one time only)...`);
  let lastPct = -1;
  try {
    const bin = await java.ensure(required, (p) => {
      if (p.note) { appendLog(server.id, `[Zenith] ${p.note}`); return; }
      if (!p.total) return;
      const step = Math.floor(p.percent / 10) * 10;
      if (step <= lastPct) return; // keep the console readable - one line per 10%
      lastPct = step;
      appendLog(server.id, `[Zenith] Java ${required}: ${step}% (${formatBytes(p.received)} / ${formatBytes(p.total)})`);
    });
    db.update('servers', server.id, { javaPath: bin, javaVersion: required });
    return bin;
  } catch (err) {
    const system = process.env.JAVA_BIN || cfg.javaBin || 'java';
    const v = await java.versionOf(system).catch(() => null);
    if (v && v.major >= required) {
      appendLog(server.id, `[Zenith] Falling back to system JVM (${v.raw || system})`);
      return system;
    }
    throw new Error(`${server.serverType} ${server.version} needs Java ${required}+, but Temurin JRE ${required} could not be installed (${err.message}) and the system JVM is ${v ? `Java ${v.major}` : 'unusable'}.`);
  }
}
exports.ensureJavaFor = ensureJavaFor;

/**
 * The java argv (no binary) for a server - shared by the process and docker
 * backends so both launch the JVM exactly the same way.
 */
function jvmArgs(server) {
  const memory = Math.max(256, parseInt(server.memory || 2048, 10));
  const args = [`-Xms${Math.min(memory, 512)}M`, `-Xmx${memory}M`];
  if (server.aikarFlags !== false) args.push(...AIKAR_FLAGS);
  if (server.javaArgs) args.push(...String(server.javaArgs).split(/\s+/).filter(Boolean));
  if (server.serverType === 'FABRIC' || server.serverType === 'FORGE' || server.serverType === 'NEOFORGE' || server.serverType === 'QUILT') {
    args.push('-Dfabric.gameJarPath=server.jar');
  }
  return args;
}
exports.jvmArgs = jvmArgs;

function buildCommand(server) {
  if (isRemote(server)) throw new Error('Remote servers are launched by their node agent');
  if (usesDocker(server)) return dockerCommand(server);
  const java = resolveJava(server);
  const memory = Math.max(256, parseInt(server.memory || 2048, 10));
  const args = [`-Xms${Math.min(memory, 512)}M`, `-Xmx${memory}M`];
  if (server.aikarFlags !== false) args.push(...AIKAR_FLAGS);
  if (server.javaArgs) args.push(...String(server.javaArgs).split(/\s+/).filter(Boolean));
  if (server.serverType === 'FABRIC' || server.serverType === 'FORGE' || server.serverType === 'NEOFORGE' || server.serverType === 'QUILT') {
    args.push('-Dfabric.gameJarPath=server.jar');
  }
  const jar = server.jarFile || 'server.jar';
  args.push('-jar', jar);
  if (server.gui !== true) args.push('nogui');
  return { bin: java, args, jar };
}
/** The equivalent of buildCommand() for the docker backend. */
function dockerCommand(server) {
  const memory = Math.max(256, parseInt(server.memory || 2048, 10));
  const args = jvmArgs(server);
  const jar = server.jarFile || 'server.jar';
  args.push('-jar', jar, 'nogui');
  const node = db.find('nodes', (n) => n.id === (server.nodeId || 'local')) || null;
  const image = (server.dockerImage || (node && node.dockerImage)) || docker.DEFAULT_IMAGE(parseInt(server.javaVersion, 10) || 21);
  return {
    bin: 'docker',
    args: ['start', '-a', '-i', docker.containerName(server.id)],
    jar,
    docker: { image, javaArgs: args, memory, container: docker.containerName(server.id) },
  };
}
exports.dockerCommand = dockerCommand;
exports.buildCommand = buildCommand;

/* --------------------------- lifecycle --------------------------- */
async function ensureDirStructure(server) {
  const dir = serverDir(server);
  await fsp.mkdir(dir, { recursive: true });
  if (isContainerWorkload(server)) {
    // Clean only empty legacy skeleton directories; never destroy a user file
    // just because it happens to use one of Minecraft's conventional names.
    await Promise.all(['plugins', 'mods'].map((name) => fsp.rmdir(path.join(dir, name)).catch(() => {})));
    return dir;
  }
  await fsp.mkdir(path.join(dir, 'plugins'), { recursive: true }).catch(() => {});
  await fsp.mkdir(path.join(dir, 'mods'), { recursive: true }).catch(() => {});
  return dir;
}
exports.ensureDirStructure = ensureDirStructure;

async function writeEula(server) {
  const dir = await ensureDirStructure(server);
  await fsp.writeFile(path.join(dir, 'eula.txt'), `# Generated by Zenith Panel\neula=${server.eulaAccepted ? 'true' : 'false'}\n`);
  if (server.eulaAccepted) {
    const props = path.join(dir, 'server.properties');
    if (!fs.existsSync(props)) {
      await fsp.writeFile(props, [
        `motd=${server.name}`,
        `server-port=${server.port}`,
        `server-ip=${server.ip || '0.0.0.0'}`,
        `max-players=${server.maxPlayers || 20}`,
        `online-mode=${server.onlineMode === false ? 'false' : 'true'}`,
        `enable-command-block=${server.enableCommandBlock ? 'true' : 'false'}`,
        'level-name=world',
        'level-seed=',
        'gamemode=survival',
        'difficulty=easy',
        'pvp=true',
        'spawn-protection=16',
        'view-distance=10',
        'simulation-distance=10',
        `query.port=${server.port}`,
        'enable-rcon=false',
        'sync-chunk-writes=false',
        '',
      ].join('\n'));
    } else {
      // keep the port in sync with the panel allocation
      await patchProperties(props, { 'server-port': String(server.port), 'query.port': String(server.port) });
    }
  }
}
exports.writeEula = writeEula;

async function patchProperties(file, patch) {
  let txt = '';
  try { txt = await fsp.readFile(file, 'utf8'); } catch { return; }
  for (const [key, value] of Object.entries(patch)) {
    const re = new RegExp(`^${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}=.*$`, 'm');
    if (re.test(txt)) txt = txt.replace(re, `${key}=${value}`);
    else txt += `${txt.endsWith('\n') ? '' : '\n'}${key}=${value}\n`;
  }
  await fsp.writeFile(file, txt);
}
exports.patchProperties = patchProperties;

async function start(server, { silent = false } = {}) {
  server = db.find('servers', (s) => s.id === server.id) || server;
  const rt = state(server.id);
  if (isRemote(server)) {
    if (rt.remotePid) throw new Error('Server is already running on its node');
    return require('./remote').start(server);
  }
  if (rt.proc) throw new Error('Server is already running');
  if (isContainerWorkload(server)) return startContainerWorkload(server, { silent });
  const dir = await ensureDirStructure(server);

  if (!server.eulaAccepted) throw new Error('EULA not accepted - enable it in the server settings first');
  const jarPath = path.join(dir, server.jarFile || 'server.jar');
  if (!fs.existsSync(jarPath)) throw new Error(`Server jar not found (${server.jarFile || 'server.jar'}). Run the installer for ${server.serverType} ${server.version}.`);

  await writeEula(server);

  if (usesDocker(server)) return startDocker(server, { silent });

  // Provision the required JVM before we try to launch (no-op when it is already installed)
  server.javaPath = await ensureJavaFor(server);
  const { bin, args } = buildCommand(server);

  rt.manualStop = false;
  rt.lastError = null;
  setStatus(server.id, STATUS.STARTING);
  appendLog(server.id, `[Zenith] Launching: ${bin} ${args.join(' ')}`);

  const proc = spawn(bin, args, {
    cwd: dir,
    stdio: ['pipe', 'pipe', 'pipe'],
    env: { ...process.env, HOME: dir, JAVA_TOOL_OPTIONS: '' },
    detached: false,
  });

  rt.proc = proc;
  rt.startedAt = Date.now();
  rt.started += 1;
  rt.players.clear();

  proc.stdout.on('data', (d) => appendLog(server.id, d.toString('utf8')));
  proc.stderr.on('data', (d) => appendLog(server.id, d.toString('utf8')));
  proc.stdin.on('error', () => { /* process died */ });

  // safety: if the JVM never reports ready, still flip to running after 60s
  const readyTimer = setTimeout(() => {
    if (rt.status === STATUS.STARTING && rt.proc) setStatus(server.id, STATUS.RUNNING);
  }, 60000);

  proc.on('error', (err) => {
    appendLog(server.id, `[Zenith] Failed to launch: ${err.message}`);
    rt.lastError = err.message;
    setStatus(server.id, STATUS.CRASHED, { lastError: err.message });
    rt.proc = null;
  });

  proc.on('exit', (code, signal) => {
    clearTimeout(readyTimer);
    if (rt.readyTimer) { clearTimeout(rt.readyTimer); rt.readyTimer = null; }
    rt.proc = null;
    rt.startedAt = null;
    rt.exitCode = code;
    rt.players.clear();
    emit(server.id, 'players', []);
    const wasManual = rt.manualStop;
    appendLog(server.id, `[Zenith] Process exited (code ${code}${signal ? `, signal ${signal}` : ''})`);

    if (wasManual || code === 0) setStatus(server.id, STATUS.OFFLINE);
    else {
      setStatus(server.id, STATUS.CRASHED);
      logger.warn('runtime', `${server.name} crashed (code ${code})`);
      if (process.env.AUTO_RESTART_ON_CRASH === 'true') {
        setTimeout(() => {
          const fresh = db.find('servers', (s) => s.id === server.id);
          if (fresh && !state(server.id).proc) start(fresh, { silent: true }).catch((e) => logger.error('runtime', `auto-restart failed: ${e.message}`));
        }, 5000);
      }
    }
  });

  emit(server.id, 'started', { pid: proc.pid });
  logger.ok('runtime', `${server.name} started (pid ${proc.pid})`);
  if (!silent) db.log({ actor: 'system', action: 'server.start', serverId: server.id, serverName: server.name });
  return { pid: proc.pid, status: rt.status };
}
exports.start = start;

/** Best-effort progress line for the installation card (no-op for plain servers). */
function installNote(serverId, note) {
  if (!note) { setInstallProgress(serverId, null); return; }
  setInstallProgress(serverId, { step: 'docker', note, percent: 5 });
}

/* --------------------------- docker backend --------------------------- */

const CONTAINER_BOOTSTRAP_FILE = '.zenith-container-bootstrap';
const CONTAINER_SPEC_VERSION = 3;

function containerSpec(server, image, cpuCores) {
  return JSON.stringify({
    v: CONTAINER_SPEC_VERSION,
    image,
    memory: Math.max(256, parseInt(server.memory || 2048, 10)),
    cpu: Number(cpuCores || 0),
  });
}

/**
 * Curated Linux/bot templates intentionally use their upstream Docker image,
 * then prepare the connection tools SSHX requires. This runs *inside*
 * the workload as its image user (root for the curated images), never on the
 * panel host. It keeps a marker in the container filesystem so normal
 * stop/start does not redownload apt indexes every time.
 */
function containerBootstrapCommand() {
  return ['/bin/sh', '-lc', [
    'set -eu',
    `printf '%s\\n' 'Preparing SSHX browser session…' > /data/${CONTAINER_BOOTSTRAP_FILE}`,
    'if [ ! -f /var/lib/.zenith-base-tools-ready ]; then',
    '  if command -v apt-get >/dev/null 2>&1; then',
    '    export DEBIAN_FRONTEND=noninteractive',
    '    apt-get update',
    '    apt-get install -y --no-install-recommends ca-certificates curl',
    '    rm -rf /var/lib/apt/lists/*',
    '  fi',
    '  touch /var/lib/.zenith-base-tools-ready',
    'fi',
    // This is intentionally the exact install command requested for each new
    // container filesystem. Its true stdout/stderr remains in the console.
    'curl -sSf https://sshx.io/get | sh',
    `rm -f /data/${CONTAINER_BOOTSTRAP_FILE}`,
    'echo "[sshx] Starting SSHX browser terminal; the session link will be displayed in the panel."',
    '(sshx; code=$?; echo "[sshx] session ended (exit ${code})") &',
    'exec sleep infinity',
  ].join('\n')];
}

/** Start a generic VM/bot workload in a real Docker container. The process
 * stays alive as a tiny POSIX supervisor while SSHX provides its own browser
 * terminal session inside that workload, never on the panel host. */
async function startContainerWorkload(server, { silent = false } = {}) {
  const rt = state(server.id);
  const probe = docker.probe({ force: true });
  if (!probe.available) {
    const message = `Docker is not available on this node: ${probe.error}`;
    setSshxState(server.id, { status: 'error', url: '', error: message });
    appendLog(server.id, `[Zenith] ${message}`);
    rt.lastError = message;
    setStatus(server.id, STATUS.CRASHED, { lastError: message });
    throw new Error(message);
  }
  const imageDef = docker.workloadImage(server.containerTemplate);
  if (!imageDef) throw new Error(`Unsupported container image template: ${server.containerTemplate || 'none'}`);
  const dir = await ensureDirStructure(server);
  const name = server.containerName || docker.containerName(server.id);
  const cores = Number(server.cpuLimit || 0) > 0 ? Math.max(.01, Number(server.cpuLimit) / 100) : 0;
  const wantedSpec = containerSpec(server, imageDef.image, cores);
  rt.manualStop = false;
  rt.lastError = null;
  setStatus(server.id, STATUS.STARTING);
  installNote(server.id, `Pulling ${imageDef.image}…`);
  try {
    await docker.ensureImage(imageDef.image, { onLine: (line) => appendLog(server.id, line) });
    installNote(server.id, null);
    let existing = await docker.inspect(name).catch(() => null);
    // Reconcile any running container Docker reports but the panel has not yet
    // attached to (for example, just after a panel restart).
    if (existing && existing.running) {
      rt.container = name; rt.containerId = existing.id; rt.startedAt = Date.now();
      setStatus(server.id, STATUS.RUNNING);
      appendLog(server.id, `[Zenith] Adopted running ${imageDef.name} container ${name}.`);
      return { status: STATUS.RUNNING, container: name, image: imageDef.image, adopted: true };
    }

    let containerId = existing && existing.id;
    if (!existing || server.containerSpec !== wantedSpec) {
      if (existing) await docker.remove(name);
      const created = await docker.create({
        name, image: imageDef.image, dir,
        memoryMb: Math.max(256, parseInt(server.memory || 2048, 10)), memoryOverheadMb: 0, cpuCores: cores,
        // no application port is exposed by default; the Network tab documents
        // this honestly and users may run their own service inside the workload.
        ports: [], env: { HOME: '/data', TERM: 'xterm-256color', TZ: process.env.TZ || 'UTC' },
        // SSHX needs a PTY so browser keystrokes control an interactive shell,
        // while Docker keeps that shell isolated from the panel host.
        tty: true,
        command: containerBootstrapCommand(),
      });
      containerId = created.id;
      db.update('servers', server.id, { containerSpec: wantedSpec });
      appendLog(server.id, `[Zenith] Created ${imageDef.name} container ${name} from ${imageDef.image}. Preparing SSHX inside the container…`);
    } else {
      appendLog(server.id, `[Zenith] Reusing existing ${imageDef.name} container ${name}.`);
    }
    rt.container = name;
    rt.containerId = containerId;
    setSshxState(server.id, { status: 'starting', url: '', error: '' });
    const proc = docker.attach(name, {
      onLine: (chunk) => appendLog(server.id, chunk),
      onExit: (code, signal) => {
        rt.lastContainer = rt.container; rt.container = null; rt.proc = null; rt.startedAt = null; rt.exitCode = code;
        setSshxState(server.id, { status: 'offline', url: '', error: code === 0 ? '' : `Container exited with code ${code}` });
        appendLog(server.id, `[Zenith] Container exited (code ${code}${signal ? `, signal ${signal}` : ''})`);
        const manual = rt.manualStop;
        if (manual || code === 0) setStatus(server.id, STATUS.OFFLINE);
        else { setStatus(server.id, STATUS.CRASHED); rt.lastError = `Container exited with code ${code}`; }
      },
    });
    rt.proc = proc;
    rt.startedAt = Date.now();
    rt.started += 1;
    setStatus(server.id, STATUS.RUNNING);
    appendLog(server.id, `[Zenith] ${imageDef.name} is running. SSHX is starting; its browser-session link will appear in Console.`);
    if (!silent) db.log({ actor: 'system', action: 'container.start', serverId: server.id, serverName: server.name, detail: imageDef.image });
    return { pid: proc.pid, status: STATUS.RUNNING, container: name, image: imageDef.image };
  } catch (err) {
    installNote(server.id, null);
    rt.lastError = err.message;
    setSshxState(server.id, { status: 'error', url: '', error: err.message });
    appendLog(server.id, `[Zenith] ${err.message}`);
    setStatus(server.id, STATUS.CRASHED, { lastError: err.message });
    throw err;
  }
}
exports.startContainerWorkload = startContainerWorkload;

/**
 * Launch a server inside a real Docker container.
 *
 * Nothing here is simulated: the image is pulled (with retries), the container
 * is created, started and attached, and any Docker error is appended to the
 * console + stored as `lastError` so the UI shows the exact message.
 */
async function startDocker(server, { silent = false } = {}) {
  const rt = state(server.id);
  // rt.proc is the live attach; rt.container only means "a container exists"
  if (rt.proc) throw new Error('Server is already running');

  const probe = docker.probe({ force: true });
  if (!probe.available) {
    const message = `Docker is not available on this node: ${probe.error}`;
    appendLog(server.id, `[Zenith] ${message}`);
    rt.lastError = message;
    setStatus(server.id, STATUS.CRASHED, { lastError: message });
    throw new Error(message);
  }

  const dir = await ensureDirStructure(server);
  const jarPath = path.join(dir, server.jarFile || 'server.jar');
  if (!fs.existsSync(jarPath)) throw new Error(`Server jar not found (${server.jarFile || 'server.jar'}). Run the installer for ${server.serverType} ${server.version}.`);

  const node = db.find('nodes', (n) => n.id === (server.nodeId || 'local')) || {};
  const image = server.dockerImage || node.dockerImage || docker.DEFAULT_IMAGE(parseInt(server.javaVersion, 10) || 21);
  const name = server.containerName || docker.containerName(server.id);
  const cores = Number(node.cpuLimit || server.cpuLimit || 0) || 0;

  rt.manualStop = false;
  rt.lastError = null;
  setStatus(server.id, STATUS.STARTING);
  installNote(server.id, 'Pulling the container image…');

  try {
    await docker.ensureImage(image, { onLine: (line) => appendLog(server.id, line) });
  } catch (err) {
    installNote(server.id, null);
    rt.lastError = err.message;
    appendLog(server.id, `[Zenith] ${err.message}`);
    setStatus(server.id, STATUS.CRASHED, { lastError: err.message });
    throw err;
  }
  installNote(server.id, null);

  // a container left over from a previous run is reused only if it still matches
  const existing = await docker.inspect(name).catch(() => null);
  if (existing) await docker.remove(name).catch(() => {});

  const command = dockerCommand(server);
  const created = await docker.create({
    name,
    image,
    dir,
    memoryMb: Math.max(256, parseInt(server.memory || 2048, 10)),
    cpuCores: cores,
    ports: [server.port],
    javaArgs: command.docker.javaArgs.slice(0, -3), // drop "-jar <jar> nogui"
    jar: server.jarFile || 'server.jar',
    env: { HOME: '/data', TZ: process.env.TZ || 'UTC' },
  }).catch((err) => {
    rt.lastError = err.message;
    appendLog(server.id, `[Zenith] ${err.message}`);
    setStatus(server.id, STATUS.CRASHED, { lastError: err.message });
    throw err;
  });

  rt.container = name;
  rt.containerId = created.id;
  appendLog(server.id, `[Zenith] Launching container ${name} (image ${image}): docker ${created.command.replace(/^docker /, '')}`);

  const proc = docker.attach(name, {
    onLine: (chunk) => appendLog(server.id, chunk),
    onExit: (code, signal) => {
      clearTimeout(rt.readyTimer);
      rt.lastContainer = rt.container;
      rt.container = null;
      rt.proc = null;
      rt.startedAt = null;
      rt.exitCode = code;
      rt.players.clear();
      emit(server.id, 'players', []);
      appendLog(server.id, `[Zenith] Container exited (code ${code}${signal ? `, signal ${signal}` : ''})`);
      const wasManual = rt.manualStop;
      if (wasManual || code === 0) setStatus(server.id, STATUS.OFFLINE);
      else {
        setStatus(server.id, STATUS.CRASHED);
        logger.warn('runtime', `${server.name} container crashed (code ${code})`);
        if (process.env.AUTO_RESTART_ON_CRASH === 'true') {
          setTimeout(() => {
            const fresh = db.find('servers', (s) => s.id === server.id);
            if (fresh && !state(server.id).proc) start(fresh, { silent: true }).catch((e) => logger.error('runtime', `auto-restart failed: ${e.message}`));
          }, 5000);
        }
      }
    },
  });

  rt.proc = proc;
  rt.startedAt = Date.now();
  rt.started += 1;
  rt.players.clear();
  rt.readyTimer = setTimeout(() => {
    if (rt.status === STATUS.STARTING && rt.proc) setStatus(server.id, STATUS.RUNNING);
  }, 60000);

  emit(server.id, 'started', { pid: proc.pid, container: name });
  logger.ok('runtime', `${server.name} started in container ${name} (pid ${proc.pid})`);
  if (!silent) db.log({ actor: 'system', action: 'server.start', serverId: server.id, serverName: server.name, detail: `container ${name}` });
  return { pid: proc.pid, status: rt.status, container: name, image };
}
exports.startDocker = startDocker;

async function stop(serverId, { force = false } = {}) {
  const rt = state(serverId);
  const remoteServer = db.find('servers', (s) => s.id === serverId);
  if (isRemote(remoteServer)) return require('./remote').stop(remoteServer, { force });
  if (!rt.proc) {
    // A Docker workload can survive a panel restart and be reconciled without
    // a live attach process. It is still an online container and must be
    // stopped through Docker rather than merely relabelled offline.
    if (rt.container) {
      rt.manualStop = true;
      setStatus(serverId, STATUS.STOPPING);
      try { await docker.stop(rt.container, { timeout: force ? 3 : 15 }); }
      catch (err) { throw new Error(`docker stop ${rt.container} failed: ${err.message}`); }
      rt.lastContainer = rt.container;
      rt.container = null;
      rt.containerId = null;
      rt.startedAt = null;
      if (isContainerWorkload(remoteServer)) setSshxState(serverId, { status: 'offline', url: '', error: '' });
      setStatus(serverId, STATUS.OFFLINE);
      return { status: STATUS.OFFLINE, container: rt.lastContainer };
    }
    if (isContainerWorkload(remoteServer)) setSshxState(serverId, { status: 'offline', url: '', error: '' });
    setStatus(serverId, STATUS.OFFLINE);
    return { status: STATUS.OFFLINE, alreadyStopped: true };
  }
  rt.manualStop = true;
  setStatus(serverId, STATUS.STOPPING);
  if (rt.container) {
    const server = db.find('servers', (s) => s.id === serverId) || {};
    // Generic workloads have no Minecraft stdin protocol. Stop their actual
    // Docker process directly instead of pretending a "stop" chat command is
    // meaningful; Docker's result remains the source of truth.
    if (isContainerWorkload(server)) {
      await docker.stop(rt.container, { timeout: force ? 3 : 15 });
      // docker stop has confirmed the workload ended; clear the capability URL
      // immediately rather than waiting for the attach child to emit close.
      setSshxState(serverId, { status: 'offline', url: '', error: '' });
      return { status: STATUS.STOPPING, container: rt.container };
    }
    // graceful: the JVM gets its stop command through the attached stdin, then
    // docker stop (SIGTERM → SIGKILL) guarantees the container really ends.
    const stopCommand = server.stopCommand || (['BUNGEECORD', 'VELOCITY'].includes(server.serverType) ? 'end' : 'stop');
    if (!force) { try { rt.proc.stdin.write(`${stopCommand}\n`); } catch (_) {} }
    const deadline = Date.now() + (force ? 3000 : cfg.stopTimeout * 1000);
    while (rt.proc && Date.now() < deadline) await sleep(300);
    if (rt.proc) {
      try { await docker.stop(rt.container, { timeout: force ? 3 : 15 }); } catch (err) { logger.warn('runtime', `docker stop ${rt.container}: ${err.message}`); }
      try { if (rt.proc) await docker.kill(rt.container); } catch (_) { /* already gone */ }
    }
    rt.container = null;
    return { status: STATUS.OFFLINE, container: serverId };
  }
  if (force) {
    rt.proc.kill('SIGKILL');
    return { status: STATUS.STOPPING, forced: true };
  }
  const server = db.find('servers', (s) => s.id === serverId) || {};
  const stopCommand = server.stopCommand || (['BUNGEECORD', 'VELOCITY'].includes(server.serverType) ? 'end' : 'stop');
  try { rt.proc.stdin.write(`${stopCommand}\n`); } catch (_) {}
  const deadline = Date.now() + cfg.stopTimeout * 1000;
  while (rt.proc && Date.now() < deadline) await sleep(300);
  if (rt.proc) { try { rt.proc.kill('SIGTERM'); } catch (_) {} }
  await sleep(1500);
  if (rt.proc) { try { rt.proc.kill('SIGKILL'); } catch (_) {} }
  return { status: STATUS.OFFLINE };
}
exports.stop = stop;

async function kill(serverId) {
  const rt = state(serverId);
  const remoteServer = db.find('servers', (s) => s.id === serverId);
  if (isRemote(remoteServer)) return require('./remote').kill(remoteServer);
  if (!rt.proc && !rt.container) return false;
  rt.manualStop = true;
  if (rt.container) {
    try { await docker.kill(rt.container); } catch (err) { logger.warn('runtime', `docker kill ${rt.container}: ${err.message}`); }
    rt.lastContainer = rt.container;
    rt.container = null;
  }
  try { rt.proc.kill('SIGKILL'); } catch (_) { /* gone */ }
  if (isContainerWorkload(remoteServer)) setSshxState(serverId, { status: 'offline', url: '', error: '' });
  setStatus(serverId, STATUS.OFFLINE);
  return true;
}
exports.kill = kill;

async function restart(serverId, opts = {}) {
  await stop(serverId, opts);
  await sleep(1200);
  const server = db.find('servers', (s) => s.id === serverId);
  if (!server) throw new Error('Server not found');
  return start(server);
}
exports.restart = restart;

function sendCommand(serverId, command) {
  const rt = state(serverId);
  const remoteServer = db.find('servers', (s) => s.id === serverId);
  if (isRemote(remoteServer)) {
    // fire-and-forget: the console route stays synchronous, errors land in the log
    require('./remote').command(remoteServer, command)
      .catch((err) => pushExternalLog(serverId, `[Zenith] command failed: ${err.message}`));
    return true;
  }
  if (!rt.proc) throw new Error('Server is not running');
  const line = String(command).replace(/[\r\n]+/g, ' ').trim();
  if (!line) return false;
  rt.proc.stdin.write(`${line}\n`);
  appendLog(serverId, `> ${line}`);
  emit(serverId, 'command', line);
  return true;
}
exports.sendCommand = sendCommand;

/* --------------------------- live stats --------------------------- */
async function sampleStats(serverId) {
  const rt = state(serverId);
  if (rt.remotePid) {
    const base = rt.remoteStats || {};
    rt.stats = { ...base, uptime: rt.startedAt ? Date.now() - rt.startedAt : base.uptime || 0, players: rt.players.size };
    return rt.stats;
  }
  if ((!rt.proc && !rt.container) || !rt.startedAt) {
    rt.stats = { cpu: 0, memory: 0, memoryBytes: 0, uptime: 0, tps: null };
    return rt.stats;
  }
  if (rt.container) {
    const server = db.find('servers', (s) => s.id === serverId) || {};
    const memLimitBytes = Math.max(256, Number(server.memory || 2048)) * 1024 * 1024;
    const live = await docker.stats(rt.container).catch((err) => ({ ok: false, error: err.message }));
    if (live.ok) {
      rt.stats = {
        cpu: Number(live.cpu.toFixed(1)),
        memory: Math.min(Number((((live.memoryBytes || 0) / memLimitBytes) * 100).toFixed(1)), 100),
        memoryBytes: live.memoryBytes || 0,
        memoryLimitBytes: live.memoryLimitBytes || memLimitBytes,
        memoryPretty: formatBytes(live.memoryBytes || 0),
        uptime: Date.now() - rt.startedAt,
        processes: live.pids || 0,
        netIO: live.netIO,
        blockIO: live.blockIO,
        players: rt.players.size,
        maxPlayers: rt.maxPlayers,
        container: rt.container,
        tps: rt.tps ?? null,
      };
      return rt.stats;
    }
    rt.stats = {
      cpu: 0, memory: 0, memoryBytes: 0, uptime: Date.now() - rt.startedAt,
      container: rt.container, containerError: live.error || 'docker stats unavailable',
      players: rt.players.size, maxPlayers: rt.maxPlayers,
    };
    return rt.stats;
  }
  const info = await stats.processTree(rt.proc.pid);
  const server = db.find('servers', (s) => s.id === serverId) || {};
  const memLimitBytes = Math.max(256, Number(server.memory || 2048)) * 1024 * 1024;
  rt.stats = {
    cpu: Number(info.cpu.toFixed(1)),
    memory: Math.min(Number(((info.rss / memLimitBytes) * 100).toFixed(1)), 100),
    memoryBytes: info.rss,
    memoryLimitBytes: memLimitBytes,
    memoryPretty: formatBytes(info.rss),
    uptime: Date.now() - rt.startedAt,
    processes: info.processes,
    players: rt.players.size,
    maxPlayers: rt.maxPlayers,
    tps: rt.tps ?? null,
  };
  return rt.stats;
}
exports.sampleStats = sampleStats;

function isOnline(serverId) {
  const rt = state(serverId);
  return Boolean(rt.proc || rt.container || rt.remotePid);
}
exports.isOnline = isOnline;

function getLogs(serverId, sinceSeq = 0) {
  const rt = state(serverId);
  if (sinceSeq) return { lines: rt.logs.since(sinceSeq), seq: rt.logs.seq, status: rt.status };
  return { lines: rt.logs.items.slice(-400), seq: rt.logs.seq, status: rt.status };
}
exports.getLogs = getLogs;

function clearLogs(serverId) { state(serverId).logs.clear(); emit(serverId, 'cleared', {}); }
exports.clearLogs = clearLogs;

function info(serverId) {
  const rt = state(serverId);
  return {
    status: rt.status,
    pid: rt.proc ? rt.proc.pid : (rt.remotePid || null),
    remote: Boolean(rt.remotePid),
    uptime: rt.startedAt ? Date.now() - rt.startedAt : 0,
    players: [...rt.players.values()],
    maxPlayers: rt.maxPlayers,
    stats: rt.stats,
    lastError: rt.lastError,
    restarts: rt.started,
    installProgress: rt.installProgress,
    container: rt.container,
    containerId: rt.containerId,
    backend: (() => { const s = db.find('servers', (x) => x.id === serverId); return s ? backendFor(s) : 'process'; })(),
    java: (() => { const s = db.find('servers', (x) => x.id === serverId); return s ? resolveJava(s) : null; })(),
  };
}
exports.info = info;

/* --------------------------- install helpers --------------------------- */
function setInstallProgress(serverId, progress) {
  const rt = state(serverId);
  rt.installProgress = progress;
  emit(serverId, 'install', progress);
}
exports.setInstallProgress = setInstallProgress;

function setStatusExternal(serverId, status) { setStatus(serverId, status); }
exports.setStatus = setStatusExternal;

/* --------------------------- shutdown --------------------------- */
async function shutdownAll() {
  const running = [...runtimes.values()].filter((r) => r.proc || r.container);
  logger.info('runtime', `Stopping ${running.length} running server(s)...`);
  await Promise.allSettled(running.map((r) => stop(r.id, { force: false })));
}

/**
 * Adopt containers that survived a panel restart on the docker backend.
 * Called from server.js at boot; returns what it found so the log is honest.
 */
async function reconcileContainers() {
  const containers = await docker.listServers();
  if (!containers.ok) return { supported: false, error: containers.error || 'docker unavailable', adopted: [] };
  const adopted = [];
  for (const c of containers.containers) {
    const server = db.find('servers', (s) => s.id === c.serverId);
    if (!server) continue;
    const rt = state(server.id);
    if (rt.proc || rt.container) continue;
    if (c.state === 'running') {
      rt.container = c.name;
      rt.containerId = c.id;
      rt.startedAt = Date.now();
      setStatus(server.id, STATUS.RUNNING);
      appendLog(server.id, `[Zenith] Adopted running container ${c.name} after panel restart (live console resumes on next start)`);
      adopted.push({ serverId: server.id, container: c.name, status: 'running' });
    } else {
      // A persisted SSHX link belongs to a live process only. Do not leave a
      // stale capability URL visible if Docker reports this workload stopped.
      if (isContainerWorkload(server)) setSshxState(server.id, { status: 'offline', url: '', error: '' });
      if (rt.status !== STATUS.OFFLINE) setStatus(server.id, STATUS.OFFLINE);
    }
  }
  return { supported: true, adopted, total: containers.containers.length };
}
exports.shutdownAll = shutdownAll;
exports.reconcileContainers = reconcileContainers;

function allStates() {
  return [...runtimes.entries()].map(([id, rt]) => ({ serverId: id, ...info(id) }));
}
exports.allStates = allStates;

exports.events = events;
exports.STATUS = STATUS;
exports.serverDir = serverDir;
exports.state = state;
