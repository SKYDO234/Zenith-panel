'use strict';
/**
 * Discord bot.
 *
 * A dependency-free Discord gateway client (`ws` is already a panel dependency)
 * plus a small command framework, so the panel can be operated from a Discord
 * server:
 *
 *   !help                       list the commands you may use
 *   !allocations [node]         free/used ports per node
 *   !newserver <name> [type] [version] [memory] [node]
 *                               asks for a username, registers the account if
 *                               needed, then creates + installs the server
 *   !servers                    your servers (admins see all)
 *   !status <id|name>           live status, players, RAM
 *   !start|!stop|!restart <id|name>
 *   !cmd <id|name> <command>    run a console command
 *   !players <id|name>          who is online
 *   !op <id|name> <player>      operator / heal / give shortcuts
 *   !give <id|name> <player> <item> [count]
 *   !heal <id|name> <player>
 *   !link <panelUsername> <password>
 *                               binds your Discord account to a panel account
 *                               (owner/admin only, one time)
 *   !whoami                     what the bot thinks you are
 *
 * Permissions: a Discord user may only use owner/admin commands when their
 * Discord id is linked to an owner/admin panel account AND (optionally) they
 * hold the configured role. Everything else is refused with a clear message.
 *
 * The transport is injectable (`bot.transport`) so the whole command surface can
 * be exercised from tests without a token.
 */
const db = require('../db');
const cfg = require('../config');
const logger = require('../logger');
const auth = require('../auth');
const { uid } = require('../utils');

const DISCORD_API = 'https://discord.com/api/v10';

/* ------------------------------ settings ------------------------------ */
function conf() {
  const s = db.settings() || {};
  return {
    enabled: Boolean(s.discordEnabled),
    token: s.discordToken || process.env.DISCORD_TOKEN || '',
    guildId: String(s.discordGuildId || process.env.DISCORD_GUILD_ID || '').trim(),
    adminRole: String(s.discordAdminRole || '').trim().toLowerCase(),
    prefix: (s.discordPrefix || '!').slice(0, 3),
    defaultMemory: parseInt(s.discordDefaultMemory || 2048, 10) || 2048,
    defaultType: (s.discordDefaultType || 'PAPER').toUpperCase(),
    defaultVersion: s.discordDefaultVersion || 'latest',
    allowRegistration: s.discordAllowRegistration !== false,
    channelId: String(s.discordChannelId || '').trim(),
    notifyChannelId: String(s.discordNotifChannelId || '').trim(),
  };
}
exports.conf = conf;

/* -------------------------- gateway state -------------------------- */
const state = {
  status: 'stopped',          // stopped | connecting | online | error
  user: null,
  guilds: [],
  startedAt: null,
  lastError: null,
  lastMessageAt: null,
  commandsHandled: 0,
  sequence: null,
  heartbeatMs: 41250,
  sessionId: null,
  resumeGatewayUrl: null,
  ws: null,
  heartbeatTimer: null,
};
exports.state = state;

const history = [];
function note(line, level = 'info') {
  history.push({ at: new Date().toISOString(), level, line: String(line).slice(0, 300) });
  if (history.length > 120) history.shift();
}
exports.log = () => history.slice().reverse();

/* ---------------------------- transport ---------------------------- */
/**
 * Real transport talks to Discord. Tests can replace it:
 *   bot.transport = { sendMessage(channelId, payload), fetchGuildMember(id) }
 */
const httpTransport = {
  async api(method, path, body) {
    const c = conf();
    const res = await fetch(`${DISCORD_API}${path}`, {
      method,
      headers: { Authorization: `Bot ${c.token}`, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch (_) { /* not json */ }
    if (!res.ok) {
      const msg = (json && (json.message || (json.errors && JSON.stringify(json.errors)))) || `HTTP ${res.status}`;
      throw new Error(`Discord API ${path}: ${msg}`);
    }
    return json;
  },
  async sendMessage(channelId, payload) {
    return httpTransport.api('POST', `/channels/${channelId}/messages`, payload);
  },
  async fetchGuildMember(guildId, userId) {
    return httpTransport.api('GET', `/guilds/${guildId}/members/${userId}`);
  },
  async gatewayUrl() {
    const res = await fetch(`${DISCORD_API}/gateway/bot`, { headers: { Authorization: `Bot ${conf().token}` } });
    if (!res.ok) throw new Error(`Discord rejected the bot token (HTTP ${res.status})`);
    return res.json();
  },
};
exports.transport = httpTransport;

/* --------------------------- permissions --------------------------- */
/** Map a Discord user to a panel account (explicit link, then username guess). */
function panelUserFor(discordUserId, username) {
  const users = db.get('users') || [];
  const byId = users.find((u) => u.discordId && String(u.discordId) === String(discordUserId));
  if (byId) return byId;
  if (username) return users.find((u) => u.username.toLowerCase() === String(username).toLowerCase()) || null;
  return null;
}
exports.panelUserFor = panelUserFor;

function linkDiscord(userId, discordId) {
  db.update('users', userId, { discordId: String(discordId), discordLinkedAt: new Date().toISOString() });
}
exports.link = linkDiscord;

/**
 * @returns {{ user: object|null, admin: boolean, reason: string }}
 */
function identity(msg) {
  const c = conf();
  const discordId = msg.author && msg.author.id;
  const user = panelUserFor(discordId, msg.panelUsername);
  const isGuildOwner = msg.guildOwnerId && String(msg.guildOwnerId) === String(discordId);
  const hasRole = c.adminRole && (msg.roles || []).map((r) => String(r).toLowerCase()).includes(c.adminRole);
  const admin = Boolean((user && auth.isAdmin(user)) || isGuildOwner || hasRole);
  let reason = 'linked panel account';
  if (!user && isGuildOwner) reason = 'Discord server owner';
  else if (!user && hasRole) reason = `holds the "${c.adminRole}" role`;
  else if (!user) reason = 'no linked panel account';
  return { user, admin, reason };
}
exports.identity = identity;

/* ----------------------------- helpers ----------------------------- */
function findServer(arg) {
  if (!arg) return null;
  const servers = db.get('servers') || [];
  const key = String(arg).trim();
  return servers.find((s) => s.id === key)
    || servers.find((s) => s.name.toLowerCase() === key.toLowerCase())
    || servers.find((s) => s.name.toLowerCase().startsWith(key.toLowerCase()))
    || null;
}

function ownedBy(user) {
  const all = db.get('servers') || [];
  if (!user) return [];
  if (auth.isAdmin(user)) return all;
  return all.filter((s) => s.ownerId === user.id || (s.subusers || []).some((su) => su.userId === user.id));
}

function fmtBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  return `${(bytes / 1024 ** i).toFixed(i ? 1 : 0)} ${units[i]}`;
}

function serverLine(server) {
  const runtime = require('./runtime');
  const info = runtime.info(server.id);
  const players = (info.players || []).length;
  return `\`${server.id}\` **${server.name}** - ${server.serverType} ${server.version} - ${info.status}${players ? ` - ${players} player(s)` : ''} - ${server.nodeName || 'local'}:${server.port}`;
}

async function reply(msg, content) {
  const transport = exports.transport;
  if (!msg.channelId) { note(`(test) reply: ${content}`, 'debug'); return { skipped: true }; }
  return transport.sendMessage(msg.channelId, { content: String(content).slice(0, 1900) });
}

/* ----------------------------- commands ----------------------------- */
const commands = new Map();
function define(name, def) { commands.set(name, { name, ...def }); }
exports.commands = commands;

define('help', {
  help: 'show this message',
  async run(ctx) {
    const { identity: id } = ctx;
    const usable = [...commands.values()].filter((c) => !c.adminOnly || id.admin);
    return [
      '**Zenith Panel bot**',
      ...usable.map((c) => `\`${ctx.prefix}${c.name}${c.usage ? ` ${c.usage}` : ''}\` - ${c.help}`),
      id.admin ? `You are recognised as **admin** (${id.reason}).` : 'Some commands need a linked admin/owner account.',
    ].join('\n');
  },
});

define('whoami', {
  help: 'which panel account the bot maps you to',
  async run(ctx) {
    const { identity: id } = ctx;
    return `Discord \`${ctx.msg.author && ctx.msg.author.id}\` -> panel user **${id.user ? id.user.username : 'none'}**`
      + ` (${id.user ? id.user.role : 'unknown'}) - admin: **${id.admin ? 'yes' : 'no'}** (${id.reason}).`
      + (id.user ? '' : '\nUse `!link <panelUsername> <password>` to bind your account.');
  },
});

define('link', {
  help: 'bind this Discord account to a panel account',
  usage: '<panelUsername> <password>',
  async run(ctx) {
    const [username, password] = ctx.args;
    if (!username || !password) return 'Usage: `!link <panelUsername> <password>`';
    const user = (db.get('users') || []).find((u) => u.username.toLowerCase() === username.toLowerCase());
    if (!user) return `No panel account named **${username}**.`;
    const ok = await auth.verifyPassword(password, auth.hashOf(user));
    if (!ok) return 'Wrong password - linking refused.';
    if (user.discordId && String(user.discordId) !== String(ctx.msg.author.id)) {
      return `**${user.username}** is already linked to another Discord account. Ask an owner to reset it.`;
    }
    linkDiscord(user.id, ctx.msg.author.id);
    db.log({ actor: user.username, action: 'discord.link', detail: `discord ${ctx.msg.author.id}` });
    note(`linked ${user.username} <-> discord ${ctx.msg.author.id}`);
    return `Linked **${user.username}** (${user.role}) to your Discord account. Try \`${ctx.prefix}help\`.`;
  },
});

define('allocations', {
  help: 'show port allocations per node',
  usage: '[node]',
  async run(ctx) {
    const nodes = db.get('nodes') || [];
    const servers = db.get('servers') || [];
    const filter = (ctx.args[0] || '').toLowerCase();
    const lines = ['**Port allocations**'];
    for (const node of nodes) {
      if (filter && !String(node.name).toLowerCase().includes(filter)) continue;
      const range = node.portRange || { start: 25565, end: 25665 };
      const total = range.end - range.start + 1;
      const used = servers.filter((s) => s.nodeId === node.id);
      const free = total - used.length;
      lines.push(`\n**${node.name}** (${node.status || 'unknown'}) - ${used.length}/${total} used, **${Math.max(0, free)} free** - range ${range.start}-${range.end}`);
      if (used.length) lines.push(used.slice(0, 12).map((s) => `> :${s.port} - ${s.name} (${s.ownerName}) - ${s.serverType} ${s.version}`).join('\n'));
      if (used.length > 12) lines.push(`> ...and ${used.length - 12} more`);
    }
    lines.push('\nCreate one with `' + ctx.prefix + 'newserver <name>` - the bot walks you through it.');
    return lines.join('\n');
  },
});

define('servers', {
  help: 'list servers you can manage',
  async run(ctx) {
    const list = ownedBy(ctx.identity.user);
    if (!list.length) return 'You have no servers yet. Try `' + ctx.prefix + 'newserver My Server`.';
    return [`**${list.length} server(s)**`, ...list.slice(0, 20).map(serverLine)].join('\n');
  },
});

define('status', {
  help: 'live status of a server',
  usage: '<id|name>',
  async run(ctx) {
    const server = findServer(ctx.args[0]);
    if (!server) return 'Server not found. `' + ctx.prefix + 'servers` lists them.';
    if (!canTouch(ctx, server)) return 'That server is not yours.';
    const runtime = require('./runtime');
    const info = runtime.info(server.id);
    const players = (info.players || []).map((p) => p.name).join(', ') || 'nobody online';
    return [
      serverLine(server),
      `status **${info.status}** - RAM ${info.stats && info.stats.memoryPretty ? info.stats.memoryPretty : '-'} - CPU ${info.stats ? info.stats.cpu : 0}%`,
      `players: ${players}`,
    ].join('\n');
  },
});

define('players', {
  help: 'who is online right now',
  usage: '<id|name>',
  async run(ctx) {
    const server = findServer(ctx.args[0]);
    if (!server) return 'Server not found.';
    if (!canTouch(ctx, server)) return 'That server is not yours.';
    const runtime = require('./runtime');
    const players = require('./players');
    players.refresh(server);
    const list = runtime.info(server.id).players || [];
    if (!list.length) return `**${server.name}**: nobody online (or the console is still starting).`;
    return `**${server.name}** - ${list.length}: ${list.map((p) => `\`${p.name}\``).join(', ')}`;
  },
});

for (const action of ['start', 'stop', 'restart', 'kill']) {
  define(action, {
    help: `${action} a server`,
    usage: '<id|name>',
    async run(ctx) {
      const server = findServer(ctx.args[0]);
      if (!server) return 'Server not found.';
      if (!canTouch(ctx, server)) return 'That server is not yours.';
      if (!ctx.identity.admin && server.ownerId !== (ctx.identity.user || {}).id) return 'Only the owner or an admin can power-cycle a server.';
      const runtime = require('./runtime');
      try {
        if (action === 'start') await runtime.start(server);
        else if (action === 'stop') await runtime.stop(server.id);
        else if (action === 'kill') await runtime.kill(server.id);
        else await runtime.restart(server.id);
        db.log({ actor: (ctx.identity.user || {}).username || 'discord', action: `discord.${action}`, serverId: server.id, serverName: server.name });
        return `**${server.name}**: ${action} requested.`;
      } catch (err) {
        return `Could not ${action} **${server.name}**: ${err.message}`;
      }
    },
  });
}

define('cmd', {
  help: 'run a console command',
  usage: '<id|name> <command>',
  adminOnly: true,
  async run(ctx) {
    const server = findServer(ctx.args[0]);
    if (!server) return 'Server not found.';
    if (!canTouch(ctx, server)) return 'That server is not yours.';
    const command = ctx.args.slice(1).join(' ');
    if (!command) return 'Usage: `!cmd <id|name> <command>`';
    const runtime = require('./runtime');
    if (!runtime.isOnline(server.id)) return `**${server.name}** is not running.`;
    runtime.sendCommand(server.id, command);
    db.log({ actor: (ctx.identity.user || {}).username || 'discord', action: 'server.command', serverId: server.id, serverName: server.name, detail: command.slice(0, 120) });
    return `Sent to **${server.name}**: \`${command}\``;
  },
});

define('op', {
  help: 'give a player operator',
  usage: '<id|name> <player>',
  async run(ctx) {
    return playerAction(ctx, 'op');
  },
});

define('deop', {
  help: 'remove a player’s operator status',
  usage: '<id|name> <player>',
  async run(ctx) { return playerAction(ctx, 'deop'); },
});

define('heal', {
  help: 'top up a player’s health',
  usage: '<id|name> <player>',
  async run(ctx) { return playerAction(ctx, 'heal'); },
});

define('feed', {
  help: 'fill a player’s hunger bar',
  usage: '<id|name> <player>',
  async run(ctx) { return playerAction(ctx, 'feed'); },
});

define('give', {
  help: 'hand a player items',
  usage: '<id|name> <player> <item> [count]',
  async run(ctx) {
    const server = findServer(ctx.args[0]);
    const player = ctx.args[1];
    const item = ctx.args[2];
    const count = parseInt(ctx.args[3] || '1', 10) || 1;
    if (!server) return 'Server not found.';
    if (!player || !item) return 'Usage: `!give <id|name> <player> <item> [count]`';
    if (!canTouch(ctx, server)) return 'That server is not yours.';
    try {
      const res = require('./players').apply(server, player, 'give', { item, count });
      return `${res.message}\n\`${res.command}\``;
    } catch (err) { return `Could not give items: ${err.message}`; }
  },
});

async function playerAction(ctx, action) {
  const server = findServer(ctx.args[0]);
  const player = ctx.args[1];
  if (!server) return 'Server not found.';
  if (!player) return `Usage: \`${ctx.prefix}${action} <id|name> <player>\``;
  if (!canTouch(ctx, server)) return 'That server is not yours.';
  try {
    const res = require('./players').apply(server, player, action);
    return `${res.message}\n\`${res.command}\``;
  } catch (err) { return `Could not run ${action}: ${err.message}`; }
}

/* --------------------------- server creation --------------------------- */
define('newserver', {
  help: 'create a server (bot asks for the username)',
  usage: '<name> [type] [version] [memory] [node]',
  async run(ctx) {
    const { args, msg } = ctx;
    if (!args.length) return 'Usage: `!newserver <name> [type] [version] [memory] [node]`';
    const c = conf();

    // Tolerant token picking so multi-word names work: `!newserver My Cool SMP
    // PAPER 1.21.4 1024` (tokens are recognised by shape, from the right).
    const versions = require('./versions');
    let rest = args.slice();
    const take = (test) => {
      for (let i = rest.length - 1; i >= 0; i -= 1) {
        if (test(rest[i])) return rest.splice(i, 1)[0];
      }
      return null;
    };
    const nodeArg = take((t) => (db.get('nodes') || []).some((n) => n.name.toLowerCase() === t.toLowerCase()));
    const memoryArg = take((t) => /^\d{3,5}$/.test(t));
    const versionArg = take((t) => /^(latest|\d+(\.\d+){1,2})$/.test(t));
    const typeArg = take((t) => versions.TYPES.some((x) => x.id === t.toUpperCase()));
    const name = rest.join(' ').trim() || args[0];
    if (!name) return 'Usage: `!newserver <name> [type] [version] [memory] [node]`';
    const type = (typeArg || c.defaultType).toUpperCase();
    const version = versionArg || c.defaultVersion;
    const memory = parseInt(memoryArg || String(c.defaultMemory), 10) || c.defaultMemory;

    // who should own it? admins can name a user, otherwise it is the caller
    let owner = ctx.identity.user;
    if (nodeArg && !ctx.identUserNamed) {
      const maybeUser = (db.get('users') || []).find((u) => u.username.toLowerCase() === nodeArg.toLowerCase());
      if (maybeUser && ctx.identity.admin) owner = maybeUser;
    }

    // interactive username prompt: the bot asks, then registers if needed
    if (!owner && c.allowRegistration) {
      const answer = await ask(ctx, 'Which panel username should own this server? Reply here within 2 minutes (or `cancel`).');
      if (!answer) return 'No answer - cancelled.';
      const username = answer.trim();
      if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) return 'That username is not valid (3-24 characters: letters, numbers, . _ -).';
      const existing = (db.get('users') || []).find((u) => u.username.toLowerCase() === username.toLowerCase());
      if (existing) return `A panel account **${username}** already exists - ask them to run \`!link\`, or an admin can create the server from the web panel.`;
      const password = Math.random().toString(36).slice(2, 8) + Math.random().toString(36).slice(2, 8).toUpperCase();
      owner = {
        id: uid('usr'), username, email: '', password: await auth.hashPassword(password),
        role: 'user', passwordVersion: 0, createdAt: new Date().toISOString(),
        suspended: false, createdBy: 'discord-bot', maxServers: 0,
        discordId: String(msg.author.id),
      };
      db.insert('users', owner);
      db.log({ actor: 'discord-bot', action: 'user.create', detail: `${username} (user, via Discord)` });
      await reply(msg, `Created the panel account **${username}** with password \`${password}\` - change it in Account → Profile after logging in to the panel.`);
      await reply(msg, `Registrations are open, so before that: keep this password safe, it will not be shown again.`);
    }
    if (!owner) return 'No panel user to own this server. Link your account with `!link <username> <password>` first.';

    // node selection
    const nodes = db.get('nodes') || [];
    const node = (nodeArg && nodes.find((n) => n.name.toLowerCase() === nodeArg.toLowerCase())) || nodes[0];
    if (!node) return 'No nodes configured.';

    const servers = require('./servers');
    try {
      const created = await servers.create({
        name, serverType: type, version, memory,
        maxPlayers: 20, eulaAccepted: true, nodeId: node.id, install: true,
      }, owner);
      await reply(msg, `Creating **${created.name}** (${type} ${version}, ${memory} MB) on node **${node.name}**, port **${created.port}** - installing now, progress shows in the panel console.`);
      // fire the installer without blocking the Discord interaction
      const versions = require('./versions');
      const runtime = require('./runtime');
      runtime.setStatus(created.id, 'installing');
      (async () => {
        try {
          if (runtime.isRemote(created)) await require('./remote').provision(created, { type, version });
          else await versions.install(created, { type, version, progress: (step, percent, line) => { runtime.setInstallProgress(created.id, { step, percent, note: line }); if (line) runtime.pushExternalLog(created.id, `[installer] ${line}`); } });
          runtime.setStatus(created.id, 'offline');
          await reply(msg, `**${created.name}** is installed. Start it with \`${ctx.prefix}start ${created.id}\`.`);
        } catch (err) {
          runtime.pushExternalLog(created.id, `[installer] FAILED: ${err.message}`);
          runtime.setStatus(created.id, 'offline', { lastError: err.message });
          await reply(msg, `Install failed for **${created.name}**: ${err.message}`);
        }
      })();
      return null; // already answered
    } catch (err) {
      return `Could not create the server: ${err.message}`;
    }
  },
});

function canTouch(ctx, server) {
  const user = ctx.identity.user;
  if (!user) return ctx.identity.admin;                       // guild owner / role holder
  return auth.canAccess(user, server);
}

/**
 * Ask the author a question and wait for their next message.
 * The gateway client wires `pendingQuestions` up when it connects; in tests it
 * is simply absent, which makes `ask()` return null immediately.
 */
const pending = new Map();
exports.pendingQuestions = pending;

async function ask(ctx, question) {
  if (!ctx.msg.channelId || typeof ctx.collectAnswer !== 'function') {
    note('ask(): no interactive transport, skipping question', 'debug');
    return null;
  }
  return ctx.collectAnswer(question);
}

/* ----------------------------- dispatcher ----------------------------- */
/**
 * Handle one inbound message. Returns the reply text (also sent to Discord when
 * a channel id is present) so tests can assert on it directly.
 */
async function handleMessage(msg) {
  const c = conf();
  if (!msg || !msg.content || !msg.author || msg.author.bot) return null;
  if (c.guildId && msg.guildId && String(msg.guildId) !== c.guildId) return null;
  if (!msg.content.startsWith(c.prefix)) return null;

  const [rawName, ...args] = msg.content.slice(c.prefix.length).trim().split(/\s+/);
  const name = (rawName || '').toLowerCase();
  const command = commands.get(name);
  state.lastMessageAt = new Date().toISOString();

  const identity = msg.identity || identityOf(msg);
  if (!command) {
    if (!name) return null;
    const replyText = `Unknown command \`${c.prefix}${name}\`. Try \`${c.prefix}help\`.`;
    await reply(msg, replyText);
    return replyText;
  }

  const ctx = {
    msg, args, prefix: c.prefix, identity,
    collectAnswer: msg.collectAnswer,
    panelUsername: msg.panelUsername,
    identUserNamed: Boolean(msg.panelUsername),
  };

  try {
    if (command.adminOnly && !identity.admin) {
      const denial = `\`${c.prefix}${command.name}\` needs an admin/owner account (${identity.reason}).`;
      await reply(msg, denial);
      return denial;
    }
    const out = await command.run(ctx);
    state.commandsHandled += 1;
    note(`${c.prefix}${name} by ${msg.author.username || msg.author.id}`);
    if (out) await reply(msg, out);
    return out;
  } catch (err) {
    logger.warn('discord', `command ${name} failed: ${err.message}`);
    note(`command ${name} failed: ${err.message}`, 'error');
    const failure = `Something went wrong: ${err.message}`;
    await reply(msg, failure);
    return failure;
  }
}
exports.handleMessage = handleMessage;

function identityOf(msg) {
  const c = conf();
  const user = panelUserFor(msg.author.id, msg.panelUsername);
  const isGuildOwner = msg.guildOwnerId && String(msg.guildOwnerId) === String(msg.author.id);
  const hasRole = c.adminRole && (msg.roles || []).map((r) => String(r).toLowerCase()).includes(c.adminRole);
  return {
    user,
    admin: Boolean((user && auth.isAdmin(user)) || isGuildOwner || hasRole),
    reason: user ? 'linked panel account' : isGuildOwner ? 'Discord server owner' : hasRole ? `role ${c.adminRole}` : 'no linked panel account',
  };
}

/* ------------------------------- gateway ------------------------------- */
let ws = null;
let heartbeatTimer = null;
let reconnectTimer = null;
let shouldRun = false;

function gatewaySend(payload) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(payload));
}

async function connect() {
  const c = conf();
  if (!c.token) throw new Error('No bot token configured');
  const WebSocket = require('ws');
  state.status = 'connecting';
  note('connecting to the Discord gateway');
  const info = await exports.transport.gatewayUrl();
  state.heartbeatMs = (info.heartbeat_interval || 41250) * 0.9;
  const url = `${info.url || 'wss://gateway.discord.gg'}/?v=10&encoding=json`;
  ws = new WebSocket(url);
  state.ws = ws;

  ws.on('open', () => note('gateway socket open'));
  ws.on('message', (raw) => {
    let pkt;
    try { pkt = JSON.parse(raw.toString()); } catch (_) { return; }
    onGatewayPacket(pkt, c);
  });
  ws.on('error', (err) => {
    state.status = 'error';
    state.lastError = err.message;
    note(`gateway error: ${err.message}`, 'error');
  });
  ws.on('close', (code) => {
    note(`gateway closed (${code})`, code === 1000 ? 'info' : 'error');
    clearInterval(heartbeatTimer);
    if (shouldRun) {
      reconnectTimer = setTimeout(() => connect().catch((err) => {
        state.status = 'error';
        state.lastError = err.message;
        note(`reconnect failed: ${err.message}`, 'error');
      }), 8000);
    } else if (state.status !== 'error') {
      state.status = 'stopped';
    }
  });
}

function onGatewayPacket(pkt, c) {
  if (pkt.s !== null && pkt.s !== undefined) state.sequence = pkt.s;
  switch (pkt.op) {
    case 10: { // HELLO
      clearInterval(heartbeatTimer);
      heartbeatTimer = setInterval(() => gatewaySend({ op: 1, d: state.sequence }), state.heartbeatMs);
      heartbeatTimer.unref?.();
      const payload = {
        op: 2,
        d: {
          token: c.token,
          intents: 1 | 512 | 32768, // GUILDS | GUILD_MESSAGES | MESSAGE_CONTENT
          properties: { os: process.platform, browser: 'zenith-panel', device: 'zenith-panel' },
          presence: { status: 'online', activities: [{ name: 'your Minecraft servers', type: 3 }] },
        },
      };
      gatewaySend(payload);
      note('sent IDENTIFY');
      break;
    }
    case 11: break;             // HEARTBEAT_ACK
    case 7:                     // RECONNECT
      ws.close();
      break;
    case 0: {                   // DISPATCH
      if (pkt.t === 'READY') {
        state.status = 'online';
        state.user = pkt.d.user ? { id: pkt.d.user.id, username: pkt.d.user.username, discriminator: pkt.d.user.discriminator } : null;
        state.sessionId = pkt.d.session_id;
        state.resumeGatewayUrl = pkt.d.resume_gateway_url;
        state.startedAt = new Date().toISOString();
        state.lastError = null;
        note(`online as ${state.user ? state.user.username : '?'} (session ${String(state.sessionId).slice(0, 8)}…)`);
        db.log({ actor: 'system', action: 'discord.online', detail: state.user ? state.user.username : '' });
      }
      if (pkt.t === 'GUILD_CREATE') {
        const g = pkt.d;
        state.guilds = [...new Set([...(state.guilds || []).map((x) => x.id), g.id])].map((id) => {
          const known = state.guilds.find((x) => x.id === id);
          if (known && known.id === g.id) return { id, name: g.name, memberCount: g.member_count };
          return known || { id, name: id === g.id ? g.name : id };
        });
        if (!c.guildId) note(`guild available: ${g.name} (${g.id}) - set it in Admin → Discord to lock the bot down`, 'warn');
      }
      if (pkt.t === 'MESSAGE_CREATE') handleDispatchMessage(pkt.d, c).catch((err) => note(err.message, 'error'));
      break;
    }
    default: break;
  }
}

/** Enrich a raw MESSAGE_CREATE with guild/role/owner info, then hand it to the dispatcher. */
async function handleDispatchMessage(d, c) {
  if (!d || !d.content || !d.author || d.author.bot) return;
  const msg = {
    content: d.content,
    channelId: d.channel_id,
    guildId: d.guild_id,
    author: { id: d.author.id, username: d.author.username, bot: d.author.bot },
    roles: [],
    guildOwnerId: null,
  };
  try {
    const member = await exports.transport.fetchGuildMember(d.guild_id, d.author.id);
    msg.roles = member.roles || [];
    msg.guildOwnerId = member.guild_owner_id || null;
  } catch (err) {
    note(`could not fetch member ${d.author.id}: ${err.message}`, 'warn');
  }
  // interactive username prompt support
  msg.collectAnswer = (question) => collectAnswer(msg, question, c);
  await handleMessage(msg);
}
// Exported so the whole message pipeline (member lookup, interactive prompts,
// prefix + permission checks) can be exercised without a Discord connection.
exports.handleDispatch = handleDispatchMessage;

/** Simple one-shot question/answer. */
const waitingFor = new Map(); // `${channelId}:${userId}` -> resolve
async function collectAnswer(msg, question, c) {
  const key = `${msg.channelId}:${msg.author.id}`;
  await reply(msg, question);
  return new Promise((resolve) => {
    const timer = setTimeout(() => { waitingFor.delete(key); resolve(null); }, 120000);
    waitingFor.set(key, (answer) => { clearTimeout(timer); waitingFor.delete(key); resolve(answer); });
    void c;
  });
}
exports.resolveAnswer = (channelId, userId, answer) => {
  const key = `${channelId}:${userId}`;
  const resolver = waitingFor.get(key);
  if (!resolver) return false;
  resolver(answer);
  return true;
};

/* ------------------------------ lifecycle ------------------------------ */
async function start() {
  const c = conf();
  if (!c.token) throw new Error('Set the Discord bot token first (Admin → Settings → Discord)');
  shouldRun = true;
  clearTimeout(reconnectTimer);
  await connect();
  return status();
}
exports.start = start;

async function stop() {
  shouldRun = false;
  clearTimeout(reconnectTimer);
  clearInterval(heartbeatTimer);
  if (ws) { try { ws.close(1000); } catch (_) {} }
  ws = null;
  state.status = 'stopped';
  state.user = null;
  note('bot stopped by the panel');
  return status();
}
exports.stop = stop;

async function restart() {
  await stop();
  await start();
  return status();
}
exports.restart = restart;

function status() {
  const c = conf();
  return {
    status: state.status,
    running: state.status === 'online' || state.status === 'connecting',
    user: state.user,
    guilds: state.guilds,
    guildId: c.guildId || null,
    prefix: c.prefix,
    adminRole: c.adminRole || null,
    commands: [...commands.keys()].length,
    commandsHandled: state.commandsHandled,
    startedAt: state.startedAt,
    lastError: state.lastError,
    lastMessageAt: state.lastMessageAt,
    tokenSet: Boolean(c.token),
    enabled: c.enabled,
    allowRegistration: c.allowRegistration,
    log: history.slice(-40).reverse(),
  };
}
exports.status = status;

/* -------------------------- notifications -------------------------- */
/**
 * Send a panel notification (server online/offline/crashed, backup ready, ...)
 * to the configured notification channel. Never throws: notifications must not
 * break the action that triggered them.
 */
async function notify(event, server = {}, extra = {}) {
  const c = conf();
  if (!c.enabled || state.status !== 'online') return false;
  const channelId = extra.channelId || c.notifyChannelId || c.channelId;
  if (!channelId) return false;
  const colours = { started: 0x3ddc84, online: 0x3ddc84, stopped: 0x8892a0, crashed: 0xff5d5d, error: 0xff5d5d, backup: 0x5aa9ff, player: 0xa78bfa, info: 0x5aa9ff };
  const titles = {
    started: 'Server online', online: 'Server online', stopped: 'Server stopped',
    crashed: 'Server crashed', error: 'Server error', backup: 'Backup finished',
    player: 'Player event', created: 'Server created', info: 'Zenith Panel',
  };
  const lines = [];
  if (server.name) lines.push(`**${server.name}**${server.id ? ` \`${server.id}\`` : ''}`);
  if (extra.line) lines.push(String(extra.line).slice(0, 300));
  if (server.port) lines.push(`Address: \`${extra.host || server.ip || 'your server ip'}:${server.port}\``);
  const payload = {
    embeds: [{
      title: titles[event] || 'Zenith Panel',
      description: lines.join('\n') || String(extra.text || '').slice(0, 300),
      color: colours[event] || 0x5aa9ff,
      footer: { text: 'Zenith Panel' },
      timestamp: new Date().toISOString(),
    }],
  };
  try {
    await exports.transport.sendMessage(channelId, payload);
    return true;
  } catch (err) {
    note(`notification failed: ${err.message}`, 'warn');
    return false;
  }
}
exports.notify = notify;

/** Called at boot when the bot is enabled in settings. */
function autostart() {
  const c = conf();
  if (c.enabled && c.token) {
    start().catch((err) => { state.status = 'error'; state.lastError = err.message; note(`autostart failed: ${err.message}`, 'error'); });
  }
}
exports.autostart = autostart;

void cfg;
