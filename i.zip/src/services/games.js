'use strict';
/**
 * Curated dedicated-game catalogue and real SteamCMD installer.
 *
 * Each entry is an audited dedicated-server application, not an arbitrary
 * Steam app supplied by the browser. Linux-native entries are installed into
 * the server's persistent /data directory with Valve's SteamCMD, then run in
 * a real Docker container with the panel's CPU/RAM limits and port mappings.
 *
 * A few publishers still ship a Windows-only dedicated binary. Those entries
 * remain visible to make the platform requirement explicit, but this Linux
 * panel will refuse to provision them rather than pretending Wine/Proton is a
 * supported server runtime.
 */
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const cfg = require('../config');
const docker = require('./docker');

const STEAMCMD_IMAGE = 'cm2network/steamcmd:latest';
exports.STEAMCMD_IMAGE = STEAMCMD_IMAGE;

const linux = 'linux';
const windows = 'windows';

// `ports` reserves every externally-reachable game/query port so a later panel
// workload cannot silently take an adjacent port this game needs.
const GAMES = Object.freeze([
  { id: 'rust', name: 'Rust', appId: 258550, platform: linux, category: 'Survival', memory: 6144, disk: 35000, players: 50, ports: [{ name: 'Game', offset: 0 }, { name: 'RCON', offset: 1 }], note: 'Rust Dedicated Server; RCON is bound but disabled until you configure it.' },
  { id: 'ark-se', name: 'ARK: Survival Evolved', appId: 376030, platform: linux, category: 'Survival', memory: 12288, disk: 100000, players: 70, ports: [{ name: 'Game', offset: 0 }, { name: 'Query', offset: 1 }], note: 'The Linux dedicated build is large; allow substantial disk space and first-install time.' },
  { id: 'palworld', name: 'Palworld', appId: 2394010, platform: linux, category: 'Survival', memory: 8192, disk: 20000, players: 32, ports: [{ name: 'Game', offset: 0 }], note: 'Uses the official Palworld dedicated server app.' },
  { id: 'valheim', name: 'Valheim', appId: 896660, platform: linux, category: 'Survival', memory: 4096, disk: 5000, players: 10, ports: [{ name: 'Game', offset: 0 }, { name: 'Game + 1', offset: 1 }], password: true, note: 'A Valheim server password of at least five characters is required.' },
  { id: 'terraria', name: 'Terraria', appId: 105600, platform: linux, category: 'Sandbox', memory: 2048, disk: 3000, players: 16, ports: [{ name: 'Game', offset: 0 }], steamLogin: true, note: 'SteamCMD account credentials are required by the publisher for this dedicated build.' },
  { id: 'cs2', name: 'Counter-Strike 2', appId: 730, platform: linux, category: 'Shooter', memory: 4096, disk: 40000, players: 16, ports: [{ name: 'Game', offset: 0 }], token: true, note: 'A Game Server Login Token is optional for private LAN testing but required for public listing.' },
  { id: 'gmod', name: "Garry's Mod", appId: 4020, platform: linux, category: 'Sandbox', memory: 4096, disk: 15000, players: 24, ports: [{ name: 'Game', offset: 0 }], note: 'Installs the dedicated Source engine server. Workshop content is managed through its game configuration.' },
  { id: 'tf2', name: 'Team Fortress 2', appId: 232250, platform: linux, category: 'Shooter', memory: 3072, disk: 20000, players: 24, ports: [{ name: 'Game', offset: 0 }], token: true, note: 'A Game Server Login Token is recommended for public server listing.' },
  { id: 'seven-days', name: '7 Days to Die', appId: 294420, platform: linux, category: 'Survival', memory: 6144, disk: 20000, players: 16, ports: [{ name: 'Game', offset: 0 }], note: 'Creates a real serverconfig.xml with the allocated game port.' },
  { id: 'project-zomboid', name: 'Project Zomboid', appId: 380870, platform: linux, category: 'Survival', memory: 4096, disk: 10000, players: 16, ports: [{ name: 'Game', offset: 0 }, { name: 'Player', offset: 1 }], note: 'Creates the initial dedicated-server profile in the persistent game directory.' },
  { id: 'dayz', name: 'DayZ', appId: 223350, platform: windows, category: 'Survival', memory: 6144, disk: 30000, players: 60, ports: [{ name: 'Game', offset: 0 }], steamLogin: true, note: 'The official dedicated binary is Windows-only. Assign this title to a Windows game node; Linux Docker provisioning is intentionally blocked.' },
  { id: 'unturned', name: 'Unturned', appId: 1110390, platform: linux, category: 'Survival', memory: 4096, disk: 10000, players: 24, ports: [{ name: 'Game', offset: 0 }, { name: 'Query', offset: 1 }], token: true, note: 'Uses the official Unturned dedicated-server app.' },
  { id: 'v-rising', name: 'V Rising', appId: 1829350, platform: linux, category: 'Survival', memory: 6144, disk: 10000, players: 40, ports: [{ name: 'Game', offset: 0 }, { name: 'Query', offset: 1 }], note: 'Creates persistent V Rising server settings under /data.' },
  { id: 'conan-exiles', name: 'Conan Exiles', appId: 443030, platform: windows, category: 'Survival', memory: 8192, disk: 80000, players: 40, ports: [{ name: 'Game', offset: 0 }, { name: 'Query', offset: 1 }], note: 'The official dedicated binary is Windows-only. Assign this title to a Windows game node; Linux Docker provisioning is intentionally blocked.' },
  { id: 'satisfactory', name: 'Satisfactory', appId: 1690800, platform: linux, category: 'Building', memory: 8192, disk: 30000, players: 16, ports: [{ name: 'Game', offset: 0 }, { name: 'Beacon', offset: 1 }, { name: 'Query', offset: 2 }], note: 'Uses the official Satisfactory dedicated server application.' },
  { id: 'factorio', name: 'Factorio', appId: 427520, platform: linux, category: 'Building', memory: 2048, disk: 5000, players: 16, ports: [{ name: 'Game', offset: 0 }], note: 'Creates an initial map only when one does not already exist in /data.' },
  { id: 'dont-starve-together', name: "Don't Starve Together", appId: 343050, platform: linux, category: 'Survival', memory: 2048, disk: 5000, players: 6, ports: [{ name: 'Master shard', offset: 0 }, { name: 'Caves shard', offset: 1 }], token: true, note: 'A Klei cluster token is required to start a real dedicated cluster.' },
  { id: 'space-engineers', name: 'Space Engineers', appId: 298740, platform: windows, category: 'Sandbox', memory: 10240, disk: 30000, players: 16, ports: [{ name: 'Game', offset: 0 }], note: 'The official dedicated binary is Windows-only. Assign this title to a Windows game node; Linux Docker provisioning is intentionally blocked.' },
  { id: 'starbound', name: 'Starbound', appId: 211820, platform: linux, category: 'Sandbox', memory: 2048, disk: 10000, players: 8, ports: [{ name: 'Game', offset: 0 }], steamLogin: true, note: 'SteamCMD account credentials are required by the publisher for this dedicated build.' },
  { id: 'squad', name: 'Squad', appId: 403240, platform: linux, category: 'Shooter', memory: 8192, disk: 50000, players: 100, ports: [{ name: 'Game', offset: 0 }, { name: 'Query', offset: 1 }, { name: 'RCON', offset: 2 }], note: 'Uses the official Squad Dedicated Server app.' },
]);
exports.GAMES = GAMES;

function game(id) { return GAMES.find((item) => item.id === String(id || '').toLowerCase()) || null; }
exports.game = game;
function isGame(server) { return Boolean(server && server.workloadType === 'game'); }
exports.isGame = isGame;

function publicGame(item) {
  if (!item || !item.id) return null;
  return {
    id: item.id, name: item.name, appId: item.appId, category: item.category,
    platform: item.platform, availableOnLocalNode: item.platform === linux,
    defaultMemory: item.memory, defaultDisk: item.disk, defaultPlayers: item.players,
    ports: (item.ports || []).map((port) => ({ ...port })), password: !!item.password,
    token: !!item.token, steamLogin: !!item.steamLogin, note: item.note,
  };
}
exports.catalogue = () => GAMES.map(publicGame);
exports.publicGame = publicGame;

function containerUser() { return String(process.env.DOCKER_GAME_UID || '').trim(); }
exports.containerUser = containerUser;

function shell(value) { return `'${String(value ?? '').replace(/'/g, "'\\''")}'`; }
function slug(value) { return String(value || 'zenith').toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 36) || 'zenith'; }
function xml(value) { return String(value ?? '').replace(/[<>&"']/g, (ch) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[ch])); }
function port(server, index = 0) { return Number((server.portAllocations || [server.port])[index] || server.port); }

function assertGameRuntime(server) {
  const item = game(server.gameId);
  if (!item) throw new Error(`Unknown game template "${server.gameId || ''}"`);
  if (item.platform !== linux) throw new Error(`${item.name} uses an official Windows-only dedicated binary. This Linux Docker node cannot provision it; assign it to a Windows game node instead.`);
  return item;
}
exports.assertGameRuntime = assertGameRuntime;

function steamLoginArgs(item) {
  if (!item.steamLogin) return ['+login', 'anonymous'];
  if (!process.env.STEAMCMD_USER || !process.env.STEAMCMD_PASSWORD) {
    throw new Error(`${item.name} requires SteamCMD account credentials. Set STEAMCMD_USER and STEAMCMD_PASSWORD in the trusted panel service environment, then restart the panel. The credentials are never stored in a server record.`);
  }
  // The values are delivered only to this short-lived --rm installer through
  // Docker's environment forwarding, so they are not added to DB records or
  // command logs. The image entrypoint expands them inside the ephemeral job.
  return null;
}

/** Install/update the exact audited Steam app into the workload's persistent dir. */
async function install(server, { progress = () => {}, log = () => {} } = {}) {
  const item = assertGameRuntime(server);
  const dir = path.join(cfg.serverDataDir, server.id);
  await fsp.mkdir(dir, { recursive: true });
  await writeBootstrap(server, item);
  progress('image', 8, `Pulling SteamCMD image for ${item.name}…`);
  await docker.ensureImage(STEAMCMD_IMAGE, { onLine: log });
  const login = steamLoginArgs(item);
  const command = login
    ? ['+force_install_dir', '/data', ...login, '+app_update', String(item.appId), 'validate', '+quit']
    : ['-lc', `exec /home/steam/steamcmd/steamcmd.sh +force_install_dir /data +login "$STEAMCMD_USER" "$STEAMCMD_PASSWORD" +app_update ${item.appId} validate +quit`];
  progress('steamcmd', 20, `Installing ${item.name} from SteamCMD app ${item.appId}…`);
  const result = await docker.runGameInstall({
    image: STEAMCMD_IMAGE, dir, command, user: containerUser(), env: { HOME: '/data' },
    envForward: login ? [] : ['STEAMCMD_USER', 'STEAMCMD_PASSWORD'], shellEntrypoint: !login,
    onLine: (line) => log(`[steamcmd] ${line}`),
  });
  if (result.code !== 0) {
    const detail = String(result.stderr || result.stdout || 'SteamCMD exited without an error message').trim().split('\n').slice(-8).join('\n');
    throw new Error(`SteamCMD could not install ${item.name} (app ${item.appId}): ${detail}`);
  }
  progress('prepare', 84, `Writing ${item.name} launch configuration…`);
  await writeBootstrap(server, item);
  await fsp.writeFile(path.join(dir, '.zenith-game-install.json'), JSON.stringify({
    game: item.id, name: item.name, appId: item.appId, installedAt: new Date().toISOString(),
  }, null, 2));
  progress('done', 100, `${item.name} installation complete`);
  return { game: item, dir, appId: item.appId };
}
exports.install = install;

/** A game container expects a launch script generated from server-owned values.
 * It is intentionally recreated on install/start so a port/limit edit never
 * leaves a stale shell command behind. */
async function writeBootstrap(server, item = assertGameRuntime(server)) {
  const dir = path.join(cfg.serverDataDir, server.id);
  await fsp.mkdir(dir, { recursive: true });
  const p0 = port(server, 0); const p1 = port(server, 1); const p2 = port(server, 2);
  const password = String((server.gameSecrets || {}).password || '');
  const token = String((server.gameSecrets || {}).token || '');
  const title = server.name || item.name;
  const saveName = slug(server.id);
  let launch = '';

  if (item.id === 'rust') launch = `exec ./RustDedicated -batchmode +server.port ${p0} +server.level "Procedural Map" +server.seed 12345 +server.worldsize 3000 +server.maxplayers ${server.maxPlayers || item.players} +server.hostname ${shell(title)}`;
  else if (item.id === 'ark-se') launch = `exec ./ShooterGame/Binaries/Linux/ShooterGameServer ${shell(`TheIsland?listen?SessionName=${title}?Port=${p0}?QueryPort=${p1}`)} -server -log`;
  else if (item.id === 'palworld') launch = `exec ./PalServer.sh -port=${p0} -players=${server.maxPlayers || item.players} -servername=${shell(title)}`;
  else if (item.id === 'valheim') launch = `exec ./valheim_server.x86_64 -name ${shell(title)} -port ${p0} -world ${shell(saveName)} -password ${shell(password)} -public 0`;
  else if (item.id === 'terraria') launch = 'exec ./TerrariaServer.bin.x86_64 -config /data/zenith-terraria.txt';
  else if (item.id === 'cs2') launch = `exec ./game/bin/linuxsteamrt64/cs2 -dedicated -usercon -port ${p0} +map de_dust2${token ? ` +sv_setsteamaccount ${shell(token)}` : ''}`;
  else if (item.id === 'gmod') launch = `exec ./srcds_run -game garrysmod +maxplayers ${server.maxPlayers || item.players} +map gm_flatgrass -port ${p0}`;
  else if (item.id === 'tf2') launch = `exec ./srcds_run -game tf +map ctf_2fort +maxplayers ${server.maxPlayers || item.players} -port ${p0}${token ? ` +sv_setsteamaccount ${shell(token)}` : ''}`;
  else if (item.id === 'seven-days') launch = 'exec ./7DaysToDieServer.x86_64 -configfile=/data/serverconfig.xml';
  else if (item.id === 'project-zomboid') launch = `exec ./start-server.sh -servername ${shell(saveName)}`;
  else if (item.id === 'unturned') launch = `exec ./ServerHelper.sh +InternetServer/${saveName}`;
  else if (item.id === 'v-rising') launch = 'exec ./VRisingServer -persistentDataPath /data/vrising';
  else if (item.id === 'satisfactory') launch = `exec ./FactoryServer.sh -Port=${p0}`;
  else if (item.id === 'factorio') launch = `mkdir -p /data/saves; if [ ! -f /data/saves/zenith.zip ]; then ./bin/x64/factorio --create /data/saves/zenith.zip; fi; exec ./bin/x64/factorio --start-server /data/saves/zenith.zip --port ${p0}`;
  else if (item.id === 'dont-starve-together') launch = 'exec ./bin/dontstarve_dedicated_server_nullrenderer -console -cluster Cluster_1 -shard Master';
  else if (item.id === 'starbound') launch = 'exec ./linux/starbound_server';
  else if (item.id === 'squad') launch = `exec ./SquadGameServer.sh PORT=${p0} QUERYPORT=${p1} RCONPORT=${p2}`;
  else throw new Error(`No Linux launch profile is available for ${item.name}`);

  const script = `#!/usr/bin/env bash\nset -euo pipefail\ncd /data\nexport HOME=/data\nexport TZ=${shell(process.env.TZ || 'UTC')}\n${launch}\n`;
  const launcher = path.join(dir, '.zenith-game-start.sh');
  // This is a tenant runtime file, not a panel secret. The SteamCMD image's
  // unprivileged `steam` user must be able to read it even when the panel and
  // game image use different host UIDs. The launch path below invokes Bash as
  // an interpreter too, so hosts that mount the data volume with `noexec` do
  // not turn an otherwise valid script into a permission-denied crash.
  await fsp.writeFile(launcher, script, { mode: 0o755 });
  await fsp.chmod(launcher, 0o755);

  // Initial config files are real game-native formats. Existing editable
  // configs are left in place on reinstall to avoid overwriting player changes.
  if (item.id === 'terraria') await writeIfAbsent(path.join(dir, 'zenith-terraria.txt'), `world=/data/world.wld\nworldname=${title}\nport=${p0}\nmaxplayers=${server.maxPlayers || item.players}\npassword=${password}\n`);
  if (item.id === 'seven-days') await writeIfAbsent(path.join(dir, 'serverconfig.xml'), `<?xml version="1.0"?><ServerSettings><property name="ServerName" value="${xml(title)}"/><property name="ServerPort" value="${p0}"/><property name="ServerMaxPlayerCount" value="${server.maxPlayers || item.players}"/></ServerSettings>\n`);
  if (item.id === 'project-zomboid') await writeIfAbsent(path.join(dir, 'Zomboid', 'Server', `${saveName}.ini`), `PublicName=${title}\nDefaultPort=${p0}\nMaxPlayers=${server.maxPlayers || item.players}\n`);
  if (item.id === 'unturned') await writeIfAbsent(path.join(dir, 'Servers', saveName, 'Server', 'Commands.dat'), `Name ${title}\nPort ${p0}\nMaxPlayers ${server.maxPlayers || item.players}\n`);
  if (item.id === 'v-rising') await writeIfAbsent(path.join(dir, 'vrising', 'Settings', 'ServerHostSettings.json'), JSON.stringify({ Name: title, Description: server.description || '', Port: p0, QueryPort: p1, MaxConnectedUsers: server.maxPlayers || item.players }, null, 2));
  if (item.id === 'dont-starve-together') {
    await writeIfAbsent(path.join(dir, 'DoNotStarveTogether', 'Cluster_1', 'cluster.ini'), `[GAMEPLAY]\nmax_players = ${server.maxPlayers || item.players}\n\n[NETWORK]\ncluster_name = ${title}\ncluster_intention = cooperative\ncluster_password = ${password}\n\n[MISC]\nconsole_enabled = true\n`);
    if (token) await fsp.writeFile(path.join(dir, 'DoNotStarveTogether', 'Cluster_1', 'cluster_token.txt'), `${token}\n`);
  }
}
exports.writeBootstrap = writeBootstrap;

async function writeIfAbsent(file, content) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  try { await fsp.access(file); } catch { await fsp.writeFile(file, content); }
}

function validateSecrets(item, body) {
  const password = String(body.gamePassword || '').trim();
  const token = String(body.gameToken || '').trim();
  if (item.password && password.length < 5) throw new Error(`${item.name} requires a server password with at least five characters`);
  if (item.id === 'dont-starve-together' && !token) throw new Error("Don't Starve Together requires a Klei cluster token before it can be created");
  if (password.length > 256 || token.length > 1024) throw new Error('Game password or token is too long');
  return { password, token };
}
exports.validateSecrets = validateSecrets;

function newRconPassword() { return crypto.randomBytes(24).toString('base64url'); }
exports.newRconPassword = newRconPassword;
