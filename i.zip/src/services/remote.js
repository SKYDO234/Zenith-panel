'use strict';
/**
 * Remote node execution.
 *
 * A server whose `nodeId` is not `local` runs on a second machine that is
 * driven through the small HTTP API exposed by `scripts/node-agent.js`
 * (provision / start / stop / kill / command / logs / status).
 *
 * The panel stays the single source of truth for *state*: this module mirrors
 * the remote process into the local runtime (console ring buffer, status
 * events, websocket fan-out) so the UI, schedules, backups and the API behave
 * exactly as they do for a local server.
 */
const db = require('../db');
const cfg = require('../config');
const logger = require('../logger');
const { formatBytes } = require('../utils');

/** runtime.js is required lazily: it requires this module back. */
function rt() { return require('./runtime'); }

function nodeFor(server) {
  return db.find('nodes', (n) => n.id === server.nodeId) || null;
}

function isRemote(server) {
  return Boolean(server && server.nodeId && server.nodeId !== 'local');
}

/**
 * Ask the agent which container runtime it really has (docker available? which
 * engine?). Used to validate a runtime change before it is saved.
 * @returns {Promise<{available:boolean, engine:string|null, error:string|null}>}
 */
async function containerRuntime(server) {
  const node = nodeFor(server);
  if (!node) return { available: false, engine: null, error: 'the node no longer exists' };
  try {
    const status = await request(node, 'GET', '/api/node/status', null, { timeout: 8000 });
    const cr = status.containerRuntime || {};
    return { available: Boolean(cr.available), engine: cr.engine || null, error: cr.error || null, node: node.name };
  } catch (err) {
    return { available: false, engine: null, error: `the node did not answer: ${err.message}` };
  }
}

function baseUrl(node) {
  const scheme = node.scheme || 'http';
  const host = node.fqdn || node.host || '127.0.0.1';
  const port = Number(node.port) || 8443;
  return `${scheme}://${host}:${port}`;
}

/** One request to a node agent, with a hard timeout and JSON errors. */
async function request(node, method, path, body, { timeout = 30000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(`${baseUrl(node)}${path}`, {
      method,
      headers: { 'x-node-token': node.token || '', 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await res.text();
    let parsed = null;
    try { parsed = text ? JSON.parse(text) : null; } catch (_) { /* non-JSON */ }
    if (!res.ok) {
      const message = (parsed && parsed.error) || `node "${node.name}" answered HTTP ${res.status}`;
      throw new Error(message);
    }
    return parsed || {};
  } catch (err) {
    if (err.name === 'AbortError') throw new Error(`node "${node.name}" timed out after ${timeout / 1000}s`);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Raw request with a custom body (binary streams) and custom headers - used to
 * push a backup archive to a node for restore.
 */
async function raw(node, method, path, body, headers = {}, { timeout = 60000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(`${baseUrl(node)}${path}`, {
      method,
      headers: { 'x-node-token': node.token || '', ...headers },
      body,
      duplex: 'half',
      signal: controller.signal,
    });
    const text = await res.text();
    let parsed = null;
    try { parsed = text ? JSON.parse(text) : null; } catch (_) { /* not json */ }
    if (!res.ok) throw new Error((parsed && parsed.error) || `node "${node.name}" answered HTTP ${res.status}`);
    return parsed || {};
  } catch (err) {
    if (err.name === 'AbortError') throw new Error(`node "${node.name}" timed out`);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
exports.raw = raw;

function mustNode(server) {
  const node = nodeFor(server);
  if (!node) throw new Error(`This server is assigned to a node that no longer exists (${server.nodeId})`);
  if (!node.token) throw new Error(`Node "${node.name}" has no token - recreate it`);
  return node;
}

async function ping(node) {
  const started = Date.now();
  const stats = await request(node, 'GET', '/api/node/status', undefined, { timeout: 6000 });
  return { stats, latencyMs: Date.now() - started };
}

/** Ask the node for a free port inside its allocation range. */
async function freePort(node, portRange) {
  const range = portRange || node.portRange || { start: 25565, end: 25665 };
  try {
    const res = await request(node, 'GET', `/api/node/ports?start=${range.start}&end=${range.end}`, undefined, { timeout: 10000 });
    if (res.port) return res.port;
  } catch (err) {
    logger.warn('remote', `could not ask ${node.name} for a port: ${err.message}`);
  }
  return null;
}

/** Install (or reinstall) the server software on the remote box. */
async function provision(server, { type, version } = {}) {
  const runtime = rt();
  const versions = require('./versions');
  const node = mustNode(server);
  const kind = String(type || server.serverType).toUpperCase();
  const ver = version || server.version;

  runtime.setStatus(server.id, 'installing');
  const log = (msg) => runtime.pushExternalLog(server.id, `[installer] ${msg}`);
  log(`Installing ${kind} ${ver} on node "${node.name}" (${baseUrl(node)}) ...`);

  let download;
  if (kind === 'CUSTOM') {
    log('Custom jar - upload it to the node yourself, or switch to a managed software.');
    runtime.setStatus(server.id, 'offline');
    return { custom: true, remote: true };
  }
  download = await versions.resolveDownload(kind, ver);
  log(`${download.filename}${download.build ? ` (build ${download.build})` : ''} -> ${baseUrl(node)}`);

  const payload = {
    serverType: kind,
    version: ver,
    jar: 'server.jar',
    jarUrl: download.url,
    jarName: download.filename,
    installer: Boolean(download.installer),
    memory: server.memory,
    port: server.port,
    ip: server.ip || '0.0.0.0',
    maxPlayers: server.maxPlayers,
    onlineMode: server.onlineMode !== false,
    motd: server.name,
    eula: Boolean(server.eulaAccepted),
    javaMajor: server.javaVersion || versions.javaFor(ver),
    aikarFlags: server.aikarFlags !== false,
  };

  const result = await request(node, 'POST', `/api/node/servers/${server.id}/provision`, payload, { timeout: 30 * 60e3 });
  for (const note of result.notes || []) log(note);

  db.update('servers', server.id, {
    serverType: kind,
    version: ver,
    build: download.build || null,
    javaVersion: versions.javaFor(ver),
    lastInstalledAt: new Date().toISOString(),
    remoteJava: result.java || null,
    remoteJar: result.jar || 'server.jar',
    status: 'offline',
  });
  runtime.setStatus(server.id, 'offline');
  log(`Done on ${node.name}. Start the server to load it.`);
  db.log({ actor: 'panel', action: 'server.install', serverId: server.id, serverName: server.name, detail: `${kind} ${ver} @ ${node.name}` });
  return { remote: true, node: node.name, jar: result.jar, java: result.java };
}

/* ----------------------------- log mirroring ----------------------------- */
const watchers = new Map(); // serverId -> { timer, node, seq, misses }

function watch(server) {
  if (watchers.has(server.id)) return;
  const node = nodeFor(server);
  if (!node) return;
  const runtime = rt();
  const entry = { node, seq: 0, misses: 0, serverId: server.id };
  watchers.set(server.id, entry);

  entry.tick = async () => {
    const state = runtime.state(server.id);
    try {
      const logs = await request(node, 'GET', `/api/node/servers/${server.id}/logs?since=${entry.seq}`, undefined, { timeout: 12000 });
      if (typeof logs.seq === 'number' && logs.seq > entry.seq) {
        for (const line of logs.lines || []) runtime.pushExternalLog(server.id, line);
        entry.seq = logs.seq;
      }
      const status = await request(node, 'GET', `/api/node/servers/${server.id}/status`, undefined, { timeout: 12000 });
      entry.misses = 0;
      if (status.running) {
        state.remotePid = status.pid;
        state.startedAt = status.startedAt ? Date.parse(status.startedAt) : state.startedAt || Date.now();
        state.remoteStats = {
          cpu: 0,
          memory: status.rss && status.memoryLimit ? Math.min(100, Number(((status.rss / (status.memoryLimit * 1048576)) * 100).toFixed(1))) : 0,
          memoryBytes: status.rss || 0,
          memoryPretty: status.rss ? formatBytes(status.rss) : '—',
          memoryLimitBytes: (status.memoryLimit || 0) * 1048576,
          uptime: status.uptimeMs || 0,
          processes: 1,
          players: state.players.size,
          maxPlayers: state.maxPlayers,
          tps: null,
          remote: true,
          node: node.name,
        };
        state.stats = { ...state.remoteStats };
        if (status.status === 'running' && state.status !== 'running') runtime.setStatus(server.id, 'running');
        else if (status.status === 'starting' && state.status !== 'starting') runtime.setStatus(server.id, 'starting');
      } else if (state.remotePid) {
        const manual = state.manualStop;
        const code = status.exitCode;
        state.remotePid = null;
        state.stats = { cpu: 0, memory: 0, memoryBytes: 0, uptime: 0, tps: null };
        runtime.pushExternalLog(server.id, `[Zenith] Remote process exited (code ${code === null ? 'unknown' : code})`);
        runtime.setStatus(server.id, manual || code === 0 ? 'offline' : 'crashed');
        if (!manual && code !== 0) logger.warn('remote', `${server.name} crashed on node ${node.name} (code ${code})`);
        stopWatch(server.id);
      }
    } catch (err) {
      entry.misses += 1;
      if (entry.misses === 3) {
        runtime.pushExternalLog(server.id, `[Zenith] node "${node.name}" is unreachable: ${err.message}`);
        logger.warn('remote', `${server.id}: ${err.message}`);
      }
    }
  };

  entry.timer = setInterval(entry.tick, 2000);
  entry.tick();
}

function stopWatch(serverId) {
  const entry = watchers.get(serverId);
  if (!entry) return;
  clearInterval(entry.timer);
  watchers.delete(serverId);
}

/* ------------------------------- lifecycle ------------------------------- */
async function start(server) {
  const runtime = rt();
  const node = mustNode(server);
  const state = runtime.state(server.id);
  if (state.remotePid) throw new Error(`Server is already running on node "${node.name}"`);

  state.manualStop = false;
  runtime.setStatus(server.id, 'starting');
  runtime.pushExternalLog(server.id, `[Zenith] Launching on node "${node.name}" (${baseUrl(node)})`);

  // Panel settings win: push memory/port/flags to the agent before it spawns the JVM.
  await request(node, 'POST', `/api/node/servers/${server.id}/config`, {
    memory: server.memory,
    port: server.port,
    motd: server.name,
    maxPlayers: server.maxPlayers,
    onlineMode: server.onlineMode !== false,
    aikarFlags: server.aikarFlags !== false,
    extraArgs: server.javaArgs || '',
    javaMajor: server.javaVersion || 21,
    ip: server.ip || '0.0.0.0',
  }, { timeout: 10000 }).catch((err) => runtime.pushExternalLog(server.id, `[Zenith] could not sync settings: ${err.message}`));
  const result = await request(node, 'POST', `/api/node/servers/${server.id}/start`, undefined, { timeout: 60000 });
  for (const note of result.notes || []) runtime.pushExternalLog(server.id, `[Zenith] ${note}`);
  state.remotePid = result.pid || -1;
  state.startedAt = Date.now();
  state.started = (state.started || 0) + 1;
  watch(server);
  logger.ok('remote', `${server.name} started on ${node.name} (pid ${result.pid})`);
  db.log({ actor: 'system', action: 'server.start', serverId: server.id, serverName: server.name, detail: `node ${node.name}` });
  return { pid: result.pid, status: 'starting', remote: true, node: node.name };
}

async function stop(serverOrId, { force = false } = {}) {
  const runtime = rt();
  const server = typeof serverOrId === 'string' ? db.find('servers', (s) => s.id === serverOrId) : serverOrId;
  if (!server) return { status: 'offline' };
  const node = mustNode(server);
  const state = runtime.state(server.id);
  if (!state.remotePid) {
    runtime.setStatus(server.id, 'offline');
    return { status: 'offline', alreadyStopped: true, remote: true };
  }
  state.manualStop = true;
  runtime.setStatus(server.id, 'stopping');
  await request(node, 'POST', `/api/node/servers/${server.id}/stop`, { force }, { timeout: 20000 });
  return { status: 'stopping', remote: true, node: node.name };
}

async function kill(serverOrId) {
  const runtime = rt();
  const server = typeof serverOrId === 'string' ? db.find('servers', (s) => s.id === serverOrId) : serverOrId;
  if (!server) return false;
  const node = mustNode(server);
  const state = runtime.state(server.id);
  state.manualStop = true;
  await request(node, 'POST', `/api/node/servers/${server.id}/kill`, undefined, { timeout: 15000 }).catch(() => {});
  state.remotePid = null;
  runtime.setStatus(server.id, 'offline');
  stopWatch(server.id);
  return true;
}

async function command(server, line) {
  const node = mustNode(server);
  const clean = String(line).replace(/[\r\n]+/g, ' ').trim();
  if (!clean) return false;
  await request(node, 'POST', `/api/node/servers/${server.id}/command`, { command: clean }, { timeout: 15000 });
  rt().pushExternalLog(server.id, `> ${clean}`);
  return true;
}

async function remove(server) {
  if (!isRemote(server)) return false;
  const node = nodeFor(server);
  stopWatch(server.id);
  if (!node) return false;
  await request(node, 'DELETE', `/api/node/servers/${server.id}`, undefined, { timeout: 20000 });
  logger.warn('remote', `removed ${server.name} from node ${node.name}`);
  return true;
}

/** Called at panel boot: adopt servers that are still running on their node. */
async function reconcile(server) {
  const runtime = rt();
  if (!isRemote(server)) return false;
  const node = nodeFor(server);
  if (!node) return false;
  try {
    const status = await request(node, 'GET', `/api/node/servers/${server.id}/status`, undefined, { timeout: 8000 });
    if (status.running) {
      const state = runtime.state(server.id);
      state.remotePid = status.pid;
      state.startedAt = status.startedAt ? Date.parse(status.startedAt) : Date.now();
      runtime.setStatus(server.id, status.status === 'running' ? 'running' : 'starting');
      runtime.pushExternalLog(server.id, `[Zenith] Adopted running server on node "${node.name}" (pid ${status.pid})`);
      watch(server);
      return true;
    }
    if (runtime.state(server.id).status !== 'offline' && !runtime.state(server.id).proc) runtime.setStatus(server.id, 'offline');
    return false;
  } catch (err) {
    logger.warn('remote', `could not reconcile ${server.name}: ${err.message}`);
    return false;
  }
}

exports.isRemote = isRemote;
exports.nodeFor = nodeFor;
exports.baseUrl = baseUrl;
exports.request = request;
exports.ping = ping;
exports.freePort = freePort;
exports.provision = provision;
exports.start = start;
exports.stop = stop;
exports.kill = kill;
exports.command = command;
exports.remove = remove;
exports.watch = watch;
exports.stopWatch = stopWatch;
exports.reconcile = reconcile;
exports.watchers = watchers;

exports.containerRuntime = containerRuntime;
