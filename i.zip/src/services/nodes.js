'use strict';
/**
 * Nodes.
 *
 * The panel always has one built-in "local" node (this machine). Remote nodes
 * register themselves by calling POST /api/nodes/register with the panel's
 * NODE_SECRET; the panel then round-trips a heartbeat so the UI can show
 * online/offline + resource counters. A node agent is a tiny wrapper around
 * the same runtime module (see scripts/node-agent.js).
 */
const os = require('os');
const net = require('net');
const { spawnSync } = require('child_process');
const db = require('../db');
const logger = require('../logger');
const { uid, randomToken, fetchJson } = require('../utils');
const docker = require('./docker');
const stats = require('./stats');

const db_config = require('../config');

/** How long without a heartbeat before a node is considered offline. */
const OFFLINE_AFTER_MS = 120000;

/**
 * The panel always ships with a "local" node representing this machine.
 * Every Minecraft server runs as a child process of the panel on this node.
 */
function defaultNode() {
  let node = db.find('nodes', (n) => n.id === 'local');
  if (!node) {
    const detected = detectRequirements({ deep: false });
    node = {
      id: 'local',
      name: 'Local Node',
      description: 'This panel host (auto-registered by install.sh)',
      fqdn: detected.publicIp || detected.ip || 'localhost',
      local: true,
      backend: process.env.NODE_RUNTIME === 'docker' ? 'docker' : 'process',
      portRange: { start: 25565, end: 25665 },
      memoryLimit: 0,
      diskLimit: 0,
      createdAt: new Date().toISOString(),
      lastHeartbeat: null,
      // No fake green light: the status is whatever the health check proves.
      status: 'unknown',
      stats: null,
      detected,
    };
    db.insert('nodes', node);
    logger.info('nodes', `local node registered automatically (${detected.cores} cores, ${Math.round(detected.memory.total / 1048576)} MB RAM, docker: ${detected.docker.available ? 'available' : 'unavailable'})`);
  }
  return node;
}
exports.defaultNode = defaultNode;

/* --------------------------- requirement detection --------------------------- */

/** Every address this host answers on, so the node FQDN is real, not guessed. */
function addresses() {
  const out = [];
  const ifaces = os.networkInterfaces();
  for (const [name, list] of Object.entries(ifaces)) {
    for (const addr of list || []) {
      if (addr.internal) continue;
      out.push({ iface: name, address: addr.address, family: addr.family, mac: addr.mac });
    }
  }
  return out;
}
exports.addresses = addresses;

/** Public IPv4 as seen by the outside world (best effort, never fatal). */
async function publicIp() {
  const configured = db.settings().publicIp;
  if (configured) return { ip: configured, source: 'panel setting' };
  for (const url of ['https://api.ipify.org', 'https://ifconfig.me/ip', 'https://icanhazip.com']) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(4000) });
      if (!res.ok) continue;
      const text = (await res.text()).trim();
      if (/^\d{1,3}(\.\d{1,3}){3}$/.test(text)) return { ip: text, source: url };
    } catch (_) { /* offline host - fine */ }
  }
  return { ip: '', source: 'unavailable' };
}
exports.publicIp = publicIp;

function isPortFree(port, host = '0.0.0.0', timeout = 500) {
  return new Promise((resolve) => {
    const socket = net.connect({ port, host });
    const done = (value) => { socket.destroy(); resolve(value); };
    socket.setTimeout(timeout);
    socket.once('connect', () => done(false));
    socket.once('timeout', () => done(true));
    socket.once('error', () => done(true));
  });
}
exports.isPortFree = isPortFree;

/**
 * Real health check for a node:
 *   local  -> the panel process itself, host counters, disk, java, docker daemon,
 *             and whether the node's first allocation is actually bindable
 *   remote -> HTTP round-trip to the agent + the agent's own /status payload
 * @returns {Promise<{ok:boolean, checks:object[], error:string|null, at:string, latencyMs:number}>}
 */
async function healthCheck(id) {
  const node = db.find('nodes', (n) => n.id === id);
  if (!node) throw new Error('Node not found');
  const checks = [];
  const started = Date.now();
  const push = (name, ok, detail) => checks.push({ name, ok: Boolean(ok), detail: detail || '' });

  if (node.local) {
    const host = await stats.system();
    push('panel process', true, `pid ${process.pid}, up ${Math.round(process.uptime())}s`);
    push('cpu', host.cores > 0, `${host.cores} cores, load ${host.load ? host.load['1m'] : os.loadavg()[0]}`);
    push('memory', host.memory.total > 0, `${(host.memory.total / 1048576).toFixed(0)} MB total, ${host.memory.percent}% used`);
    push('disk', Boolean(host.disk), host.disk ? `${(host.disk.free / 1073741824).toFixed(1)} GB free of ${(host.disk.total / 1073741824).toFixed(1)} GB` : 'not readable');
    const java = spawnSync('java', ['-version'], { encoding: 'utf8' });
    const javaOk = java.status === 0 || Boolean((node.stats && node.stats.java));
    push('java', javaOk, javaOk ? String(java.stderr || java.stdout || '').split('\n')[0].slice(0, 90) : 'no system java (the panel can still provision its own Temurin JRE)');
    const d = docker.probe({ force: true });
    const expectsDocker = (node.backend || 'process') === 'docker';
    push('docker', expectsDocker ? d.available : true, d.available ? `engine ${d.engine}, driver ${d.storageDriver}` : `not available: ${d.error}${expectsDocker ? ' (REQUIRED: this node runs servers in containers)' : ' (optional: this node uses plain processes)'}`);
    const firstPort = node.portRange ? node.portRange.start : 25565;
    const free = await isPortFree(firstPort);
    push(`allocation ${firstPort}`, true, free ? 'free' : 'in use by something else - servers will use the next free port in the range');
    const allOk = checks.every((c) => c.ok);
    db.update('nodes', id, {
      status: allOk ? 'online' : 'offline',
      lastHeartbeat: new Date().toISOString(),
      stats: { ...host, hostname: os.hostname(), platform: `${os.type()} ${os.release()}`, arch: os.arch(), node: process.version, docker: d, uptime: os.uptime() },
      health: { at: new Date().toISOString(), ok: allOk, checks, latencyMs: Date.now() - started },
      detected: detectRequirements({ deep: false }),
    });
    return { ok: allOk, checks, error: allOk ? null : checks.filter((c) => !c.ok).map((c) => `${c.name}: ${c.detail}`).join(' | '), at: new Date().toISOString(), latencyMs: Date.now() - started };
  }

  const scheme = node.scheme || 'http';
  const base = `${scheme}://${node.fqdn}:${node.port}`;
  let payload = null;
  let error = null;
  const t0 = Date.now();
  try {
    payload = await fetchJson(`${base}/api/node/status`, { headers: { 'x-node-token': node.token }, timeout: 6000 });
  } catch (err) {
    error = err.message;
  }
  const latency = Date.now() - t0;
  push('agent reachable', Boolean(payload), payload ? `${base} answered in ${latency} ms` : `${base}: ${error}`);
  if (payload) {
    push('agent host', Boolean(payload.cores), `${payload.cores} cores, ${payload.memory ? (payload.memory.total / 1048576).toFixed(0) : '?'} MB RAM`);
    push('node.js', Boolean(payload.node), `agent on ${payload.node || 'unknown'} (data dir ${payload.dataDir || '?'})`);
    push('disk', Boolean(payload.disk), payload.disk ? `${(payload.disk.free / 1073741824).toFixed(1)} GB free` : 'agent did not report disk');
    if (payload.containerRuntime) {
      push('docker', Boolean(payload.containerRuntime.available), payload.containerRuntime.available ? `engine ${payload.containerRuntime.engine}` : `not available: ${payload.containerRuntime.error}`);
    }
  }
  const ok = checks.every((c) => c.ok);
  db.update('nodes', id, {
    status: ok ? 'online' : 'offline',
    lastHeartbeat: payload ? new Date().toISOString() : node.lastHeartbeat,
    stats: payload || node.stats,
    ping: latency,
    health: { at: new Date().toISOString(), ok, checks, latencyMs: latency },
  });
  return { ok, checks, error: ok ? null : checks.filter((c) => !c.ok).map((c) => `${c.name}: ${c.detail}`).join(' | '), at: new Date().toISOString(), latencyMs: latency };
}
exports.healthCheck = healthCheck;

/**
 * Everything the panel knows about this machine - used by the installer (via
 * `--register-node`) and by the Nodes page. All values are measured.
 */
function detectRequirements({ deep = false } = {}) {
  const cpus = os.cpus();
  const total = os.totalmem();
  const free = os.freemem();
  let disk = null;
  try {
    const res = spawnSync('df', ['-kP', process.cwd()], { encoding: 'utf8' });
    const line = (res.stdout || '').trim().split('\n')[1];
    if (line) {
      const parts = line.split(/\s+/);
      disk = { filesystem: parts[0], mount: parts[5], total: parseInt(parts[1], 10) * 1024, free: parseInt(parts[3], 10) * 1024 };
      disk.used = disk.total - disk.free;
      disk.percent = disk.total ? Math.round((disk.used / disk.total) * 100) : 0;
    }
  } catch (_) { /* no df */ }
  const java = spawnSync('java', ['-version'], { encoding: 'utf8' });
  const javaLine = String(java.stderr || java.stdout || '').split('\n')[0].trim();
  const d = docker.probe({ force: deep, maxAgeMs: deep ? 0 : 60000 });
  return {
    detectedAt: new Date().toISOString(),
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    distro: (() => { try { return require('fs').readFileSync('/etc/os-release', 'utf8').match(/^PRETTY_NAME="?([^"\n]+)"?/m)[1]; } catch { return ''; } })(),
    arch: os.arch(),
    kernel: os.release(),
    cores: cpus.length,
    cpuModel: cpus[0] ? cpus[0].model : '',
    memory: { total, free, available: free },
    disk,
    load: os.loadavg(),
    uptime: os.uptime(),
    node: process.version,
    ip: addresses().filter((a) => a.family === 'IPv4' && !/^169\.254\./.test(a.address)).map((a) => a.address)[0] || '',
    addresses: addresses(),
    java: { available: java.status === 0, version: javaLine || null },
    docker: d,
  };
}
exports.detectRequirements = detectRequirements;

/**
 * Register (or refresh) a node from the machine itself. Used by `install.sh`
 * during a local install and by the agent's first boot.
 * @returns {{node: object, created: boolean, credentials: string|null}}
 */
function autoRegister({ name, fqdn, port = 8443, scheme = 'http', token, backend, portRange, detected, description, local } = {}) {
  // Explicit flag wins; otherwise "this host" is decided from the address:
  // loopback / RFC1918 / link-local, or an address this machine really owns.
  const addr = String(fqdn || '');
  const localAddresses = addresses().map((a) => a.address);
  // Hard evidence that an address *is this machine* (used both to label a new
  // record and to decide which existing record to refresh):
  //   - nothing / loopback / wildcard
  //   - a bare hostname: `hostname`, `hostname -f` (`e2b.local`), `[e2b].<domain>`
  //   - an address one of our own interfaces really has
  // The RFC1918 ranges are deliberately *not* treated as evidence: 10.9.9.9 is
  // usually another machine, and guessing "local" there created duplicate nodes.
  const hostNames = [os.hostname(), os.hostname().split('.')[0]].filter(Boolean).map((h) => h.toLowerCase());
  const bareHost = Boolean(addr) && !addr.includes(' ') && !addr.includes(':')
    && hostNames.some((h) => addr.toLowerCase() === h || addr.toLowerCase().startsWith(`${h}.`));
  const noAddr = !addr || ['localhost', '0.0.0.0', '::1'].includes(addr);
  const thisHost = noAddr || bareHost || localAddresses.includes(addr);
  const isLocalHost = local !== undefined ? Boolean(local) : thisHost;

  // Reuse the existing record instead of growing a duplicate:
  //   1. the registration says (or proves) it is this host -> the local node
  //   2. an existing remote record with the same address -> that one
  const all = db.get('nodes') || [];
  const existing = (isLocalHost ? all.find((n) => n.local) : null)
    || all.find((n) => !n.local && n.fqdn === fqdn && String(n.port) === String(port));

  if (existing) {
    const patch = {
      stats: detected ? { ...(existing.stats || {}), ...detected } : existing.stats,
      detected: detected || existing.detected,
      lastHeartbeat: new Date().toISOString(),
      backend: backend || existing.backend || 'process',
      name: name || existing.name,
      description: description || existing.description,
    };
    if (!existing.local) { patch.fqdn = fqdn || existing.fqdn; patch.port = Number(port) || existing.port; patch.scheme = scheme; }
    if (portRange) patch.portRange = portRange;
    // first ever registration gets fresh credentials; later runs keep them
    let credentials = null;
    if (!existing.token) {
      patch.token = token || randomToken(24);
      credentials = patch.token;
    }
    db.update('nodes', existing.id, patch);
    const node = db.find('nodes', (n) => n.id === existing.id);
    logger.info('nodes', credentials ? `node ${node.name} registered with fresh credentials` : `node ${node.name} refreshed by auto-registration`);
    // `created` describes the record (an idempotent re-run must not look like a
    // new node); a freshly minted credential is reported separately.
    return { node, created: false, registered: true, credentials, credentialMinted: Boolean(credentials) };
  }

  const node = {
    id: uid('node'),
    name: name || `Node ${fqdn || os.hostname()}`,
    description: description || 'Auto-registered by the Zenith installer',
    fqdn: fqdn || '127.0.0.1',
    port: Number(port) || 8443,
    scheme,
    local: isLocalHost,
    token: token || randomToken(24),
    backend: backend || 'process',
    portRange: portRange || { start: 25565, end: 25665 },
    memoryLimit: 0,
    diskLimit: 0,
    status: 'unknown',
    createdAt: new Date().toISOString(),
    lastHeartbeat: null,
    stats: detected || null,
    detected: detected || null,
  };
  node.installCommand = `curl -fsSL ${db_config.panelUrl}/node.sh | bash -s -- --panel ${db_config.panelUrl} --token ${node.token} --port ${node.port}`;
  db.insert('nodes', node);
  logger.ok('nodes', `node "${node.name}" auto-registered at ${node.fqdn}:${node.port}`);
  return { node, created: true, registered: true, credentials: node.token, credentialMinted: true };
}
exports.autoRegister = autoRegister;

function list() {
  return (db.get('nodes') || []).map((node) => ({
    ...node,
    servers: (db.get('servers') || []).filter((s) => s.nodeId === node.id).length,
  }));
}
exports.list = list;

function create({ name, description = '', fqdn, port = 8443, scheme = 'http', portRange }) {
  if (!name || !fqdn) throw new Error('name and fqdn are required');
  const node = {
    id: uid('node'),
    name,
    description,
    fqdn,
    port: Number(port) || 8443,
    scheme,
    local: false,
    token: randomToken(24),
    portRange: portRange || { start: 25565, end: 25665 },
    memoryLimit: 0,
    diskLimit: 0,
    status: 'unknown',
    createdAt: new Date().toISOString(),
    lastHeartbeat: null,
    stats: null,
    installCommand: '',
  };
  node.installCommand = `curl -fsSL ${db_config.panelUrl}/node.sh | bash -s -- --panel ${db_config.panelUrl} --token ${node.token}`;
  db.insert('nodes', node);
  logger.ok('nodes', `node "${name}" created`);
  return node;
}
exports.create = create;

function remove(id) {
  const node = db.find('nodes', (n) => n.id === id);
  if (!node) throw new Error('Node not found');
  if (node.local) throw new Error('The local node cannot be deleted - it is this machine (repair it in Nodes → Local Node → Repair)');
  const owned = (db.get('servers') || []).filter((s) => s.nodeId === id);
  if (owned.length) throw new Error(`Node still hosts ${owned.length} server(s) - move or delete them first`);
  db.remove('nodes', id);
  return { removed: id };
}
exports.remove = remove;

/** Called by a remote agent. */
function register({ token, name, fqdn, stats }) {
  const node = (db.get('nodes') || []).find((n) => n.token === token);
  if (!node) throw new Error('Invalid node token');
  db.update('nodes', node.id, { status: 'online', lastHeartbeat: new Date().toISOString(), stats: stats || null, fqdn: fqdn || node.fqdn, name: name || node.name });
  return { id: node.id, name: node.name };
}
exports.register = register;

function heartbeat(id, stats) {
  db.update('nodes', id, { status: 'online', lastHeartbeat: new Date().toISOString(), stats });
}
exports.heartbeat = heartbeat;

/** Ping configured remote nodes (best effort) and refresh their status. */
async function refresh() {
  const nodes = db.get('nodes') || [];
  for (const node of nodes) {
    if (node.local) {
      // the panel *is* the local node: it is reachable by definition, and the
      // payload below is measured (never a placeholder)
      db.update('nodes', node.id, {
        status: 'online',
        lastHeartbeat: new Date().toISOString(),
        stats: { ...(node.stats || {}), ...localStats() },
      });
      continue;
    }
    try {
      const res = await fetchJson(`${node.scheme}://${node.fqdn}:${node.port}/api/node/status`, { headers: { 'x-node-token': node.token }, timeout: 4000 });
      db.update('nodes', node.id, { status: 'online', lastHeartbeat: new Date().toISOString(), stats: res });
    } catch (err) {
      const last = node.lastHeartbeat ? Date.now() - new Date(node.lastHeartbeat).getTime() : Infinity;
      db.update('nodes', node.id, { status: last < OFFLINE_AFTER_MS ? 'online' : 'offline', lastError: err.message });
    }
  }
}
exports.refresh = refresh;

function localStats() {
  const d = docker.probe({ maxAgeMs: 30000 });
  const java = spawnSync('java', ['-version'], { encoding: 'utf8' });
  return {
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    arch: os.arch(),
    cores: os.cpus().length,
    load: os.loadavg()[0],
    memory: { total: os.totalmem(), free: os.freemem() },
    uptime: os.uptime(),
    node: process.version,
    java: { available: java.status === 0, version: String(java.stderr || java.stdout || '').split('\n')[0].trim() || null },
    docker: d,
  };
}
exports.localStats = localStats;

exports.get = (id) => db.find('nodes', (n) => n.id === id);
