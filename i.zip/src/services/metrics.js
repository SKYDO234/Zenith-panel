'use strict';
/**
 * Panel-wide metrics history.
 *
 * Samples host + fleet counters every few seconds into a ring buffer so the
 * dashboard can draw real graphs instead of a single live number. Kept in
 * memory only: nothing is written to disk, and the buffer length is bounded.
 */
const stats = require('./stats');
const db = require('../db');
const runtime = require('./runtime');

const RETENTION = 720;          // samples kept (5 s each => 1 hour)
const INTERVAL = 5000;
const samples = [];
let timer = null;

function runningCount() {
  return (db.get('servers') || []).filter((s) => {
    const state = runtime.state(s.id);
    return Boolean(state.proc || state.remotePid);
  }).length;
}

async function sampleOnce() {
  try {
    const host = await stats.system();
    const servers = db.get('servers') || [];
    let players = 0;
    for (const s of servers) players += runtime.state(s.id).players.size;
    samples.push({
      at: Date.now(),
      cpu: host.cpu,
      memory: host.memory.percent,
      memoryUsed: host.memory.used,
      disk: host.disk ? Math.round(((host.disk.total - host.disk.free) / host.disk.total) * 100) : 0,
      servers: servers.length,
      running: runningCount(),
      players,
      load: host.load ? host.load['1m'] : 0,
    });
    if (samples.length > RETENTION) samples.splice(0, samples.length - RETENTION);
  } catch (_) { /* a single failed sample is not worth logging */ }
}
exports.sampleOnce = sampleOnce;

function start() {
  if (timer) return;
  sampleOnce();
  timer = setInterval(sampleOnce, INTERVAL);
  timer.unref?.();
}
exports.start = start;

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
}
exports.stop = stop;

/**
 * @param {object} opts { minutes = 30, points = 120 }
 * @returns {{ points: number, series: object[], summary: object }}
 */
function history({ minutes = 30, points = 120 } = {}) {
  const since = Date.now() - Math.min(minutes, 720) * 60000;
  const filtered = samples.filter((s) => s.at >= since);
  // downsample to at most `points` buckets, averaging inside each bucket
  const bucketSize = Math.max(1, Math.ceil(filtered.length / points));
  const out = [];
  for (let i = 0; i < filtered.length; i += bucketSize) {
    const slice = filtered.slice(i, i + bucketSize);
    const avg = (key) => Number((slice.reduce((sum, s) => sum + (s[key] || 0), 0) / slice.length).toFixed(2));
    const last = slice[slice.length - 1];
    out.push({
      at: last.at,
      cpu: avg('cpu'),
      memory: avg('memory'),
      disk: avg('disk'),
      servers: last.servers,
      running: last.running,
      players: last.players,
      load: avg('load'),
    });
  }
  const peak = (key) => (filtered.length ? Math.max(...filtered.map((s) => Number(s[key] || 0))) : 0);
  const avgOf = (key) => (filtered.length ? Number((filtered.reduce((sum, s) => sum + Number(s[key] || 0), 0) / filtered.length).toFixed(1)) : 0);
  return {
    points: out.length,
    intervalMs: INTERVAL,
    windowMinutes: minutes,
    series: out,
    summary: {
      cpuAvg: avgOf('cpu'), cpuPeak: peak('cpu'),
      memoryAvg: avgOf('memory'), memoryPeak: peak('memory'),
      playersPeak: peak('players'),
      disk: filtered.length ? filtered[filtered.length - 1].disk : 0,
      uptimeSamples: filtered.length,
    },
  };
}
exports.history = history;
