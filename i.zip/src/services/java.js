'use strict';
/**
 * Java runtime manager.
 * Detects what is already on the machine and can fetch Temurin (Adoptium)
 * JREs into data/java/jre-<major> so a fresh box needs no manual setup.
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const os = require('os');

const cfg = require('../config');
const logger = require('../logger');
const { download, exists, formatBytes, ensureDir } = require('../utils');
const { execFileP } = require('./versions');

function osSlug() {
  switch (process.platform) {
    case 'linux': return 'linux';
    case 'darwin': return 'mac';
    case 'win32': return 'windows';
    default: return 'linux';
  }
}
function archSlug() {
  switch (process.arch) {
    case 'x64': return 'x64';
    case 'arm64': return 'aarch64';
    case 'arm': return 'arm';
    default: return 'x64';
  }
}
function ext() { return process.platform === 'win32' ? 'zip' : 'tar.gz'; }

async function versionOf(bin) {
  const res = await execFileP(bin, ['-version']);
  const text = `${res.stdout}\n${res.stderr}`;
  const m = text.match(/version "?(\d+)(?:\.(\d+))?/);
  if (!m) return null;
  const major = parseInt(m[1], 10);
  return { major: major === 1 ? parseInt(m[2] || '0', 10) : major, raw: text.split('\n')[0].trim() };
}

/** All JVMs the panel can see. */
async function list() {
  const found = [];
  const managedRoot = cfg.javaDir;
  const managed = fs.existsSync(managedRoot) ? fs.readdirSync(managedRoot, { withFileTypes: true }).filter((d) => d.isDirectory()) : [];
  for (const dir of managed) {
    const bin = path.join(managedRoot, dir.name, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
    if (fs.existsSync(bin)) {
      const v = await versionOf(bin);
      found.push({ path: bin, managed: true, label: `Temurin ${v ? `Java ${v.major}` : dir.name} (managed)`, ...(v || {}) });
    }
  }
  const candidates = new Set();
  if (process.env.JAVA_HOME) candidates.add(path.join(process.env.JAVA_HOME, 'bin', process.platform === 'win32' ? 'java.exe' : 'java'));
  candidates.add(cfg.javaBin || 'java');
  for (const base of ['/usr/lib/jvm', '/usr/java', '/opt/java', '/Library/Java/JavaVirtualMachines']) {
    try {
      for (const dir of fs.readdirSync(base)) {
        candidates.add(path.join(base, dir, 'bin', 'java'));
        candidates.add(path.join(base, dir, 'Contents', 'Home', 'bin', 'java'));
      }
    } catch (_) {}
  }
  for (const bin of candidates) {
    try {
      const v = await versionOf(bin);
      if (!v) continue;
      if (found.some((f) => f.path === bin)) continue;
      found.push({ path: bin, managed: false, label: `System Java ${v.major}`, ...v });
    } catch (_) {}
  }
  found.sort((a, b) => (b.major || 0) - (a.major || 0));
  return found;
}
exports.list = list;
exports.versionOf = versionOf;

async function managedPath(major) {
  const bin = path.join(cfg.javaDir, `jre-${major}`, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
  return (await exists(bin)) ? bin : null;
}
exports.managedPath = managedPath;

/**
 * Ensure a JRE for the given major version exists locally.
 * Returns the java binary path.
 */
async function ensure(major, onProgress = () => {}) {
  const already = await managedPath(major);
  if (already) return already;

  const installed = await list();
  const usable = installed.find((j) => (j.major || 0) === Number(major));
  if (usable && !cfg.settings?.installJavaAutomatically) return usable.path;

  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${osSlug()}/${archSlug()}/jre/hotspot/normal/eclipse`;
  const archive = path.join(cfg.dataDir, 'tmp', `temurin-${major}.${ext()}`);
  await ensureDir(path.dirname(archive));
  logger.info('java', `Downloading Temurin JRE ${major} for ${osSlug()}/${archSlug()}`);
  await download(url, archive, { onProgress });
  onProgress({ percent: 100, received: 0, total: 0 });

  const target = path.join(cfg.javaDir, `jre-${major}`);
  await fsp.rm(target, { recursive: true, force: true });
  await ensureDir(target);

  if (ext() === 'zip') {
    const AdmZip = require('adm-zip');
    new AdmZip(archive).extractAllTo(target, true);
  } else {
    const res = await execFileP('tar', ['-xzf', archive, '-C', target]);
    if (!res.ok) throw new Error(`Failed to extract Java: ${res.stderr || res.error}`);
  }
  // JDK tarballs contain a single nested folder - flatten it
  const entries = await fsp.readdir(target);
  if (entries.length === 1) {
    const nested = path.join(target, entries[0]);
    if ((await fsp.stat(nested)).isDirectory() && fs.existsSync(path.join(nested, 'bin'))) {
      for (const item of await fsp.readdir(nested)) {
        await fsp.rename(path.join(nested, item), path.join(target, item));
      }
      await fsp.rm(nested, { recursive: true, force: true });
    }
  }
  const archiveSize = (await fsp.stat(archive).catch(() => ({ size: 0 }))).size;
  await fsp.unlink(archive).catch(() => {});
  const bin = path.join(target, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
  if (!(await exists(bin))) throw new Error('Java extraction produced no binary');
  await fsp.chmod(bin, 0o755).catch(() => {});
  logger.ok('java', `Java ${major} installed at ${bin} (${formatBytes(archiveSize)})`);
  onProgress({ percent: 100, note: `Java ${major} installed` });
  return bin;
}
exports.ensure = ensure;

exports.info = async () => ({ platform: process.platform, arch: process.arch, host: os.hostname(), available: await list() });

/**
 * Disk usage of the managed runtimes + what can be freed.
 * A JRE is "in use" when a server pins that major version (or a server's
 * javaPath points inside it); those are never offered for removal.
 */
async function usage() {
  const db = require('../db');
  const { dirSize } = require('../utils');
  const servers = db.get('servers') || [];
  const wanted = new Set();
  for (const server of servers) {
    if (server.javaVersion) wanted.add(Number(server.javaVersion));
    if (server.requiredJava) wanted.add(Number(server.requiredJava));
    if (server.javaPath && String(server.javaPath).includes(cfg.javaDir)) {
      const m = String(server.javaPath).match(/jre-(\d+)/);
      if (m) wanted.add(Number(m[1]));
    }
  }
  const dirs = fs.existsSync(cfg.javaDir)
    ? fs.readdirSync(cfg.javaDir, { withFileTypes: true }).filter((d) => d.isDirectory() && /^jre-\d+$/.test(d.name))
    : [];
  const entries = [];
  let totalBytes = 0;
  for (const dir of dirs) {
    const major = Number(dir.name.replace('jre-', ''));
    const full = path.join(cfg.javaDir, dir.name);
    const bytes = await dirSize(full);
    totalBytes += bytes;
    entries.push({ path: full, major, bytes, used: wanted.has(major), servers: servers.filter((s) => Number(s.javaVersion) === major).length });
  }
  return {
    dir: cfg.javaDir,
    totalBytes,
    unusedBytes: entries.filter((e) => !e.used).reduce((a, e) => a + e.bytes, 0),
    entries,
    inUseMajors: [...wanted].sort((a, b) => a - b),
  };
}
exports.usage = usage;

/** Remove managed runtimes no server needs. `all: true` removes everything. */
async function prune({ all = false } = {}) {
  const report = await usage();
  const victims = report.entries.filter((e) => (all ? true : !e.used));
  let freed = 0;
  const removed = [];
  for (const victim of victims) {
    // never delete a runtime while a server that needs it is running
    if (victim.used) {
      const runtime = require('./runtime');
      const busy = (require('../db').get('servers') || [])
        .filter((s) => Number(s.javaVersion) === victim.major)
        .some((s) => runtime.isOnline(s.id));
      if (busy) continue;
    }
    await fsp.rm(victim.path, { recursive: true, force: true });
    freed += victim.bytes;
    removed.push({ path: victim.path, major: victim.major, bytes: victim.bytes });
    logger.info('java', `pruned ${victim.path} (${formatBytes(victim.bytes)})`);
  }
  return { freed, removed, kept: report.entries.filter((e) => !victims.includes(e)) };
}
exports.prune = prune;
