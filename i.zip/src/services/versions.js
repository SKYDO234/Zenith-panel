'use strict';
/**
 * Minecraft server software catalogue + downloader.
 *
 * Everything is fetched live from the upstream APIs, so new Minecraft
 * versions show up in the panel without a panel update:
 *   VANILLA    -> Mojang version manifest
 *   PAPER      -> fill.papermc.io v3
 *   VELOCITY   -> fill.papermc.io v3
 *   PURPUR     -> api.purpurmc.org v2
 *   FABRIC     -> meta.fabricmc.net v2
 *   QUILT      -> meta.quiltmc.org v3
 *   FORGE      -> maven.minecraftforge.net
 *   NEOFORGE   -> maven.neoforged.net
 *   BUNGEECORD -> ci.md-5.net
 *   SPIGOT     -> BuildTools
 *   CUSTOM     -> user uploaded jar
 */
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const { execFile } = require('child_process');

const cfg = require('../config');
const logger = require('../logger');
const { download, fetchJson, formatBytes, exists } = require('../utils');

const TYPES = [
  { id: 'VANILLA', name: 'Vanilla', description: 'Official Mojang server', kind: 'server', mods: false, plugins: false, java: 'auto' },
  { id: 'PAPER', name: 'Paper', description: 'High performance Spigot fork (recommended)', kind: 'server', mods: false, plugins: true, java: 'auto' },
  { id: 'PURPUR', name: 'Purpur', description: 'Paper fork with extra configuration options', kind: 'server', mods: false, plugins: true, java: 'auto' },
  { id: 'FABRIC', name: 'Fabric', description: 'Lightweight mod loader', kind: 'server', mods: true, plugins: false, java: 'auto' },
  { id: 'QUILT', name: 'Quilt', description: 'Fabric-compatible mod loader', kind: 'server', mods: true, plugins: false, java: 'auto' },
  { id: 'FORGE', name: 'Forge', description: 'Classic mod loader for large modpacks', kind: 'server', mods: true, plugins: false, java: 'auto' },
  { id: 'NEOFORGE', name: 'NeoForge', description: 'Modern Forge fork', kind: 'server', mods: true, plugins: false, java: 'auto' },
  { id: 'SPIGOT', name: 'Spigot', description: 'Built from source with BuildTools (slow)', kind: 'server', mods: false, plugins: true, java: 'auto' },
  { id: 'BUNGEECORD', name: 'BungeeCord', description: 'Proxy', kind: 'proxy', mods: false, plugins: true, java: 'auto' },
  { id: 'VELOCITY', name: 'Velocity', description: 'Modern proxy (PaperMC)', kind: 'proxy', mods: false, plugins: true, java: 'auto' },
  { id: 'CUSTOM', name: 'Custom jar', description: 'Upload your own server jar', kind: 'server', mods: true, plugins: true, java: 'auto' },
];
exports.TYPES = TYPES;

/** Which Java major version a Minecraft version needs. */
function javaFor(mcVersion) {
  const v = String(mcVersion || '');
  if (/^26\./.test(v)) return 25;                      // 2026 release train
  if (/^1\.(2[1-9]|[3-9]\d)/.test(v)) return 21;
  if (/^1\.20\.[5-9]|^1\.20\.[1-9]\d/.test(v)) return 21;
  if (/^1\.(18|19|20)/.test(v)) return 17;
  if (/^1\.17/.test(v)) return 17;
  return 8;
}
exports.javaFor = javaFor;

const cache = new Map();
async function cached(key, ttlMs, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value;
  const value = await fn();
  cache.set(key, { at: Date.now(), value });
  return value;
}

/* ------------------------------ versions ------------------------------ */
async function listVersions(type) {
  type = String(type || '').toUpperCase();
  switch (type) {
    case 'VANILLA': {
      const m = await cached('vanilla', 30 * 60e3, () => fetchJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json'));
      return {
        latest: m.latest.release,
        versions: m.versions.filter((v) => v.type === 'release').map((v) => ({ id: v.id, released: v.releaseTime.slice(0, 10) })).slice(0, 120),
      };
    }
    case 'PAPER':
    case 'VELOCITY': {
      const data = await cached(`pmc-${type}`, 30 * 60e3, () => fetchJson(`https://fill.papermc.io/v3/projects/${type.toLowerCase()}`));
      const versions = Object.values(data.versions || {}).flat();
      return { latest: versions[0], versions: versions.map((id) => ({ id })) };
    }
    case 'PURPUR': {
      const data = await cached('purpur', 30 * 60e3, () => fetchJson('https://api.purpurmc.org/v2/purpur'));
      const versions = (data.versions || []).slice().reverse();
      return { latest: versions[0], versions: versions.map((id) => ({ id })) };
    }
    case 'FABRIC': {
      const game = await cached('fabric-game', 30 * 60e3, () => fetchJson('https://meta.fabricmc.net/v2/versions/game'));
      return { latest: game[0] && game[0].version, versions: game.filter((g) => g.stable).map((g) => ({ id: g.version })) };
    }
    case 'QUILT': {
      const game = await cached('quilt-game', 30 * 60e3, () => fetchJson('https://meta.quiltmc.org/v3/versions/game'));
      return { latest: game[0] && game[0].version, versions: game.slice(0, 200).map((g) => ({ id: g.version })) };
    }
    case 'FORGE': {
      const xml = await cached('forge-meta', 60 * 60e3, () => fetchText('https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml'));
      const list = [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]);
      const byMc = new Map();
      for (const v of list) {
        const mc = v.split('-')[0];
        if (!byMc.has(mc)) byMc.set(mc, []);
        byMc.get(mc).push(v);
      }
      const mcs = [...byMc.keys()].filter((v) => /^1\./.test(v)).sort(cmpMc).reverse();
      return {
        latest: mcs[0],
        versions: mcs.map((mc) => ({ id: mc, builds: byMc.get(mc).length })),
      };
    }
    case 'NEOFORGE': {
      const xml = await cached('neoforge-meta', 60 * 60e3, () => fetchText('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml'));
      const list = [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]);
      const byMc = new Map();
      for (const v of list) {
        const parts = v.split('.');
        const mc = parts.length >= 2 ? `1.${parts[0]}.${parts[1]}` : v;
        if (!byMc.has(mc)) byMc.set(mc, []);
        byMc.get(mc).push(v);
      }
      const mcs = [...byMc.keys()].sort(cmpMc).reverse();
      return { latest: mcs[0], versions: mcs.map((mc) => ({ id: mc, builds: byMc.get(mc).length })) };
    }
    case 'BUNGEECORD': {
      const list = await cached('bungee', 10 * 60e3, () => fetchJson('https://ci.md-5.net/job/BungeeCord/api/json?tree=builds[number,result,timestamp]&depth=1'));
      const builds = (list.builds || []).filter((b) => b.result === 'SUCCESS').slice(0, 10);
      return { latest: builds[0] ? `#${builds[0].number}` : 'latest', versions: builds.map((b) => ({ id: `#${b.number}`, build: b.number })) };
    }
    case 'SPIGOT': {
      const m = await cached('vanilla', 30 * 60e3, () => fetchJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json'));
      return { latest: m.latest.release, versions: m.versions.filter((v) => v.type === 'release').slice(0, 60).map((v) => ({ id: v.id })) };
    }
    default:
      return { latest: 'custom', versions: [] };
  }
}
exports.listVersions = listVersions;

function cmpMc(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

async function fetchText(url) {
  const res = await fetch(url, { headers: { 'User-Agent': cfg.modrinthUA } });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.text();
}

/* --------------------------- download URLs --------------------------- */
async function resolveDownload(type, version) {
  type = String(type).toUpperCase();
  switch (type) {
    case 'VANILLA': {
      const m = await fetchJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json');
      const entry = m.versions.find((v) => v.id === version);
      if (!entry) throw new Error(`Unknown Minecraft version ${version}`);
      const meta = await fetchJson(entry.url);
      return { url: meta.downloads.server.url, filename: `server-${version}.jar`, build: null };
    }
    case 'PAPER':
    case 'VELOCITY': {
      const builds = await fetchJson(`https://fill.papermc.io/v3/projects/${type.toLowerCase()}/versions/${version}/builds`);
      const stable = builds.find((b) => b.channel === 'STABLE') || builds[0];
      if (!stable) throw new Error(`No builds for ${type} ${version}`);
      const dl = stable.downloads['server:default'] || Object.values(stable.downloads)[0];
      return { url: dl.url, filename: dl.name, build: String(stable.id), sha256: dl.checksums && dl.checksums.sha256 };
    }
    case 'PURPUR': {
      const info = await fetchJson(`https://api.purpurmc.org/v2/purpur/${version}`);
      const build = info.builds.latest;
      return { url: `https://api.purpurmc.org/v2/purpur/${version}/${build}/download`, filename: `purpur-${version}-${build}.jar`, build };
    }
    case 'FABRIC': {
      const loaders = await fetchJson(`https://meta.fabricmc.net/v2/versions/loader/${version}`);
      const loader = loaders.find((l) => l.loader.stable) || loaders[0];
      const installer = await fetchJson(`https://meta.fabricmc.net/v2/versions/installer`);
      return {
        url: `https://meta.fabricmc.net/v2/versions/loader/${version}/${loader.loader.version}/${installer[0].version}/server/jar`,
        filename: `fabric-server-${version}.jar`,
        build: loader.loader.version,
      };
    }
    case 'QUILT': {
      const loaders = await fetchJson(`https://meta.quiltmc.org/v3/versions/loader/${version}`);
      const loader = loaders[0];
      return {
        url: `https://meta.quiltmc.org/v3/versions/loader/${version}/${loader.loader.version}/server/jar`,
        filename: `quilt-server-${version}.jar`,
        build: loader.loader.version,
      };
    }
    case 'FORGE': {
      const xml = await fetchText('https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml');
      const candidates = [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]).filter((v) => v.startsWith(`${version}-`));
      if (!candidates.length) throw new Error(`No Forge build for ${version}`);
      const full = candidates[candidates.length - 1];
      return {
        url: `https://maven.minecraftforge.net/net/minecraftforge/forge/${full}/forge-${full}-installer.jar`,
        filename: `forge-${full}-installer.jar`,
        installer: true,
        fullVersion: full,
        build: full.split('-')[1],
      };
    }
    case 'NEOFORGE': {
      const xml = await fetchText('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml');
      const list = [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map((m) => m[1]);
      const prefix = version.replace(/^1\./, '');
      const candidates = list.filter((v) => v.startsWith(`${prefix}.`));
      if (!candidates.length) throw new Error(`No NeoForge build for ${version}`);
      const full = candidates[candidates.length - 1];
      return {
        url: `https://maven.neoforged.net/releases/net/neoforged/neoforge/${full}/neoforge-${full}-installer.jar`,
        filename: `neoforge-${full}-installer.jar`,
        installer: true,
        fullVersion: full,
        build: full,
      };
    }
    case 'BUNGEECORD': {
      const build = String(version || '').replace('#', '') || 'lastSuccessfulBuild';
      return {
        url: `https://ci.md-5.net/job/BungeeCord/${/^\d+$/.test(build) ? build : 'lastSuccessfulBuild'}/artifact/bootstrap/target/BungeeCord.jar`,
        filename: 'BungeeCord.jar',
        build,
      };
    }
    case 'SPIGOT':
      return { url: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar', filename: 'BuildTools.jar', buildTools: true };
    default:
      throw new Error(`Cannot auto-download a jar for type ${type}`);
  }
}
exports.resolveDownload = resolveDownload;

function execFileP(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    execFile(cmd, args, { maxBuffer: 8 * 1024 * 1024, ...opts }, (err, stdout, stderr) => {
      resolve({ ok: !err, code: err ? err.code || 1 : 0, stdout: String(stdout || ''), stderr: String(stderr || ''), error: err ? err.message : null });
    });
  });
}
exports.execFileP = execFileP;

/**
 * Install (or reinstall) the server software into the server directory.
 * @param {object} server   db record
 * @param {object} opts     { version, type, progress(step, percent, note) }
 */
async function install(server, { version, type, progress = () => {} } = {}) {
  const runtime = require('./runtime');
  const dir = await runtime.ensureDirStructure(server);
  type = String(type || server.serverType || 'PAPER').toUpperCase();
  version = version || server.version || 'latest';

  // Downloads run into data/tmp and can be hundreds of MB - always clean up after ourselves.
  const tempPaths = [];
  const cleanupTemp = async () => {
    for (const p of tempPaths) await fsp.rm(p, { force: true, recursive: true }).catch(() => {});
  };

  try {
  const java = require('./java');
  const jv = javaFor(version);
  progress('java', 4, `Checking Java ${jv}...`);
  let javaPath;
  try {
    javaPath = await java.ensure(jv, (p) => progress('java', 4 + p.percent * 0.12, `Downloading Java ${jv} (${formatBytes(p.received)})`));
  } catch (err) {
    logger.warn('versions', `Java ${jv} not available (${err.message}); falling back to system java`);
    javaPath = null;
  }

  if (type === 'CUSTOM') {
    progress('done', 100, 'Custom jar - waiting for upload');
    return { custom: true, javaPath };
  }

  if (type === 'SPIGOT') {
    progress('download', 16, 'Downloading BuildTools...');
    const btDir = path.join(cfg.dataDir, 'tmp', `buildtools-${version}`);
    await fsp.mkdir(btDir, { recursive: true });
    tempPaths.push(btDir);
    const bt = path.join(btDir, 'BuildTools.jar');
    const meta = await resolveDownload(type, version);
    await download(meta.url, bt);
    progress('build', 30, `Building Spigot ${version} (this can take ~10 minutes)...`);
    const res = await execFileP(javaPath || 'java', ['-jar', 'BuildTools.jar', '--rev', version], {
      cwd: btDir,
      env: { ...process.env, JAVA_HOME: javaPath ? path.dirname(path.dirname(javaPath)) : process.env.JAVA_HOME || '' },
      timeout: 30 * 60e3,
    });
    if (!res.ok) throw new Error(`BuildTools failed: ${res.stderr.slice(-500) || res.error}`);
    const built = path.join(btDir, `spigot-${version}.jar`);
    if (!(await exists(built))) throw new Error('BuildTools finished but no spigot jar was produced');
    await fsp.copyFile(built, path.join(dir, 'server.jar'));
    progress('done', 100, 'Spigot installed');
    return { jar: 'server.jar', javaPath, build: null };
  }

  const meta = await resolveDownload(type, version);
  progress('download', 18, `Downloading ${meta.filename}...`);
  const tmpJar = path.join(cfg.dataDir, 'tmp', meta.filename);
  tempPaths.push(tmpJar);
  await download(meta.url, tmpJar, {
    onProgress: (p) => progress('download', 18 + p.percent * 0.35, `Downloading ${meta.filename} - ${formatBytes(p.received)}${p.total ? ` / ${formatBytes(p.total)}` : ''}`),
  });

  if (meta.installer) {
    progress('install', 58, `Running ${type} installer (this takes a few minutes)...`);
    const inst = await execFileP(javaPath || 'java', ['-jar', path.basename(tmpJar), '--installServer', dir], { cwd: dir, timeout: 20 * 60e3 });
    const log = `${inst.stdout}\n${inst.stderr}`.trim().split('\n').slice(-6).join('\n');
    if (!inst.ok) throw new Error(`${type} installer failed:\n${log}`);
    // Forge/NeoForge drop run.sh or a launcher jar + libraries dir
    const candidates = [
      path.join(dir, 'run.sh'),
      ...(await fsp.readdir(dir).catch(() => [])).filter((f) => /^(forge|neoforge).*\.jar$/.test(f)).map((f) => path.join(dir, f)),
    ];
    const launch = candidates.find((c) => c.endsWith('.jar'));
    if (launch) {
      await fsp.copyFile(launch, path.join(dir, 'server.jar'));
      progress('done', 100, `${type} ${meta.fullVersion || version} installed`);
      return { jar: 'server.jar', javaPath, build: meta.build, fullVersion: meta.fullVersion, launcherJar: path.basename(launch) };
    }
    if (await exists(path.join(dir, 'run.sh'))) {
      await fsp.chmod(path.join(dir, 'run.sh'), 0o755);
      progress('done', 100, `${type} installed (launcher script mode)`);
      return { jar: 'run.sh', javaPath, build: meta.build, useScript: 'run.sh' };
    }
    progress('done', 100, `${type} installer finished`);
    return { jar: 'server.jar', javaPath, build: meta.build };
  }

  const target = path.join(dir, 'server.jar');
  await fsp.copyFile(tmpJar, target);
  progress('done', 100, `${type} ${version} ${meta.build ? `build ${meta.build}` : ''} ready`);
  return { jar: 'server.jar', javaPath, build: meta.build, version };
  } finally {
    await cleanupTemp();
  }
}
exports.install = install;
