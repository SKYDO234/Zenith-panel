'use strict';
/**
 * Server records: creation, port allocation, limits and deletion.
 */
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { uid, checkPortFree, ensureDir, formatBytes, dirSize } = require('../utils');
const versions = require('./versions');

const RESERVED_PORTS = new Set([cfg.port, 22, 80, 443, 3306, 5432, 6379, 8080, 25565 + 100000]);

/**
 * Find a free allocation for a server, honouring the node's port range and
 * what other panel servers already claimed.
 */
async function allocatePort(preferred, node) {
  const used = new Set((db.get('servers') || []).map((s) => Number(s.port)));
  const range = node && node.portRange ? node.portRange : { start: 25565, end: 25665 };
  const candidates = [];
  if (preferred) candidates.push(Number(preferred));
  for (let p = range.start; p <= range.end; p++) candidates.push(p);
  for (const port of candidates) {
    if (!port || RESERVED_PORTS.has(port) || used.has(port)) continue;
    if (await checkPortFree(port)) return port;
  }
  // last resort: let the OS pick something high
  return 30000 + Math.floor(Math.random() * 20000);
}
exports.allocatePort = allocatePort;

const defaultNode = () => require('./nodes').defaultNode();
exports.defaultNode = defaultNode;

function tagsForRequest(body) {
  return {
    serverType: String(body.serverType || 'PAPER').toUpperCase(),
    version: body.version || 'latest',
    memory: Math.max(256, parseInt(body.memory || 2048, 10)),
    cpuLimit: Math.max(0, parseInt(body.cpuLimit || 0, 10)),
    diskLimit: Math.max(0, parseInt(body.diskLimit || 0, 10)),
    maxPlayers: Math.max(1, parseInt(body.maxPlayers || 20, 10)),
    onlineMode: body.onlineMode !== false,
    port: parseInt(body.port || 0, 10) || 0,
    javaVersion: parseInt(body.javaVersion || 0, 10) || versions.javaFor(body.version),
  };
}

/** Small helper so services can signal an HTTP status to the API layer. */
function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  err.expose = true;
  return err;
}
exports.httpError = httpError;

/** Create the DB record + on-disk skeleton for a new server. */
async function create(body, owner) {
  const settings = db.settings();
  const type = String(body.serverType || 'PAPER').toUpperCase();
  if (!versions.TYPES.find((t) => t.id === type)) throw httpError(400, `Unknown server type ${type}`);

  const owned = (db.get('servers') || []).filter((s) => s.ownerId === owner.id).length;
  const isAdminUser = owner.role === 'admin' || owner.role === 'owner';
  // per-user quota wins, 0/absent means "use the panel-wide default"
  const limit = Number(owner.maxServers) > 0 ? Number(owner.maxServers) : (settings.maxServersPerUser || 5);
  if (!isAdminUser && owned >= limit) {
    throw httpError(409, `Server limit reached (${limit} per user - ask an admin for a higher quota)`);
  }

  const node = body.nodeId ? db.find('nodes', (n) => n.id === body.nodeId) || defaultNode() : defaultNode();
  const tags = tagsForRequest(body);
  const remote = node.id !== 'local';

  // A container runtime is only accepted if the target really has a working
  // daemon - otherwise the user gets the engine's own error right here.
  if (String(body.backend || '') === 'docker') {
    if (remote) {
      const probe = await require('./remote').containerRuntime({ nodeId: node.id });
      if (!probe.available) {
        throw httpError(409, `Node "${node.name}" reports Docker unavailable: ${probe.error || 'the agent did not say why'}`);
      }
    } else {
      const probe = require('./docker').probe({ force: true });
      if (!probe.available) {
        throw httpError(409, `Docker is not available on "${node.name}": ${probe.error || 'the docker CLI did not answer'}`);
      }
    }
  }

  let port = null;
  if (remote) {
    const remoteSvc = require('./remote');
    port = await remoteSvc.freePort(node, node.portRange);
    if (!port) throw httpError(409, `Node "${node.name}" is unreachable or has no free port in ${node.portRange.start}-${node.portRange.end}`);
    logger.info('servers', `starting ${body.name} on remote node ${node.name} :${port}`);
  } else {
    port = await allocatePort(tags.port, node);
  }

  const server = {
    id: uid('srv'),
    name: (body.name || 'Minecraft Server').slice(0, 60),
    description: body.description || '',
    ownerId: owner.id,
    ownerName: owner.username,
    nodeId: node.id,
    nodeName: node.name,
    serverType: tags.serverType,
    version: body.version || 'latest',
    build: null,
    jarFile: 'server.jar',
    memory: tags.memory,
    cpuLimit: tags.cpuLimit,
    diskLimit: tags.diskLimit,
    port,
    ip: body.ip || '0.0.0.0',
    maxPlayers: tags.maxPlayers,
    onlineMode: tags.onlineMode,
    javaVersion: tags.javaVersion,
    javaPath: body.javaPath || '',
    aikarFlags: body.aikarFlags !== false,
    javaArgs: body.javaArgs || '',
    eulaAccepted: !!body.eulaAccepted,
    stopCommand: type === 'BUNGEECORD' || type === 'VELOCITY' ? 'end' : 'stop',
    // runtime choice: '' = follow the node, otherwise 'process' | 'docker'
    backend: body.backend === 'docker' || body.backend === 'process' ? body.backend : '',
    dockerImage: typeof body.dockerImage === 'string' && /^[a-zA-Z0-9][\w.\-/:@]{0,120}$/.test(body.dockerImage.trim()) ? body.dockerImage.trim() : '',
    status: 'installing',
    autoStart: !!body.autoStart,
    autoBackup: body.autoBackup !== false,
    subusers: [],
    packages: [],
    backups: [],
    schedules: defaultSchedules(),
    portAllocations: [port],
    subdomains: [],
    playit: { enabled: false, status: 'stopped', autostart: false },
    createdAt: new Date().toISOString(),
    createdBy: owner.username,
    stats: { cpu: 0, memory: 0 },
    suspended: false,
  };

  db.insert('servers', server);
  if (!remote) {
    await ensureDir(path.join(cfg.serverDataDir, server.id));
    await ensureDir(path.join(cfg.serverDataDir, server.id, 'plugins'));
  }
  db.log({ actor: owner.username, action: 'server.create', serverId: server.id, serverName: server.name, detail: `${type} ${server.version} @ ${node.name}` });
  logger.ok('servers', `created ${server.name} (${type} ${server.version}) on ${node.name}:${port}`);
  return server;
}
exports.create = create;
exports.destroy = destroy;

function defaultSchedules() {
  return [
    { id: uid('sch'), name: 'Nightly restart', action: 'restart', cron: '0 4 * * *', payload: '', enabled: false, createdAt: new Date().toISOString(), lastRun: null, lastResult: null },
    { id: uid('sch'), name: 'Daily backup', action: 'backup', cron: '30 4 * * *', payload: '', enabled: false, createdAt: new Date().toISOString(), lastRun: null, lastResult: null },
  ];
}

/** Stop + delete a server and all of its data. */
async function destroy(server, { removeFiles = true, removeBackups = true } = {}) {
  const runtime = require('./runtime');
  const playit = require('./playit');
  try { await playit.stop(server.id); } catch (_) {}
  try { if (runtime.isOnline(server.id)) await runtime.stop(server.id, { force: true }); } catch (_) {}
  try { await require('./remote').remove(server); } catch (err) { logger.warn('servers', `remote cleanup failed for ${server.name}: ${err.message}`); }
  if (removeFiles) await fsp.rm(path.join(cfg.serverDataDir, server.id), { recursive: true, force: true }).catch(() => {});
  if (removeBackups) await fsp.rm(path.join(cfg.backupDir, server.id), { recursive: true, force: true }).catch(() => {});
  db.remove('servers', server.id);
  db.log({ actor: 'panel', action: 'server.delete', serverName: server.name });
}

/** Cheap live usage snapshot used by the dashboard and admin views. */
async function usage(server, { withDisk = false } = {}) {
  const runtime = require('./runtime');
  const info = runtime.info(server.id);
  // `players` stays a NUMBER here (every consumer adds/sorts with it) - the
  // live roster is exposed separately as `playerList`.
  const data = { id: server.id, status: info.status, stats: info.stats, players: (info.players || []).length, playerList: info.players || [] };
  if (withDisk && require('./runtime').isRemote(server)) {
    const node = require('./remote').nodeFor(server);
    if (node) {
      try {
        const status = await require('./remote').request(node, 'GET', `/api/node/servers/${server.id}/status`, undefined, { timeout: 6000 });
        const bytes = status.diskUsed || 0;
        data.disk = { bytes, pretty: formatBytes(bytes), limit: server.diskLimit * 1024 * 1024, remote: true };
      } catch (_) {
        data.disk = { bytes: 0, pretty: 'n/a', limit: 0, remote: true, error: 'node unreachable' };
      }
      return data;
    }
  }
  if (withDisk) {
    const dir = path.join(cfg.serverDataDir, server.id);
    let bytes = 0;
    try { bytes = await dirSize(dir); } catch (_) {}
    data.disk = { bytes, pretty: formatBytes(bytes), limit: server.diskLimit * 1024 * 1024 };
  }
  return data;
}
exports.usage = usage;

exports.touch = (server, patch) => db.update('servers', server.id, patch);
exports.dir = (server) => path.join(cfg.serverDataDir, server.id);
exports.hasEulaFile = (server) => fs.existsSync(path.join(cfg.serverDataDir, server.id, 'eula.txt'));
