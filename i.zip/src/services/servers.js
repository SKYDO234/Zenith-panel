'use strict';
/**
 * Server records: creation, port allocation, limits and deletion.
 */
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const cfg = require('../config');
const db = require('../db');
const logger = require('../logger');
const { uid, checkPortFree, ensureDir, formatBytes, dirSize } = require('../utils');
const versions = require('./versions');
const games = require('./games');

const RESERVED_PORTS = new Set([cfg.port, 22, 80, 443, 3306, 5432, 6379, 8080, 25565 + 100000]);

/**
 * Find a free allocation for a server, honouring the node's port range and
 * what other panel servers already claimed.
 */
async function allocatePort(preferred, node) {
  const ports = await allocatePorts(1, preferred, node);
  return ports[0];
}
exports.allocatePort = allocatePort;

/** Allocate a contiguous game-port block. Every reserved port is persisted so
 * an adjacent query/shard port cannot later be handed to another workload. */
async function allocatePorts(count, preferred, node) {
  const width = Math.max(1, Math.min(16, Number(count) || 1));
  const used = new Set((db.get('servers') || []).flatMap((s) => (s.portAllocations && s.portAllocations.length ? s.portAllocations : [s.port]).map(Number)));
  const range = node && node.portRange ? node.portRange : { start: 25565, end: 25665 };
  const candidates = [];
  if (preferred) candidates.push(Number(preferred));
  for (let p = range.start; p <= range.end - width + 1; p += 1) candidates.push(p);
  for (const base of candidates) {
    const group = Array.from({ length: width }, (_, index) => base + index);
    if (group.some((item) => !item || RESERVED_PORTS.has(item) || used.has(item))) continue;
    let free = true;
    for (const item of group) { if (!(await checkPortFree(item))) { free = false; break; } }
    if (free) return group;
  }
  throw httpError(409, `No contiguous block of ${width} free ports is available in ${range.start}-${range.end}`);
}
exports.allocatePorts = allocatePorts;

const defaultNode = () => require('./nodes').defaultNode();
exports.defaultNode = defaultNode;

function tagsForRequest(body) {
  return {
    serverType: String(body.serverType || 'PAPER').toUpperCase(),
    version: body.version || 'latest',
    memory: Math.max(256, parseInt(body.memory || 2048, 10)),
    cpuLimit: Math.max(0, parseInt(body.cpuLimit || 0, 10)),
    diskLimit: Math.max(0, parseInt(body.diskLimit || 0, 10)),
    maxPlayers: Math.max(1, parseInt(body.maxPlayers || 20, 10)),
    onlineMode: body.onlineMode !== false,
    port: parseInt(body.port || 0, 10) || 0,
    javaVersion: parseInt(body.javaVersion || 0, 10) || versions.javaFor(body.version),
  };
}

/** Small helper so services can signal an HTTP status to the API layer. */
function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  err.expose = true;
  return err;
}
exports.httpError = httpError;

/** Create the DB record + on-disk skeleton for a new server. */
async function create(body, owner, actor = owner) {
  const settings = db.settings();
  const workloadType = body.workloadType === 'container' ? 'container' : (body.workloadType === 'game' ? 'game' : 'minecraft');
  const type = workloadType === 'container' ? 'CONTAINER' : (workloadType === 'game' ? 'GAME' : String(body.serverType || 'PAPER').toUpperCase());
  const containerTemplate = workloadType === 'container' ? require('./docker').workloadImage(body.containerTemplate) : null;
  const gameTemplate = workloadType === 'game' ? games.game(body.gameId) : null;
  if (workloadType === 'container' && !containerTemplate) throw httpError(400, 'Choose one of the supported container images');
  if (workloadType === 'game' && !gameTemplate) throw httpError(400, 'Choose one of the supported dedicated game templates');
  if (gameTemplate && gameTemplate.platform !== 'linux') throw httpError(409, `${gameTemplate.name} uses an official Windows-only dedicated binary and cannot be created on this Linux Docker node. Use a Windows game node instead.`);
  if (workloadType === 'game') {
    try { games.validateSecrets(gameTemplate, body); } catch (err) { throw httpError(400, err.message); }
  }
  if (workloadType === 'minecraft' && !versions.TYPES.find((t) => t.id === type)) throw httpError(400, `Unknown server type ${type}`);

  const owned = (db.get('servers') || []).filter((s) => s.ownerId === owner.id).length;
  const isAdminUser = owner.role === 'admin' || owner.role === 'owner';
  // per-user quota wins, 0/absent means "use the panel-wide default"
  const limit = Number(owner.maxServers) > 0 ? Number(owner.maxServers) : (settings.maxServersPerUser || 5);
  if (!isAdminUser && owned >= limit) {
    throw httpError(409, `Server limit reached (${limit} per user - ask an admin for a higher quota)`);
  }

  const node = body.nodeId ? db.find('nodes', (n) => n.id === body.nodeId) || defaultNode() : defaultNode();
  const tags = tagsForRequest(body);
  // Game catalogue recommendations apply to API callers too, not only the
  // browser wizard. Explicit 0 disk means "no panel limit" and is preserved.
  if (gameTemplate) {
    if (body.memory === undefined) tags.memory = gameTemplate.memory;
    if (body.diskLimit === undefined) tags.diskLimit = gameTemplate.disk;
    if (body.cpuLimit === undefined) tags.cpuLimit = 100;
    if (body.maxPlayers === undefined) tags.maxPlayers = gameTemplate.players;
  }
  // A generic Docker VPS always receives a real CPU cgroup cap. Older forms
  // used 0 as "unlimited"; for VPS isolation that would make a tenant compete
  // with every host core, so omitted/legacy values mean one vCPU (100%).
  if (workloadType === 'container' && tags.cpuLimit <= 0) tags.cpuLimit = 100;
  const remote = node.id !== 'local';
  if ((workloadType === 'container' || workloadType === 'game') && remote) throw httpError(409, 'Dedicated game and general Docker workloads are currently supported only on the local Docker node; choose Local node or use a Minecraft server on a remote agent');

  // A container runtime is only accepted if the target really has a working
  // daemon - otherwise the user gets the engine's own error right here.
  if (workloadType === 'container' || workloadType === 'game' || String(body.backend || '') === 'docker') {
    if (remote) {
      const probe = await require('./remote').containerRuntime({ nodeId: node.id });
      if (!probe.available) {
        throw httpError(409, `Node "${node.name}" reports Docker unavailable: ${probe.error || 'the agent did not say why'}`);
      }
    } else {
      const probe = require('./docker').probe({ force: true });
      if (!probe.available) {
        throw httpError(409, `Docker is not available on "${node.name}": ${probe.error || 'the docker CLI did not answer'}`);
      }
    }
  }

  let port = null;
  let portAllocations = [];
  if (remote) {
    const remoteSvc = require('./remote');
    port = await remoteSvc.freePort(node, node.portRange);
    if (!port) throw httpError(409, `Node "${node.name}" is unreachable or has no free port in ${node.portRange.start}-${node.portRange.end}`);
    portAllocations = [port];
    logger.info('servers', `starting ${body.name} on remote node ${node.name} :${port}`);
  } else {
    portAllocations = workloadType === 'game'
      ? await allocatePorts(gameTemplate.ports.length, tags.port, node)
      : [await allocatePort(tags.port, node)];
    port = portAllocations[0];
  }

  const serverId = uid('srv');
  const server = {
    id: serverId,
    name: (body.name || 'Minecraft Server').slice(0, 60),
    description: body.description || '',
    ownerId: owner.id,
    ownerName: owner.username,
    nodeId: node.id,
    nodeName: node.name,
    workloadType,
    gameId: gameTemplate ? gameTemplate.id : '',
    gameName: gameTemplate ? gameTemplate.name : '',
    gameAppId: gameTemplate ? gameTemplate.appId : null,
    gamePlatform: gameTemplate ? gameTemplate.platform : '',
    // Passwords/tokens are game launch secrets and are intentionally omitted
    // from every public API projection.
    gameSecrets: gameTemplate ? games.validateSecrets(gameTemplate, body) : null,
    containerTemplate: containerTemplate ? containerTemplate.id : '',
    // `vm` means a Linux system-container-style workspace (still Docker's
    // shared kernel); `bot` is the curated Python/Node application runtime.
    // The classification comes only from the audited image catalogue.
    containerRole: containerTemplate ? containerTemplate.family : '',
    // A generic VPS receives a deterministic hostname and a private managed
    // bridge. Neither is selected by the user, so tenant names cannot collide
    // or influence another workload's namespace.
    containerHostname: workloadType === 'container' ? require('./docker').workloadHostname(serverId) : '',
    containerNetwork: workloadType === 'container' ? require('./docker').workloadNetworkName(serverId) : '',
    // Bumped whenever the container's base image/limits/isolation policy need
    // a fresh Docker create. Its /data directory remains the only persisted bind.
    containerSpec: '',
    // Created at runtime for generic workloads after sshx prints its real
    // browser-session URL. It is intentionally not an API credential.
    sshx: workloadType === 'container' ? { status: 'offline', url: '', error: '', updatedAt: null } : null,
    serverType: workloadType === 'container' ? 'CONTAINER' : (workloadType === 'game' ? 'GAME' : tags.serverType),
    version: workloadType === 'container' ? containerTemplate.id : (workloadType === 'game' ? `SteamCMD app ${gameTemplate.appId}` : (body.version || 'latest')),
    build: null,
    jarFile: workloadType === 'game' ? '' : 'server.jar',
    memory: tags.memory,
    cpuLimit: tags.cpuLimit,
    diskLimit: tags.diskLimit,
    port,
    ip: body.ip || '0.0.0.0',
    maxPlayers: tags.maxPlayers,
    onlineMode: tags.onlineMode,
    javaVersion: tags.javaVersion,
    javaPath: body.javaPath || '',
    aikarFlags: body.aikarFlags !== false,
    javaArgs: body.javaArgs || '',
    eulaAccepted: workloadType === 'container' || workloadType === 'game' ? true : !!body.eulaAccepted,
    stopCommand: workloadType === 'container' || workloadType === 'game' ? '' : (type === 'BUNGEECORD' || type === 'VELOCITY' ? 'end' : 'stop'),
    // General workloads and games are always actual Docker containers. Minecraft
    // may still follow its node backend or opt into Docker independently.
    backend: workloadType === 'container' || workloadType === 'game' ? 'docker' : (body.backend === 'docker' || body.backend === 'process' ? body.backend : ''),
    dockerImage: gameTemplate ? games.STEAMCMD_IMAGE : (containerTemplate ? containerTemplate.image : (typeof body.dockerImage === 'string' && /^[a-zA-Z0-9][\w.\-/:@]{0,120}$/.test(body.dockerImage.trim()) ? body.dockerImage.trim() : '')),
    status: 'installing',
    autoStart: !!body.autoStart,
    autoBackup: body.autoBackup !== false,
    subusers: [],
    packages: [],
    backups: [],
    schedules: defaultSchedules(),
    portAllocations,
    subdomains: [],
    playit: { enabled: false, status: 'stopped', autostart: false },
    createdAt: new Date().toISOString(),
    createdBy: actor.username,
    stats: { cpu: 0, memory: 0 },
    suspended: false,
  };

  db.insert('servers', server);
  if (!remote) {
    await ensureDir(path.join(cfg.serverDataDir, server.id));
    // General containers own a neutral /data directory. Do not seed Minecraft
    // plugin/mod folders into their file manager.
    if (workloadType === 'minecraft') await ensureDir(path.join(cfg.serverDataDir, server.id, 'plugins'));
  }
  db.log({ actor: actor.username, action: 'server.create', serverId: server.id, serverName: server.name, detail: `${workloadType === 'container' ? containerTemplate.name : (workloadType === 'game' ? gameTemplate.name : `${type} ${server.version}`)} @ ${node.name} for ${owner.username}` });
  logger.ok('servers', `created ${server.name} (${workloadType === 'container' ? containerTemplate.name : (workloadType === 'game' ? gameTemplate.name : `${type} ${server.version}`)}) on ${node.name}:${port}`);
  return server;
}
exports.create = create;
exports.destroy = destroy;

function defaultSchedules() {
  return [
    { id: uid('sch'), name: 'Nightly restart', action: 'restart', cron: '0 4 * * *', payload: '', enabled: false, createdAt: new Date().toISOString(), lastRun: null, lastResult: null },
    { id: uid('sch'), name: 'Daily backup', action: 'backup', cron: '30 4 * * *', payload: '', enabled: false, createdAt: new Date().toISOString(), lastRun: null, lastResult: null },
  ];
}

/** Stop + delete a server and all of its data. */
async function destroy(server, { removeFiles = true, removeBackups = true } = {}) {
  const runtime = require('./runtime');
  const playit = require('./playit');
  try { await playit.stop(server.id); } catch (_) {}
  try { if (runtime.isOnline(server.id)) await runtime.stop(server.id, { force: true }); } catch (_) {}
  // Generic workloads are genuine named Docker containers. Remove that
  // runtime record during deletion as well as the mounted panel data.
  if ((server.workloadType === 'container' || server.workloadType === 'game') && server.nodeId === 'local') {
    const docker = require('./docker');
    try { await docker.remove(server.containerName || docker.containerName(server.id)); }
    catch (err) { logger.warn('servers', `container cleanup failed for ${server.name}: ${err.message}`); }
    if (server.workloadType === 'container') {
      try { await docker.removeWorkloadNetwork(server.id); }
      catch (err) { logger.warn('servers', `container network cleanup failed for ${server.name}: ${err.message}`); }
    }
  }
  try { await require('./remote').remove(server); } catch (err) { logger.warn('servers', `remote cleanup failed for ${server.name}: ${err.message}`); }
  if (removeFiles) await fsp.rm(path.join(cfg.serverDataDir, server.id), { recursive: true, force: true }).catch(() => {});
  if (removeBackups) await fsp.rm(path.join(cfg.backupDir, server.id), { recursive: true, force: true }).catch(() => {});
  db.remove('servers', server.id);
  db.log({ actor: 'panel', action: 'server.delete', serverName: server.name });
}

/** Cheap live usage snapshot used by the dashboard and admin views. */
async function usage(server, { withDisk = false } = {}) {
  const runtime = require('./runtime');
  const info = runtime.info(server.id);
  // `players` stays a NUMBER here (every consumer adds/sorts with it) - the
  // live roster is exposed separately as `playerList`.
  const data = { id: server.id, status: info.status, stats: info.stats, players: (info.players || []).length, playerList: info.players || [] };
  if (withDisk && require('./runtime').isRemote(server)) {
    const node = require('./remote').nodeFor(server);
    if (node) {
      try {
        const status = await require('./remote').request(node, 'GET', `/api/node/servers/${server.id}/status`, undefined, { timeout: 6000 });
        const bytes = status.diskUsed || 0;
        data.disk = { bytes, pretty: formatBytes(bytes), limit: server.diskLimit * 1024 * 1024, remote: true };
      } catch (_) {
        data.disk = { bytes: 0, pretty: 'n/a', limit: 0, remote: true, error: 'node unreachable' };
      }
      return data;
    }
  }
  if (withDisk) {
    const dir = path.join(cfg.serverDataDir, server.id);
    let bytes = 0;
    try { bytes = await dirSize(dir); } catch (_) {}
    data.disk = { bytes, pretty: formatBytes(bytes), limit: server.diskLimit * 1024 * 1024 };
  }
  return data;
}
exports.usage = usage;

exports.touch = (server, patch) => db.update('servers', server.id, patch);
exports.dir = (server) => path.join(cfg.serverDataDir, server.id);
exports.hasEulaFile = (server) => fs.existsSync(path.join(cfg.serverDataDir, server.id, 'eula.txt'));
