'use strict';
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const https = require('https');
const http = require('http');

/* ------------------------------ ids ------------------------------ */
const uid = (prefix = 'id') => `${prefix}_${Date.now().toString(36)}${crypto.randomBytes(4).toString('hex')}`;
const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('hex');

/* ---------------------------- numbers ---------------------------- */
function formatBytes(bytes, digits = 1) {
  bytes = Number(bytes) || 0;
  if (bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : digits)} ${units[i]}`;
}

const clamp = (n, min, max) => Math.min(Math.max(Number(n) || 0, min), max);

/* ------------------------------ paths ------------------------------ */
/**
 * Resolve `target` inside `base`, refusing anything that escapes it.
 * Protects the file manager / modrinth installer against ../../ traversal.
 */
function safeJoin(base, target = '') {
  const cleaned = String(target).replace(/\\/g, '/').replace(/^\/+/, '');
  const resolved = path.resolve(base, cleaned);
  const rel = path.relative(path.resolve(base), resolved);
  if (rel.startsWith('..') || path.isAbsolute(rel) && rel !== '') {
    if (rel.startsWith('..')) throw new Error('Path escapes the server directory');
  }
  if (rel.split(path.sep).includes('..')) throw new Error('Path escapes the server directory');
  return resolved;
}

/* ------------------------------ fs ------------------------------ */
async function ensureDir(dir) { await fsp.mkdir(dir, { recursive: true }); }
async function exists(p) { try { await fsp.access(p); return true; } catch { return false; } }
function existsSync(p) { try { fs.accessSync(p); return true; } catch { return false; } }

async function readJson(file, fallback = null) {
  try { return JSON.parse(await fsp.readFile(file, 'utf8')); } catch { return fallback; }
}
async function writeJson(file, data, pretty = true) {
  await ensureDir(path.dirname(file));
  const tmp = `${file}.${process.pid}.tmp`;
  await fsp.writeFile(tmp, pretty ? JSON.stringify(data, null, 2) : JSON.stringify(data));
  await fsp.rename(tmp, file);
}

async function dirSize(dir) {
  let total = 0;
  const walk = async (d) => {
    let entries = [];
    try { entries = await fsp.readdir(d, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const full = path.join(d, e.name);
      try {
        if (e.isDirectory()) await walk(full);
        else if (e.isFile()) total += (await fsp.stat(full)).size;
      } catch { /* ignore */ }
    }
  };
  await walk(dir);
  return total;
}

/* --------------------------- binary / text --------------------------- */
const TEXT_EXT = new Set(['.txt', '.log', '.yml', '.yaml', '.json', '.properties', '.toml', '.conf', '.cfg',
  '.ini', '.md', '.sh', '.bat', '.js', '.ts', '.html', '.css', '.xml', '.mcmeta', '.csv', '.env', '.jar.txt', '.gitignore', '.snbt']);
function looksTextual(file, size) {
  const ext = path.extname(file).toLowerCase();
  if (TEXT_EXT.has(ext)) return true;
  if (!ext && size < 512 * 1024) return true;
  return false;
}

/* ------------------------------ net ------------------------------ */
function fetchJson(url, { headers = {}, timeout = 25000 } = {}) {
  return new Promise(async (resolve, reject) => {
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), timeout);
    try {
      const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json', ...headers }, signal: ac.signal });
      clearTimeout(t);
      if (!res.ok) return reject(new Error(`HTTP ${res.status} for ${url}`));
      resolve(await res.json());
    } catch (e) { clearTimeout(t); reject(e); }
  });
}
const UA = 'zenith-panel/1.0.0 (+https://github.com/zenith-panel)';

/** Download a URL to a file, following redirects, reporting progress. */
function download(url, dest, { onProgress, timeout = 600000, expected } = {}) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    let received = 0;
    let settled = false;
    const fail = (err) => {
      if (settled) return;
      settled = true;
      file.close(() => fs.unlink(dest, () => reject(err)));
    };
    const go = (u, redirects = 0) => {
      if (redirects > 8) return fail(new Error('Too many redirects'));
      const mod = u.startsWith('https') ? https : http;
      const req = mod.get(u, { headers: { 'User-Agent': UA, Accept: '*/*' }, timeout }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          return go(new URL(res.headers.location, u).toString(), redirects + 1);
        }
        if (res.statusCode !== 200) {
          res.resume();
          return fail(new Error(`Download failed: HTTP ${res.statusCode}`));
        }
        const total = Number(res.headers['content-length'] || expected || 0);
        res.on('data', (chunk) => {
          received += chunk.length;
          if (onProgress) onProgress({ received, total, percent: total ? Math.round((received / total) * 100) : 0 });
        });
        file.on('error', fail);
        res.pipe(file);
        file.on('finish', () => { if (settled) return; settled = true; file.close(() => resolve({ path: dest, size: received })); });
      });
      req.on('error', fail);
      req.on('timeout', () => { req.destroy(new Error('Download timed out')); });
    };
    go(url);
  });
}

/* ------------------------------ misc ------------------------------ */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function parseCronField(field, min, max) {
  const out = new Set();
  for (const part of String(field).split(',')) {
    const stepSplit = part.split('/');
    const step = stepSplit[1] ? parseInt(stepSplit[1], 10) : 1;
    let range = stepSplit[0];
    let start = min, end = max;
    if (range !== '*') {
      if (range.includes('-')) {
        const [a, b] = range.split('-');
        start = a === '' ? min : parseInt(a, 10);
        end = b === '' ? max : parseInt(b, 10);
      } else {
        start = end = parseInt(range, 10);
      }
    }
    if (Number.isNaN(start) || Number.isNaN(end)) continue;
    for (let i = start; i <= end; i += Math.max(step, 1)) if (i >= min && i <= max) out.add(i);
  }
  return out;
}

/** Minimal 5-field cron matcher (minute hour dom month dow). */
function cronMatches(expr, date = new Date()) {
  const parts = String(expr || '').trim().split(/\s+/);
  if (parts.length !== 5) return false;
  const checks = [
    [parts[0], date.getMinutes(), 0, 59],
    [parts[1], date.getHours(), 0, 23],
    [parts[2], date.getDate(), 1, 31],
    [parts[3], date.getMonth() + 1, 1, 12],
    [parts[4], date.getDay(), 0, 6],
  ];
  return checks.every(([field, value, min, max]) => parseCronField(field, min, max).has(value));
}

function describeCron(expr) {
  const map = { '@hourly': 'Every hour', '@daily': 'Every day at midnight', '@weekly': 'Every week', '@monthly': 'Every month', '@reboot': 'On panel start' };
  if (map[expr]) return map[expr];
  return expr;
}

/** TCP port check: is something already listening? */
function checkPortFree(port, host = '0.0.0.0') {
  return new Promise((resolve) => {
    const srv = require('net').createServer();
    srv.once('error', () => resolve(false));
    srv.once('listening', () => srv.close(() => resolve(true)));
    srv.listen(port, host);
  });
}

function stripAnsi(str = '') {
  // eslint-disable-next-line no-control-regex
  return String(str).replace(/\u001b\[[0-9;?]*[ -/]*[@-~]/g, '').replace(/\u001b\][^\u0007]*\u0007/g, '');
}

module.exports = {
  uid, randomToken, formatBytes, clamp, safeJoin, ensureDir, exists, existsSync,
  readJson, writeJson, dirSize, looksTextual, fetchJson, download, sleep,
  cronMatches, describeCron, checkPortFree, stripAnsi, TEXT_EXT,
};
