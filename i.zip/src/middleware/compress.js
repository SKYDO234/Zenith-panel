'use strict';
/**
 * Response compression + cache headers - no extra dependency.
 *
 * The panel ships ~470 KB of front-end assets (`public/js/server.js` alone is
 * 125 KB). Gzipped that is 8-12 KB per file, so this middleware is the single
 * biggest loading win: the same bytes over the wire, without a CDN.
 *
 * How it stays safe:
 *   - it only touches responses whose body is available as one buffer with a
 *     known Content-Length of at most `maxSize` - downloads, uploads, backups
 *     and streamed responses pass through untouched;
 *   - Range requests (206) and already-encoded bodies are never re-encoded;
 *   - compressed static assets are cached by (url, ETag) so a hot file is
 *     compressed exactly once, not once per request.
 *
 * `zlib` is part of Node, so this adds 0 bytes to node_modules.
 */
const zlib = require('zlib');

const COMPRESSIBLE = /^(text\/|application\/(json|javascript|xml|xhtml\+xml|manifest\+json|ld\+json)|image\/svg\+xml|font\/(ttf|otf|woff2?)|application\/vnd\.ms-fontobject)/i;

// brotli is noticeably smaller but CPU-hungry: use it for the static files that
// are compressed once and cached, gzip for everything else.
const STATIC_RE = /^\/(css|js|assets)\//;

function negotiate(header = '') {
  const value = String(header);
  if (/\bbr\b/.test(value)) return 'br';
  if (/\bgzip\b/.test(value)) return 'gzip';
  if (/\bdeflate\b/.test(value)) return 'deflate';
  return null;
}

function encode(buffer, encoding) {
  if (encoding === 'br') {
    return zlib.brotliCompressSync(buffer, {
      params: {
        [zlib.constants.BROTLI_PARAM_QUALITY]: 9,
        [zlib.constants.BROTLI_PARAM_SIZE_HINT]: buffer.length,
      },
    });
  }
  if (encoding === 'deflate') return zlib.deflateSync(buffer, { level: 6 });
  return zlib.gzipSync(buffer, { level: 9 });
}

function contentTypeOf(res) {
  const type = res.getHeader('Content-Type');
  return Array.isArray(type) ? type[0] : String(type || '');
}

function compression({ threshold = 1024, maxSize = 4 * 1024 * 1024, cacheLimit = 120 } = {}) {
  /** @type {Map<string, {etag: string, body: Buffer, encoding: string}>} */
  const cache = new Map();

  const remember = (key, entry) => {
    if (cache.size >= cacheLimit) cache.delete(cache.keys().next().value);
    cache.set(key, entry);
  };

  return function compress(req, res, next) {
    const encoding = negotiate(req.headers['accept-encoding']);
    // HEAD has no body to save; small/encoded responses are not worth it.
    if (!encoding || req.method === 'HEAD') return next();

    const originalWrite = res.write;
    const originalEnd = res.end;
    let chunks = [];
    let buffered = 0;
    let bypass = false;

    const giveUp = () => {
      bypass = true;
      if (chunks.length) {
        for (const chunk of chunks) originalWrite.call(res, chunk);
        chunks = [];
      }
    };

    // Reads are buffered until the response ends or grows past `maxSize`
    // (express.static streams even small files in 64 KB blocks, so a single
    // write is not a safe assumption). Everything above the cap - downloads,
    // backups, container logs - is flushed and passed through untouched.
    const absorb = (chunk, enc) => {
      const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, typeof enc === 'string' && enc !== 'buffer' ? enc : 'utf8');
      chunks.push(buf);
      buffered += buf.length;
      if (buffered > maxSize) giveUp();
    };

    res.write = function write(chunk, enc, cb) {
      if (bypass || chunk === undefined || chunk === null) return originalWrite.call(res, chunk, enc, cb);
      absorb(chunk, enc);
      return true;
    };

    res.end = function end(chunk, enc, cb) {
      if (chunk !== undefined && chunk !== null && !bypass) absorb(chunk, enc);

      if (bypass) return originalEnd.call(res, undefined, undefined, cb);

      const body = chunks.length === 1 ? chunks[0] : Buffer.concat(chunks);
      chunks = [];

      const status = res.statusCode || 200;
      const type = contentTypeOf(res);
      const already = res.getHeader('Content-Encoding');
      const noTransform = res.getHeader('Cache-Control') === 'no-transform';
      const worthIt = body.length >= threshold
        && !already
        && !noTransform
        && status !== 204 && status !== 206 && status !== 304
        && !res.getHeader('Content-Range')
        && COMPRESSIBLE.test(type);

      if (!worthIt) {
        if (!res.headersSent) res.setHeader('Content-Length', body.length);
        return originalEnd.call(res, body, undefined, cb);
      }

      const etag = String(res.getHeader('ETag') || `${body.length}`);
      const key = `${STATIC_RE.test(req.path) ? req.path : req.originalUrl}|${etag}|${body.length}|${encoding}`;
      let entry = cache.get(key);
      if (!entry) {
        try {
          entry = { body: encode(body, encoding), encoding };
        } catch (err) {
          // never break a response because compression failed
          if (!res.headersSent) res.setHeader('Content-Length', body.length);
          return originalEnd.call(res, body, undefined, cb);
        }
        if (STATIC_RE.test(req.path)) remember(key, entry);
      }

      if (!res.headersSent) {
        res.setHeader('Content-Encoding', encoding);
        res.setHeader('Content-Length', entry.body.length);
        // caches keep the two variants apart
        res.setHeader('Vary', 'Accept-Encoding');
        const previous = res.getHeader('ETag');
        if (previous) res.setHeader('ETag', `${previous}-${encoding}`);
      }
      return originalEnd.call(res, entry.body, undefined, cb);
    };

    next();
  };
}

/** Cache policy per path: immutable-ish assets, always-fresh HTML, never-cache API. */
function cacheHeaders(req, res, next) {
  const pathname = (req.path || '').toLowerCase();
  if (pathname.startsWith('/api/')) {
    // authenticated JSON: never store it in a shared cache
    res.setHeader('Cache-Control', 'no-store');
  } else if (/\.(css|js|svg|png|jpe?g|gif|webp|ico|woff2?|ttf)$/.test(pathname)) {
    res.setHeader('Cache-Control', 'public, max-age=3600, must-revalidate');
  } else if (/\.html?$/.test(pathname) || pathname === '/') {
    // the shell changes with every release; revalidate cheaply (304)
    res.setHeader('Cache-Control', 'no-cache');
  }
  next();
}

module.exports = { compression, cacheHeaders, negotiate };
